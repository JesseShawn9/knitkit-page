const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html')));
});
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext({ viewport: { width: 393, height: 852 } });
    const source = await context.newPage();
    await source.goto('file://' + path.join(root, 'dist/knitkit2.html'));
    await source.waitForFunction(() => initialized);
    await source.selectOption('#mode', '66');
    const input = randomBytes(96 * 1024);
    await source.locator('#pattern').setInputFiles({ name: 'portrait.bin', mimeType: 'application/octet-stream', buffer: input });
    await source.waitForFunction(() => ready && !preparing);
    async function imagesForMode(mode) {
      await source.selectOption('#mode', String(mode));
      await source.waitForFunction(() => ready && !preparing);
      return source.evaluate(() => {
      const canvas = document.querySelector('#canvas');
      const copy = document.createElement('canvas'); copy.width = canvas.width; copy.height = canvas.height;
      const ctx = copy.getContext('2d'); const images = [];
      for (let i = 0; i < 75; i++) {
        Module._cimbare_next_frame(false); Module._cimbare_render();
        ctx.drawImage(document.querySelector('#canvas'), 0, 0);
        images.push(copy.toDataURL());
      }
      return images;
      });
    }
    let fixtures = await imagesForMode(66);
    for (const [width, height, fallback] of [[1344, 2240, false], [1344, 2240, true], [3840, 2160, false]]) {
      if (width === 3840) fixtures = await imagesForMode(68);
      const ctx = await browser.newContext({ viewport: { width: 393, height: 852 } });
      const reader = await ctx.newPage();
      await reader.goto('http://127.0.0.1:' + server.address().port);
      await reader.evaluate(({ width, height, fallback }) => {
        const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
        const context = canvas.getContext('2d'); context.fillStyle = '#333'; context.fillRect(0, 0, width, height);
        window.fixture = { canvas, context };
        navigator.mediaDevices.getUserMedia = async () => {
          const stream = canvas.captureStream(30);
          setTimeout(() => context.drawImage(canvas, 0, 0), 50); return stream;
        };
        // Reproduce a frozen time property; capture must not depend on this clock.
        const video = document.querySelector('#video');
        Object.defineProperty(video, 'currentTime', { get: () => 0 });
        if (fallback) video.requestVideoFrameCallback = undefined;
      }, { width, height, fallback });
      await reader.locator('#read').click();
      await reader.waitForFunction(() => reading && workerReady);
      let sawProgress = false;
      for (let start = 0; start < fixtures.length; start += 5) {
        await reader.evaluate(async images => {
          for (const src of images) {
            if (!reading) break;
            const before = captured;
            const image = new Image(); image.src = src; await image.decode();
            fixture.context.fillStyle = '#333'; fixture.context.fillRect(0, 0, fixture.canvas.width, fixture.canvas.height);
            // The code deliberately extends outside the old central crop.
            fixture.context.drawImage(image, 72, 60, 1200, 1200 * image.naturalHeight / image.naturalWidth);
            const deadline = performance.now() + 6000;
            while (reading && (captured === before || busy) && performance.now() < deadline) await new Promise(resolve => setTimeout(resolve, 20));
          }
        }, fixtures.slice(start, start + 5));
        const value = await reader.locator('#partialProgress').evaluate(el => el.value);
        if (value > 0 && value < 1) sawProgress = true;
        if (await reader.locator('#saveArea').isVisible()) break;
      }
      await reader.locator('#saveArea').waitFor({ state: 'visible', timeout: 20000 }).catch(async error => {
        console.log(await reader.evaluate(() => ({ reading, busy, captured, frames, progress: document.querySelector('#partial').textContent, hint: document.querySelector('#stateHint').textContent })));
        throw error;
      });
      assert(sawProgress, 'Native intermediate progress must be visible');
      assert.equal(await reader.evaluate(async () => KnitBatches.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), createHash('sha256').update(input).digest('hex'));
      const camera = await reader.locator('.camera').boundingBox();
      assert(Math.abs(camera.width / camera.height - width / height) < 0.01, 'Preview must keep the complete camera aspect ratio');
      assert.deepEqual(await reader.evaluate(() => [capture.width, capture.height]), [width, height]);
      assert.equal(await reader.locator('#video').evaluate(el => getComputedStyle(el).objectFit), 'contain');
      assert((await reader.locator('#partialProgress').boundingBox()).y < 220);
      assert((await reader.locator('#read').boundingBox()).y < 260);
      await reader.screenshot({ path: '/private/tmp/knitkit2-browser-check/reader-original-' + width + '-' + fallback + '.png', fullPage: true });
      await ctx.close();
      console.log('PASS: ' + (width === 3840 ? 'B' : 'Bu') + ' detection, off-centre ' + width + 'x' + height + ' video at original resolution + frozen currentTime, native progress and exact SHA-256, ' + (fallback ? 'timer fallback' : 'video frame callback'));
    }
    await context.close();
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
