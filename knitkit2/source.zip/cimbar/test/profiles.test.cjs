const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    for (const profile of [
      { name: 'phone', ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)', platform: 'iPhone', cores: 6, touch: 5, count: 1, width: 393, height: 852 },
      { name: 'tablet', ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15)', platform: 'MacIntel', cores: 8, touch: 5, count: 2, width: 1180, height: 820 },
      { name: 'desktop', ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) Chrome/142.0', platform: 'MacIntel', cores: 24, touch: 0, count: 4, width: 1440, height: 900 }
    ]) {
      const context = await browser.newContext({ userAgent: profile.ua, viewport: { width: profile.width, height: profile.height } });
      await context.addInitScript(p => {
        Object.defineProperty(navigator, 'platform', { get: () => p.platform });
        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => p.cores });
        Object.defineProperty(navigator, 'maxTouchPoints', { get: () => p.touch });
      }, profile);
      const page = await context.newPage(); await page.goto('http://127.0.0.1:' + server.address().port);
      await page.evaluate(() => makeWorker()); await page.waitForFunction(() => workerReady);
      assert.equal(await page.evaluate(() => pool.length), profile.count);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
      const frame = await page.locator('.camera').boundingBox(); assert(Math.abs(frame.width / frame.height - 16 / 9) < .01);
      assert(await page.locator('#read').isVisible()); assert(await page.locator('#pause').isVisible());
      if (profile.name === 'phone') {
        await page.setViewportSize({ width: 852, height: 393 });
        assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
        assert.equal(await page.evaluate(() => pool.length), profile.count);
      }
      await page.evaluate(() => disposeWorker()); await context.close();
      console.log('PASS: simulated ' + profile.name + ' browser facts -> ' + profile.count + ' extraction workers + one collector; wide responsive viewport, no horizontal overflow (not a real-device test)');
    }
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
