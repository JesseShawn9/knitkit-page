const assert = require('node:assert/strict');
const { webcrypto, randomBytes } = require('node:crypto');
if (!globalThis.crypto) globalThis.crypto = webcrypto;
require('../src/batches.js');
const B = globalThis.KnitBatches;

(async () => {
  const input = randomBytes(1024 * 1024 + 17);
  const file = new File([input], '中文文件-测试.zip', { type: 'application/zip' });
  const m = await B.prepare(file, 256 * 1024);
  assert.equal(m.hashes.length, 5);
  assert.equal((await B.prepare(file, m.partSize)).id, m.id);
  assert.notEqual((await B.prepare(file, 128 * 1024)).id, m.id);
  assert.equal(B.ranges([4, 2, 0, 1, 4]), '1-3,5');
  const code = B.mending(m, new Set([1, 3]));
  assert.deepEqual(B.replay(m, code), [0, 2, 4]);
  assert.deepEqual(B.replay(m, 'KK2M:' + m.id + ':1-5,2'), [0, 1, 2, 3, 4]);
  for (const invalid of ['0', '6', '3-1', '1-999999999', 'NaN', '1,,2', '']) {
    assert.throws(() => B.replay(m, 'KK2M:' + m.id + ':' + invalid));
  }
  assert.throws(() => B.replay({ ...m, id: '0'.repeat(64) }, code), /不属于/);
  const packets = [];
  const saved = new Map();
  for (const i of [4, 1, 3, 0, 2, 2]) {
    const value = await B.packet(file, m, i);
    const decoded = await B.unpack(value);
    saved.set(decoded.index, decoded.data); packets.push(value);
  }
  const output = await B.assemble(m, i => saved.get(i));
  assert.deepEqual(Buffer.from(await output.arrayBuffer()), input);
  await assert.rejects(() => B.assemble(m, i => i === 1 ? undefined : saved.get(i)), /缺失或损坏/);
  const corrupt = new Uint8Array(await packets[1].arrayBuffer()); corrupt[corrupt.length - 1] ^= 1;
  await assert.rejects(() => B.unpack(new Blob([corrupt])), /校验失败/);
  await assert.rejects(() => B.unpack(packets[0].slice(0, 30)));
  await assert.rejects(() => B.validate({ ...m, size: m.size + 1 }));
  await assert.rejects(() => B.packet(file, m, -1));
  const empty = new File([], 'empty.bin'); const em = await B.prepare(empty, 1024);
  assert.equal((await B.unpack(await B.packet(empty, em, 0))).data.size, 0);
  assert.equal((await B.assemble(em, () => new Blob())).size, 0);

  const large = new File([Buffer.alloc(165 * 1024 * 1024, 0xa7)], '165MiB.bin');
  const lm = await B.prepare(large, 10 * 1024 * 1024);
  assert.equal(lm.hashes.length, 17);
  const parts = new Map();
  for (let i = lm.hashes.length - 1; i >= 0; i--) {
    const p = await B.unpack(await B.packet(large, lm, i)); parts.set(i, p.data);
  }
  const merged = await B.assemble(lm, i => parts.get(i));
  assert.equal(merged.size, large.size);
  assert.equal(await B.hash(await merged.arrayBuffer()), await B.hash(await large.arrayBuffer()));
  console.log('PASS: binary/Unicode/empty/deterministic/duplicates/out-of-order/tampering/missing; 165MiB => 17 parts => exact full-file SHA-256 match');
})().catch(error => { console.error(error); process.exitCode = 1; });
