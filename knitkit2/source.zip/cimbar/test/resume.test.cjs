const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const os = require('node:os');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'knitkit2-resume-'));
  let context = await chromium.launchPersistentContext(profile, { channel: 'chrome', headless: true });
  try {
    const source = await context.newPage();
    await source.goto('file://' + path.join(root, 'dist/knitkit2.html'));
    await source.waitForFunction(() => initialized);
    const input = randomBytes(2 * 1024 * 1024);
    await source.locator('#pattern').setInputFiles({ name: 'resume-中文.zip', mimeType: 'application/zip', buffer: input });
    await source.waitForFunction(() => ready && !preparing);
    const fixtures = await source.evaluate(async () => {
      const canvas = document.querySelector('#canvas');
      const copy = document.createElement('canvas'); copy.width = 1040; copy.height = 1040;
      const ctx = copy.getContext('2d', { willReadFrequently: true });
      Module._cimbard_configure_decode(68);
      const cap = Module._cimbard_get_bufsize(), p = Module._malloc(cap), image = Module._malloc(1040 * 1040 * 4);
      function capture(limit) {
        const chunks = [];
        for (let frame = 0; chunks.length < limit; frame++) {
          if (frame) Module._cimbare_next_frame(false);
          Module._cimbare_render(); ctx.drawImage(canvas, 0, 0);
          Module.HEAPU8.set(ctx.getImageData(0, 0, 1040, 1040).data, image);
          const length = Module._cimbard_scan_extract_decode(image, 1040, 1040, 4, p, cap);
          if (length < 0 || length % 625) throw new Error('Native extraction failed: ' + length);
          for (let i = 0; i < length; i += 625) chunks.push(Module.HEAPU8.slice(p + i, p + i + 625));
        }
        return chunks;
      }
      function pack(chunks) {
        const joined = new Uint8Array(chunks.length * 625);
        chunks.forEach((c, i) => joined.set(c, i * 625));
        let binary = ''; for (let i = 0; i < joined.length; i += 8192) binary += String.fromCharCode(...joined.subarray(i, i + 8192));
        return btoa(binary);
      }
      const sets = [];
      try {
        for (let index = 0; index < 2; index++) {
          await selectBatch(index);
          const first = capture(1), head = first[0];
          const size = (head[0] >>> 7) * 16777216 + head[1] * 65536 + head[2] * 256 + head[3];
          const n = Math.ceil(size / 619), cutoff = Math.floor(n * .58);
          // Reinitialize so capture begins with symbol zero, exactly as the carried sender does.
          await selectBatch(index);
          const all = capture(n + 40);
          const left = all.filter(c => c[4] * 256 + c[5] < cutoff && (index === 0 || c[4] !== 0 || c[5] !== 0));
          await selectBatch(index);
          const replay = capture(n + 40);
          const right = replay.filter(c => c[4] * 256 + c[5] === 0 || c[4] * 256 + c[5] >= cutoff);
          const az = all.find(c => c[4] === 0 && c[5] === 0), bz = replay.find(c => c[4] === 0 && c[5] === 0);
          if (!az || !bz) throw new Error('Systematic anchor not captured');
          if ((az[0] & 127) === (bz[0] & 127)) throw new Error('Replay must change upstream ID');
          const a = az.slice(), b = bz.slice(); a[0] &= 128; b[0] &= 128;
          if (!a.every((v, i) => v === b[i])) throw new Error('Replay symbol content changed');
          sets.push({ left: pack(left), right: pack(right), n, counts: [left.length, right.length], ids: [az[0] & 127, bz[0] & 127] });
        }
        return sets;
      } finally { Module._free(p); Module._free(image); }
    });
    let reader = await context.newPage();
    const url = 'http://127.0.0.1:' + server.address().port;
    await reader.goto(url);
    async function engine() {
      await reader.evaluate(async () => {
        const source = new TextDecoder().decode(Uint8Array.from(atob(document.querySelector('#readerSource').textContent.trim()), c => c.charCodeAt(0)));
        const url = URL.createObjectURL(new Blob(['var knitRole="collector";\n', source], { type: 'text/javascript' }));
        window.testEngine = new Worker(url); URL.revokeObjectURL(url);
        window.testErrors = []; window.testCompleted = []; window.testProgress = []; window.testSequence = 0;
        await new Promise((resolve, reject) => {
          testEngine.onerror = e => reject(new Error(e.message));
          testEngine.onmessage = e => { if (e.data.kind === 'ready') resolve(); else if (e.data.kind === 'error') reject(new Error(e.data.message)); };
        });
        testEngine.onmessage = async e => {
          const d = e.data;
          if (d.kind === 'error') testErrors.push(d.message);
          if (d.kind === 'progress') testProgress.push(d.meta);
          if (d.kind === 'settled') window.testSettled = d.sequence;
          if (d.kind === 'complete') {
            const value = await KnitBatches.unpack(new Blob([d.buffer]));
            await KnitReceiver.accept(new Blob([d.buffer]));
            testCompleted.push(value.index);
            testEngine.postMessage({ kind: 'saved', key: d.key, task: value.manifest.id, index: value.index });
          }
        };
      });
    }
    async function feed(base64) {
      await reader.evaluate(async encoded => {
        const bytes = Uint8Array.from(atob(encoded), c => c.charCodeAt(0));
        for (let offset = 0; offset < bytes.length; offset += 7500) {
          const chunk = bytes.slice(offset, offset + 7500), sequence = ++testSequence;
          testEngine.postMessage({ kind: 'collect', mode: 68, bytes: chunk, sequence }, [chunk.buffer]);
          const deadline = performance.now() + 10000;
          while (window.testSettled !== sequence && !testErrors.length && performance.now() < deadline) await new Promise(r => setTimeout(r, 5));
          if (testErrors.length) throw new Error(testErrors.join('; '));
          if (window.testSettled !== sequence) throw new Error('Collector stalled');
        }
      }, base64);
    }
    await engine();
    await feed(fixtures[0].left); await feed(fixtures[1].left);
    assert.deepEqual(await reader.evaluate(() => testCompleted), []);
    const saved = await reader.evaluate(() => KnitStore.skeins());
    assert.equal(saved.length, 2); assert(saved.every(s => s.count > 0 && s.progress > .4 && s.progress < .7));
    await reader.evaluate(async () => {
      const pending = (await KnitStore.skeins()).find(s => s.key.startsWith('pending:'));
      if (!pending) throw new Error('B must be retained even without systematic symbol zero');
      const symbols = await KnitStore.stitches(pending.key);
      const damaged = symbols.find(s => s.block === 400); damaged.bytes[6] ^= 1;
      await KnitStore.journal({ ...pending, key: 'pending:damaged-candidate' }, symbols);
    });
    // Browser process and WASM are destroyed: replay must reconstruct from disk.
    await context.close();
    context = await chromium.launchPersistentContext(profile, { channel: 'chrome', headless: true });
    reader = await context.newPage(); await reader.goto(url); await engine();
    await feed(fixtures[0].right);
    await reader.waitForFunction(() => testCompleted.includes(0));
    assert.equal(await reader.locator('#gathered').textContent(), '1 / 2');
    await feed(fixtures[1].right);
    await reader.locator('#saveArea').waitFor({ state: 'visible' });
    assert.equal(await reader.evaluate(async () => KnitBatches.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), createHash('sha256').update(input).digest('hex'));
    assert(await reader.evaluate(async () => (await KnitStore.stitches('pending:damaged-candidate')).length > 0), 'An invalid trial must not overwrite or remove the prior journal');
    assert(fixtures.every(s => s.counts.every(n => n < s.n)), 'Neither replay alone may have enough symbols');
    console.log('PASS: unchanged sender, 2 x 1MiB native images, A partial -> B partial (symbol zero missed) -> browser-process restart -> changed-ID replays; invalid candidate retained; neither replay sufficient alone; exact assembled SHA-256. Wire IDs:', fixtures.map(s => s.ids));
  } finally { await context.close(); fs.rmSync(profile, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
