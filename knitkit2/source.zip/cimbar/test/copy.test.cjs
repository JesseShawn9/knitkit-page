const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.resolve(__dirname, '../dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext({ permissions: ['clipboard-read', 'clipboard-write'] });
    await context.addInitScript(() => { navigator.mediaDevices.getUserMedia = () => new Promise(() => {}); });
    const page = await context.newPage(); await page.goto('http://127.0.0.1:' + server.address().port);
    await page.evaluate(async () => {
      window.sample = new File([new Uint8Array(9000)], 'copy.bin'); window.sampleManifest = await B.prepare(sample, 3000);
      await KnitReceiver.accept(await B.packet(sample, sampleManifest, 0));
    });
    await page.locator('#read').click();
    await page.evaluate(() => {
      markReading(); window.originalPut = KnitStore.put;
      KnitStore.put = async (...args) => { await new Promise(resolve => { window.releaseSave = resolve; }); return originalPut(...args); };
    });
    await page.evaluate(async () => enqueueCandidate({ name: 'second', blob: await B.packet(sample, sampleManifest, 1) }));
    await page.waitForFunction(() => pending === 1 && !!window.releaseSave);
    assert(await page.locator('#copyIDs').isEnabled(), 'Saving cannot disable live missing-ID copying');
    await page.locator('#copyIDs').click();
    assert.equal(await page.evaluate(() => navigator.clipboard.readText()), '2-3', 'Real clipboard receives the missing IDs');
    await page.evaluate(() => { navigator.clipboard.writeText = async () => { throw new Error('Denied'); }; });
    await page.locator('#copy').click();
    assert.equal(await page.evaluate(() => navigator.clipboard.readText()), await page.evaluate(() => B.mending(sampleManifest, have)), 'Synchronous copy works when async clipboard is denied');
    assert.equal(await page.evaluate(() => reading && pending === 1), true);
    await page.evaluate(() => { document.execCommand = () => false; navigator.clipboard.writeText = async text => { window.asyncCopy = text; }; });
    await page.locator('#copyIDs').click(); assert.equal(await page.evaluate(() => asyncCopy), '2-3');
    await page.evaluate(() => { navigator.clipboard.writeText = async () => { throw new Error('Denied'); }; });
    await page.locator('#copy').click();
    assert.equal(await page.locator('#stateTitle').textContent(), 'Copy selected text');
    assert(await page.locator('#mending').isVisible());
    assert(await page.locator('#mending').evaluate(el => el === document.activeElement && el.selectionEnd === el.value.length));
    await page.evaluate(() => { releaseSave(); }); await page.waitForFunction(() => pending === 0);
    await page.locator('#read').click(); await context.close();
    console.log('PASS: real clipboard bytes, sync copy under denied async permission, async fallback, honest manual fallback, live copying during slow save and uninterrupted reading');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
