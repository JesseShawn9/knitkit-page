const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 393, height: 852 } }), requests = [], errors = [];
    page.on('request', r => requests.push(r.url())); page.on('pageerror', e => { console.error(e.stack); errors.push(e.message); });
    await page.addInitScript(() => {
      if (window !== parent) {
        const listen = HTMLVideoElement.prototype.addEventListener;
        HTMLVideoElement.prototype.addEventListener = function (type, ...args) {
          if (!['playing', 'loadeddata', 'canplay', 'resize', 'timeupdate'].includes(type)) return listen.call(this, type, ...args);
        };
        return;
      }
      window.testConstraints = []; window.testStreams = [];
      navigator.mediaDevices.getUserMedia = async constraints => {
        await new Promise(resolve => setTimeout(resolve, 500));
        testConstraints.push(constraints);
        const c = document.createElement('canvas'); c.width = 1920; c.height = 1080;
        const ctx = c.getContext('2d'), paint = () => { ctx.fillStyle = '#345678'; ctx.fillRect(0, 0, c.width, c.height); };
        paint(); const stream = c.captureStream(15); testStreams.push(stream); setInterval(paint, 100); return stream;
      };
    });
    const base = 'http://127.0.0.1:' + server.address().port;
    await page.goto(base);
    assert.equal(await page.evaluate(() => testConstraints.length), 0);
    await page.locator('#read').click(); await page.waitForFunction(() => reading);
    assert.equal(await page.locator('#stateTitle').textContent(), 'Looking for pattern', 'Live video is detected even when readiness events are missed');
    assert.equal(await page.locator('#partial').textContent(), '0%', 'Metadata readiness must not pretend to decode a frame');
    let native = page.frames().find(f => f.parentFrame());
    assert.deepEqual(await native.evaluate(() => [innerWidth, innerHeight]), [393, 852]);
    assert.equal(await native.locator('#mode-val').textContent(), 'B');
    assert.equal(await native.locator('#progress_bars').count(), 1);
    const before = await native.evaluate(() => ({ frame: String(Recv.on_frame), decode: String(Recv.on_decode), media: String(matchMedia) }));
    assert(!before.frame.includes('await vf.copyTo')); assert(!before.decode.includes('shellSequence')); assert(!before.media.includes('parent'));
    assert.equal((await page.evaluate(() => testConstraints[0])).video.aspectRatio, 9 / 16);
    await page.locator('#read').click(); await page.waitForTimeout(1200);
    assert(await page.evaluate(() => testStreams.every(s => s.getTracks().every(t => t.readyState === 'ended'))));
    assert.equal(await page.evaluate(() => testConstraints.length), 1, 'Disposed original page must not reopen the camera');
    await page.setViewportSize({ width: 852, height: 393 });
    await page.locator('#read').click(); await page.waitForFunction(() => reading);
    native = page.frames().find(f => f.parentFrame());
    assert.deepEqual(await native.evaluate(() => [innerWidth, innerHeight]), [852, 393]);
    assert.equal((await page.evaluate(() => testConstraints[1])).video.aspectRatio, 16 / 9);
    await page.locator('#read').click();
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    assert(requests.every(url => url.startsWith(base) || url.startsWith('blob:')), 'Bundled page must not fetch assets or send pixels externally');
    assert.deepEqual(errors, []);
    console.log('PASS: original mobile viewport/orientation and Auto/B controls; no capture/decode overrides, no external assets, explicit start, pause disposal and no watchdog reopen');
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; }).finally(() => server.close());
