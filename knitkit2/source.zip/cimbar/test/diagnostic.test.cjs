const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 393, height: 852 } }), requests = [], errors = [];
    page.on('request', request => requests.push(request.url())); page.on('pageerror', error => errors.push(error.message));
    await page.addInitScript(() => {
      if (window === parent) return;
      navigator.mediaDevices.getUserMedia = async () => {
        const c = document.createElement('canvas'); c.width = 1920; c.height = 1080;
        const ctx = c.getContext('2d');
        const paint = () => { ctx.fillStyle = '#345678'; ctx.fillRect(0, 0, c.width, c.height); };
        paint(); const stream = c.captureStream(15); setInterval(paint, 100); return stream;
      };
    });
    const base = 'http://127.0.0.1:' + server.address().port;
    await page.goto(base);
    assert.equal(await page.locator('#diagnose').isEnabled(), false);
    await page.locator('#readDetails summary').click(); await page.locator('#read').click();
    await page.waitForFunction(() => document.querySelector('#pipelineCounts').textContent.split(' / ').every(v => Number(v) >= 15));
    assert.equal(await page.locator('#frames').textContent(), '0');
    assert.equal(await page.locator('#decodeResult').textContent(), '图案提取失败');
    assert.equal(await page.locator('#stateTitle').textContent(), '画面已处理，但尚未解码');
    assert.equal(await page.locator('#saveDiagnostic').isVisible(), false, 'Never record frames automatically');
    await page.locator('#diagnose').click();
    await page.locator('#saveDiagnostic').waitFor({ state: 'visible' });
    const report = await page.evaluate(async () => (await fetch(document.querySelector('#saveDiagnostic').href)).json());
    assert.equal(report.kind, 'knitkit2-camera-diagnostic'); assert.equal(report.capture, 'await-copy-visible-rect');
    assert.deepEqual([report.input.width, report.input.height, report.input.format], [1920, 1080, 'RGBA']);
    const pixels = Buffer.from(report.pixels, 'base64');
    assert.equal(pixels.length, report.input.byteLength); assert.equal(pixels.length, 1920 * 1080 * 4);
    assert(pixels[0] > 0 && pixels[1] > pixels[0] && pixels[2] > pixels[1]); assert.equal(pixels[3], 255);
    assert(report.pipeline.extractFailed > 0); assert.equal(report.pipeline.decoded, 0);
    assert(!JSON.stringify(report).includes('manifest'));
    assert(requests.every(url => url.startsWith(base) || url.startsWith('blob:')), 'Diagnostics must not send frames to a server');
    await page.locator('#pause').click(); assert.equal(await page.locator('#diagnose').isEnabled(), false);
    assert.equal(await page.locator('#saveDiagnostic').isVisible(), true, 'Allow saving an already captured diagnostic after Pause');
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    await page.screenshot({ path: '/private/tmp/knitkit2-diagnostic-mobile.png', fullPage: true });
    assert.deepEqual(errors, []);
    console.log('PASS: real worker returns shown for undecodable camera input; one explicit raw pixel export; exact geometry/byte count, no automatic collection/upload, pause and mobile layout');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
