const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { randomBytes } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
require('../src/batches.js');
const B = globalThis.KnitBatches, root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  const input = randomBytes(16384), file = new File([input], '连续接收.zip');
  const manifest = await B.prepare(file, 4096), packets = [];
  for (let i = 0; i < 4; i++) packets.push(Buffer.from(await (await B.packet(file, manifest, i)).arrayBuffer()).toString('base64'));
  const broken = new Uint8Array(Buffer.from(packets[1], 'base64')); broken[broken.length - 1] ^= 1;
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 393, height: 852 } });
    await page.addInitScript(() => {
      if (window !== parent) { navigator.mediaDevices.getUserMedia = () => new Promise(() => {}); return; }
      const timeout = setTimeout;
      window.setTimeout = (fn, ms, ...args) => timeout(fn, ms === 30000 ? 600 : ms, ...args);
      Object.defineProperty(navigator, 'clipboard', { value: { writeText: async text => { window.copied = text; } } });
    });
    await page.goto('http://127.0.0.1:' + server.address().port);
    const send = data => page.evaluate(data => window.dispatchEvent(new MessageEvent('message', { source: document.querySelector('#nativeView').contentWindow, origin: location.origin, data: { ...data, knitNative: true, session: nativeEpoch } })), data);
    const sendPart = async text => {
      await page.evaluate(text => window.dispatchEvent(new MessageEvent('message', { source: document.querySelector('#nativeView').contentWindow, origin: location.origin, data: { knitNative: true, session: nativeEpoch, kind: 'file', blob: new Blob([Uint8Array.from(atob(text), c => c.charCodeAt(0))]) } })), text);
      await page.waitForFunction(() => pending === 0);
    };
    await page.locator('#read').click();
    await page.waitForTimeout(750);
    assert.equal(await page.evaluate(() => starting && engineRequested), true, 'No startup notification must not shut down the original page');
    const epoch = await page.evaluate(() => nativeEpoch);
    await sendPart(packets[0]);
    assert.equal(await page.evaluate(() => reading && !starting), true, 'A completed file is readiness evidence without a playing event');
    await send({ kind: 'progress', report: [.25] });
    assert.equal(await page.locator('#missingText').inputValue(), '2-4');
    await page.locator('#copyIDs').click();
    assert.equal(await page.evaluate(() => copied), '2-4');
    await page.locator('#copy').click();
    assert.equal(await page.evaluate(() => copied), 'KK2M:' + manifest.id + ':2-4');
    assert.equal(await page.evaluate(() => reading), true, 'Copy must not pause or dispose the engine');
    assert.equal(await page.evaluate(() => nativeEpoch), epoch);
    await page.evaluate(() => navigator.clipboard.writeText = async () => { throw new Error('Clipboard unavailable'); });
    await page.locator('#copy').click();
    assert.equal(await page.locator('#mending').inputValue(), 'KK2M:' + manifest.id + ':2-4');
    assert.equal(await page.locator('#mending').isVisible(), true);
    assert.equal(await page.evaluate(() => reading), true);
    await page.evaluate(() => { document.querySelector('#codeField').classList.remove('copy-fallback'); });
    await page.locator('#copyIDs').click();
    assert.equal(await page.locator('#missingText').evaluate(el => el === document.activeElement && el.selectionStart === 0 && el.selectionEnd === el.value.length), true);
    assert.equal(await page.evaluate(() => reading && nativeEpoch), epoch, 'ID fallback also keeps the camera session alive');
    await page.evaluate(() => {
      window.storedPart = KnitStore.part;
      KnitStore.part = async (id, index) => index === 1 ? new Blob(['failed readback']) : storedPart(id, index);
    });
    await sendPart(packets[1]);
    assert.equal(await page.evaluate(() => reading && have.size === 1), true, 'A failed save readback must not count as saved or stop scanning');
    assert.match(await page.locator('#stateHint').textContent(), /Length mismatch/);
    await page.evaluate(() => { KnitStore.part = storedPart; });
    assert.equal(await page.evaluate(async () => await KnitStore.part(manifest.id, 1)), undefined);
    await sendPart(Buffer.from(broken).toString('base64'));
    assert.equal(await page.evaluate(() => reading && have.size === 1), true, 'Corrupt completed candidate is nonfatal and never counted');
    await sendPart(packets[2]); await sendPart(packets[3]);
    assert.equal(await page.locator('#missingText').inputValue(), '2');
    await page.waitForTimeout(750);
    assert.equal(await page.evaluate(() => reading && nativeEpoch), epoch, 'Reception continues past the old watchdog');
    await page.evaluate(async ({ m, rest }) => {
      await KnitStore.put(m, 0, new Blob(['corrupt stored bytes']));
      await KnitStore.put(m, 2, new Blob(['another corrupt stored part']));
      for (const text of rest) await KnitReceiver.accept(new Blob([Uint8Array.from(atob(text), c => c.charCodeAt(0))]));
    }, { m: manifest, rest: [packets[1]] });
    assert.equal(await page.locator('#missingText').inputValue(), '1,3');
    assert.equal(await page.evaluate(() => reading && have.size === 2), true, 'All corrupt stored parts become missing in one verification pass while the camera stays open');
    assert.equal(await page.evaluate(async () => !!await KnitStore.part(manifest.id, 0)), false);
    assert.equal(await page.evaluate(async () => !!await KnitStore.part(manifest.id, 2)), false);
    await page.screenshot({ path: '/private/tmp/knitkit2-continuous-mobile.png' });
    await sendPart(packets[0]);
    assert.equal(await page.locator('#missingText').inputValue(), '3');
    await sendPart(packets[2]); await page.locator('#saveArea').waitFor({ state: 'visible' });
    assert.equal(await page.evaluate(async () => KnitBatches.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), await B.hash(input));
    assert.equal(await page.evaluate(() => reading), false, 'Stop only after the entire file has been verified and assembled');
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    await page.reload(); await page.locator('#read').click();
    await send({ kind: 'progress', report: [.1] }); await page.waitForTimeout(750);
    assert.equal(await page.evaluate(() => reading && !starting), true, 'Progress alone cancels the startup wait without a playing event');
    await page.locator('#read').click();
    console.log('PASS: silent/late playing notification, nonfatal startup timer, continuous parts, live missing/copy, bad candidate skip, stored-part repair, final hash and stop-on-complete');
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; }).finally(() => server.close());
