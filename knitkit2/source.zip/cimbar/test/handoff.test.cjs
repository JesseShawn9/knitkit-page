const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { randomBytes } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
require('../src/batches.js');
const B = globalThis.KnitBatches, root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  const input = randomBytes(6 * 4096), file = new File([input], 'handoff.bin'), manifest = await B.prepare(file, 4096), packets = [];
  for (let i = 0; i < 6; i++) packets.push(Buffer.from(await (await B.packet(file, manifest, i)).arrayBuffer()).toString('base64'));
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage();
    await page.addInitScript(() => { if (window !== parent) navigator.mediaDevices.getUserMedia = () => new Promise(() => {}); });
    await page.goto('http://127.0.0.1:' + server.address().port);
    const send = data => page.evaluate(data => window.dispatchEvent(new MessageEvent('message', {
      source: document.querySelector('#nativeView').contentWindow, origin: location.origin,
      data: { knitNative: true, session: nativeEpoch, ...data, ...(data.text ? { blob: new Blob([Uint8Array.from(atob(data.text), c => c.charCodeAt(0))]) } : {}) }
    })), data);
    await page.locator('#read').click(); await send({ kind: 'camera' });
    await page.evaluate(() => window.dispatchEvent(new MessageEvent('message', {
      source: document.querySelector('#nativeView').contentWindow, origin: location.origin,
      data: { knitNative: true, session: nativeEpoch, kind: 'file', blob: new Blob(Array(49).fill(new Uint8Array(1048576))) }
    })));
    assert.equal(await page.evaluate(() => pending === 0 && candidateBytes === 0), true, 'Byte budget rejects oversized candidates before validation');
    await page.evaluate(() => {
      window.originalUnpack = B.unpack;
      B.unpack = async blob => { await new Promise(resolve => { window.releaseCandidate = resolve; }); return originalUnpack(blob); };
    });
    await send({ kind: 'file', name: '1', text: packets[0] }); await page.waitForFunction(() => !!window.releaseCandidate);
    await send({ kind: 'file', name: '1', text: packets[0] });
    assert.equal(await page.evaluate(() => pending), 1, 'Duplicate in-flight candidate is not retained twice');
    for (let i = 1; i < 6; i++) await send({ kind: 'file', name: String(i + 1), text: packets[i] });
    assert.equal(await page.evaluate(() => pending), 4, 'Slow storage cannot create an unbounded completed-file queue');
    assert.equal(await page.evaluate(() => candidates.length), 3);
    await send({ kind: 'stalled' });
    assert.equal(await page.evaluate(() => recoveryNeeded && reading), true, 'Recovery must wait for in-progress verified persistence');
    const oldEpoch = await page.evaluate(() => nativeEpoch);
    await page.evaluate(() => { B.unpack = originalUnpack; releaseCandidate(); });
    await page.waitForFunction(epoch => nativeEpoch > epoch && starting && pending === 0, oldEpoch);
    assert.deepEqual(await page.evaluate(() => [have.size, candidates.length, candidateBytes, candidateNames.size]), [4, 0, 0, 0], 'Completed candidate references and duplicate keys are released before automatic recovery');
    assert.equal(await page.locator('#missingText').inputValue(), '5-6');
    await send({ kind: 'file', session: oldEpoch, name: '5', text: packets[4] });
    assert.equal(await page.evaluate(() => have.size), 4, 'Discarded native page cannot enqueue a late candidate');
    await send({ kind: 'camera' });
    await send({ kind: 'stalled' }); await page.waitForFunction(() => starting);
    await send({ kind: 'camera' }); await send({ kind: 'stalled' });
    assert.equal(await page.evaluate(() => !reading && !starting && have.size === 4), true, 'Repeated true failures stop automatic restart loops without losing saved parts');
    await page.locator('#read').click(); await send({ kind: 'camera' });
    const bad = new Uint8Array(Buffer.from(packets[4], 'base64')); bad[bad.length - 1] ^= 1;
    await send({ kind: 'file', name: 'bad', text: Buffer.from(bad).toString('base64') }); await page.waitForFunction(() => pending === 0);
    assert.deepEqual(await page.evaluate(() => [reading, have.size, candidateBytes, candidateNames.size]), [true, 4, 0, 0], 'Rejected content is released and remains missing without pausing normal scanning');
    await page.evaluate(() => {
      B.unpack = async blob => { await new Promise(resolve => { window.releaseCandidate = resolve; }); return originalUnpack(blob); };
    });
    await send({ kind: 'file', name: '5', text: packets[4] });
    await send({ kind: 'file', name: '6', text: packets[5] });
    await page.locator('#read').click();
    assert.deepEqual(await page.evaluate(() => [pending, candidates.length, candidateNames.size]), [1, 0, 1], 'Pause drops queued transient candidates but permits the active persistence to finish');
    await page.evaluate(() => { B.unpack = originalUnpack; releaseCandidate(); }); await page.waitForFunction(() => pending === 0);
    assert.equal(await page.evaluate(() => have.size), 5);
    await page.locator('#read').click(); await send({ kind: 'camera' });
    await send({ kind: 'file', name: '6', text: packets[5] }); await page.waitForFunction(() => pending === 0);
    assert.equal(await page.locator('#saveArea').isVisible(), true);
    assert.deepEqual(await page.evaluate(() => [candidates.length, candidateBytes, candidateNames.size]), [0, 0, 0]);
    assert.equal(await page.evaluate(async () => B.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), await B.hash(input));
    console.log('PASS: bounded save queue, in-flight duplicate suppression, released failed/saved candidates, deferred stall recovery, retry cap, stale-session rejection and exact final output');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
