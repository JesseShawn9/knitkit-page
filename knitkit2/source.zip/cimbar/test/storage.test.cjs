const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'text/html');
  res.end(req.url === '/blank' ? '<!doctype html><title>Storage fixture</title>' : fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html')));
});
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext(), page = await context.newPage();
    const url = 'http://127.0.0.1:' + server.address().port;
    await page.goto(url + '/blank');
    await page.evaluate(async () => {
      await new Promise((resolve, reject) => {
        const r = indexedDB.open('knitkit2-batches', 1);
        r.onupgradeneeded = () => {
          r.result.createObjectStore('tasks', { keyPath: 'id' });
          r.result.createObjectStore('parts', { keyPath: ['id', 'index'] }).createIndex('task', 'id');
        };
        r.onerror = () => reject(r.error);
        r.onsuccess = () => {
          const tx = r.result.transaction(['tasks', 'parts'], 'readwrite');
          tx.objectStore('tasks').put({ id: 'legacy', manifest: { name: 'legacy.bin' }, updated: 1 });
          tx.objectStore('parts').put({ id: 'legacy', index: 0, data: new Blob(['old bytes']) });
          tx.oncomplete = () => { r.result.close(); resolve(); };
        };
      });
    });
    await page.goto(url);
    const result = await page.evaluate(async () => {
      const old = await KnitStore.part('legacy', 0);
      const m = await KnitBatches.prepare(new File(['new bytes'], 'new.bin'), 300);
      await KnitStore.remember(m);
      const meta = { key: 'test-skein', task: m.id, mode: 68, count: 2, progress: .4 };
      await KnitStore.journal(meta, [{ block: 0, bytes: new Uint8Array([1, 2]) }, { block: 1, bytes: new Uint8Array([3, 4]) }]);
      await KnitStore.journal({ ...meta, progress: .5 }, [{ block: 1, bytes: new Uint8Array([3, 4]) }]);
      const restored = await KnitStore.stitches(meta.key), metadata = await KnitStore.skeins();
      await KnitStore.remove(m.id);
      return { old: await old.text(), restored: restored.length, progress: metadata[0].progress, empty: (await KnitStore.skeins()).length === 0 && (await KnitStore.stitches(meta.key)).length === 0, oldStillThere: !!await KnitStore.part('legacy', 0) };
    });
    assert.deepEqual(result, { old: 'old bytes', restored: 2, progress: .5, empty: true, oldStillThere: true });
    const conflict = await page.evaluate(async () => {
      const source = new TextDecoder().decode(Uint8Array.from(atob(document.querySelector('#readerSource').textContent.trim()), c => c.charCodeAt(0)));
      const url = URL.createObjectURL(new Blob(['var knitRole="collector";\n', source], { type: 'text/javascript' }));
      const worker = new Worker(url); URL.revokeObjectURL(url);
      let step = 0, notices = 0;
      await new Promise((resolve, reject) => {
        worker.onerror = e => reject(new Error(e.message));
        worker.onmessage = e => {
          const d = e.data;
          if (d.kind === 'error') reject(new Error(d.message));
          if (d.kind === 'notice') notices++;
          if (d.kind === 'settled' && ++step === 2) { resolve(); return; }
          if (d.kind === 'ready' || d.kind === 'settled') {
            const bytes = new Uint8Array(625); bytes[0] = 7; bytes[1] = 1; bytes[5] = 1; bytes[6] = step ? 9 : 0;
            worker.postMessage({ mode: 68, bytes, sequence: step + 1 });
          }
        };
      });
      worker.terminate();
      const skeins = await KnitStore.skeins(), contents = [];
      for (const s of skeins) contents.push((await KnitStore.stitches(s.key))[0].bytes[6]);
      for (const s of skeins) await KnitStore.dropSkein(s.key);
      return { notices, contents: contents.sort() };
    });
    assert.deepEqual(conflict, { notices: 1, contents: [0, 9] }, 'Conflicting symbol bytes must fork, never overwrite a saved symbol');
    const quota = await page.evaluate(async () => {
      const source = new TextDecoder().decode(Uint8Array.from(atob(document.querySelector('#readerSource').textContent.trim()), c => c.charCodeAt(0)));
      const patch = '\nKnitStore.journal=async()=>{throw new Error("本地任务保存失败，可能空间不足。");};';
      const url = URL.createObjectURL(new Blob(['var knitRole="collector";\n', source, patch], { type: 'text/javascript' }));
      const worker = new Worker(url); URL.revokeObjectURL(url);
      return new Promise((resolve, reject) => {
        worker.onerror = e => { worker.terminate(); reject(new Error(e.message)); };
        worker.onmessage = e => {
          if (e.data.kind === 'ready') {
            const bytes = new Uint8Array(625); bytes[0] = 7; bytes[1] = 1; bytes[5] = 1;
            worker.postMessage({ kind: 'collect', mode: 68, sequence: 1, bytes });
          } else if (e.data.kind === 'error') { worker.terminate(); resolve(e.data.message); }
          else if (e.data.kind === 'complete' || e.data.kind === 'progress') { worker.terminate(); reject(new Error('Unsaved data must not report progress')); }
        };
      });
    });
    assert.match(quota, /空间不足/);
    console.log('PASS: v1 -> v2 storage upgrade preserves old parts; journal upsert, restoration, task-scoped removal; quota failure never reports unsaved progress');
    await context.close();
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
