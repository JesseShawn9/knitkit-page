const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext(), sender = await context.newPage();
    await sender.goto('file://' + path.join(root, 'dist/knitkit2.html')); await sender.waitForFunction(() => initialized);
    const input = randomBytes(140 * 16384);
    await sender.locator('#pattern').setInputFiles({ name: 'many.bin', mimeType: 'application/octet-stream', buffer: input });
    await sender.waitForFunction(() => ready && !preparing);
    const built = fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'), 'utf8');
    const embedded = id => Buffer.from(built.match(new RegExp('<script id="' + id + '"[^>]*>([\\s\\S]*?)<\\/script>'))[1], 'base64').toString();
    const fixtures = await sender.evaluate(async workerSource => {
      manifest = await KnitBatches.prepare(file, 16384); order = manifest.hashes.map((_, i) => i);
      const canvas = document.querySelector('#canvas'), copy = document.createElement('canvas'); copy.width = copy.height = 1040;
      const ctx = copy.getContext('2d', { willReadFrequently: true });
      const sets = [], url = URL.createObjectURL(new Blob([workerSource], { type: 'text/javascript' })), worker = new Worker(url); URL.revokeObjectURL(url);
      await new Promise((resolve, reject) => { worker.onmessage = e => { if (e.data.ready) resolve(); }; worker.onerror = e => reject(new Error(e.message)); });
      function extract(pixels) { return new Promise(resolve => { worker.onmessage = e => resolve(e.data.buff); worker.postMessage({ pixels, format: 'RGBA', width: 1040, height: 1040, mode: 68 }, [pixels.buffer]); }); }
      try {
        for (let i = 0; i < 140; i++) {
          await selectBatch(i); const frames = [];
          for (let f = 0; frames.length < 5 && f < 20; f++) {
            Module._cimbare_render(); ctx.drawImage(canvas, 0, 0);
            const bytes = await extract(ctx.getImageData(0, 0, 1040, 1040).data);
            if (bytes && bytes.length) frames.push(Array.from(bytes)); Module._cimbare_next_frame(false);
          }
          if (frames.length !== 5) throw new Error('No native extraction for segment ' + i);
          sets.push(frames);
        }
        return sets;
      } finally { worker.terminate(); }
    }, 'var console={log:()=>{},info:()=>{},error:()=>{},warn:()=>{}};\n' + embedded('readerSource') + ';\n' + embedded('nativeRuntime'));
    const reader = await context.newPage();
    await reader.addInitScript(() => {
      if (window === parent) return;
      navigator.mediaDevices.getUserMedia = async () => { const c = document.createElement('canvas'); c.width = 1920; c.height = 1080; return c.captureStream(15); };
    });
    await reader.goto('http://127.0.0.1:' + server.address().port); await reader.locator('#read').click();
    await reader.waitForFunction(() => document.querySelector('#nativeView').contentWindow.Module?._cimbard_get_bufsize);
    const engine = reader.frames().find(f => f.parentFrame());
    await engine.evaluate(() => { window.testModes = []; const original = Module._cimbard_configure_decode; Module._cimbard_configure_decode = mode => { testModes.push(mode); return original(mode); }; });
    const send = frames => engine.evaluate(items => { for (const bytes of items) Recv.on_decode(0, { buff: new Uint8Array(bytes), mode: 68 }); }, frames);
    for (let i = 0; i < fixtures.length; i++) {
      await send(fixtures[i]);
      await reader.waitForFunction(n => have.size === n, i + 1);
      if (i === fixtures.length - 2) assert(await engine.evaluate(() => testModes.length > 0 && testModes.every(mode => mode === 68)), 'Original B mode remains unchanged; no alternate-mode resets');
    }
    await reader.locator('#saveArea').waitFor({ state: 'visible', timeout: 30000 });
    assert.equal(await reader.evaluate(async () => KnitBatches.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), createHash('sha256').update(input).digest('hex'));
    assert.equal(new Set(fixtures.map(f => f[0][0] & 127)).size, 128, 'Native optical labels must wrap during the test');
    console.log('PASS: 140 sequential completed segments through unchanged native Sink/Zstd, seven-bit label wrap, no per-segment mode resets, exact final SHA-256');
    await context.close();
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; }).finally(() => server.close());
