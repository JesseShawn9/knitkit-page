const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const { test } = require('node:test');
test('warm camera waits for all original image workers and cancels retired requests', async () => {
  const workers = [], events = {}, calls = [], stream = {};
  const parent = { location: { origin: 'http://test' }, KnitNativeSources: { session: 3, worker: '', runtime: '' }, KnitCamera: { acquire: (constraints, session) => { calls.push({ constraints, session }); return stream; } }, postMessage() {} };
  const window = { Worker: function () {
    const listeners = {};
    const worker = { addEventListener(type, listener) { (listeners[type] ||= []).push(listener); }, emit(data) { for (const listener of listeners.message || []) listener({ data }); }, terminate() { this.ended = true; } };
    workers.push(worker); return worker;
  }, addEventListener: (name, fn) => { events[name] = fn; } };
  const navigator = { mediaDevices: { getUserMedia() { throw new Error('Camera may only be owned by the parent'); } } };
  const video = { readyState: 0, addEventListener() {} };
  const context = vm.createContext({ parent, window, navigator, DOMException, Blob, Recv: { render_progress() {} }, Zstd: {}, setInterval: () => 1, clearInterval() {}, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} }, document: { getElementById: () => video } });
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../src/native-bridge.js'), 'utf8'), context);
  for (let i = 0; i < 4; i++) new window.Worker('recv-worker.2026-08-21T2336.js');
  const constraints = Object.freeze({ audio: false, video: { frameRate: { ideal: 15 } } });
  const pending = navigator.mediaDevices.getUserMedia(constraints);
  for (let i = 0; i < 3; i++) workers[i].emit({ ready: true });
  await Promise.resolve(); assert.equal(calls.length, 0, 'Do not feed a warm camera to half-initialized image workers');
  workers[3].emit({ ready: true });
  assert.equal(await pending, stream); assert.equal(calls[0].constraints, constraints); assert.equal(calls[0].session, 3);
  events.message({ source: parent, origin: 'http://test', data: { knitShell: true, kind: 'pause' } });
  await assert.rejects(navigator.mediaDevices.getUserMedia(constraints), { name: 'AbortError' });
  assert.equal(calls.length, 1); assert(workers.every(worker => worker.ended));
});
