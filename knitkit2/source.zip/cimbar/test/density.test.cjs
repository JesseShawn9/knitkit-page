const { execFileSync } = require('node:child_process');
const path = require('node:path');
execFileSync(process.execPath, [path.join(__dirname, 'native.test.cjs')], {
  env: { ...process.env, KNIT_TEST_MODE: '66', KNIT_TEST_OUTPUT: '/private/tmp/cimbarplus-density-native' },
  stdio: 'inherit', timeout: 240000
});
