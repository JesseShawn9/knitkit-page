const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const { test } = require('node:test');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'), 'utf8');
const engine = Buffer.from(html.match(/<script id="nativeEngine"[^>]*>([\s\S]*?)<\/script>/)[1], 'base64').toString();
const source = engine.match(/<script>(var Sink =[\s\S]*?)<\/script>/)[1];

async function fixture(copy) {
  const sent = [], nodes = {}, events = [], callbacks = [];
  const frame = {
    format: 'NV12', displayWidth: 4, displayHeight: 8,
    visibleRect: { x: 0, y: 0, width: 8, height: 4 },
    allocationSize: () => 48,
    copyTo: pixels => copy(pixels, events),
    close: () => events.push('closed')
  };
  const video = { srcObject: null, play() {}, requestVideoFrameCallback(cb) { callbacks.push(cb); } };
  const context = vm.createContext({
    console, Uint8Array, VideoFrame: function () { return frame; },
    navigator: { userAgent: 'test', maxTouchPoints: 0, mediaDevices: { getUserMedia: async () => ({}) } },
    matchMedia: () => ({ matches: false }),
    document: { getElementById: id => nodes[id] ||= {} },
    Worker: function () { this.postMessage = data => { events.push('sent'); sent.push(data); }; },
    window: { addEventListener() {} }
  });
  vm.runInContext(source, context);
  context.Recv.update_visual_state = () => {};
  context.Recv.on_capture_error = error => events.push('error:' + error.message);
  context.Recv.init(video, 4); await Promise.resolve();
  return { sent, events, nodes, callbacks, run: () => context.Recv.on_frame(1, {}) };
}

test('copy completion precedes worker transfer and VideoFrame close', async () => {
  let complete;
  const f = await fixture((pixels, events) => new Promise(resolve => {
    complete = () => { pixels.fill(77); events.push('copied'); resolve([{ offset: 0, stride: 8 }]); };
  }));
  const pending = f.run();
  assert.equal(f.sent.length, 0, 'Do not transfer an unfilled buffer to a worker');
  assert(!f.events.includes('closed'), 'Keep the frame alive until the asynchronous copy completes');
  complete(); await pending;
  assert.equal(f.sent[0].pixels[0], 77);
  assert.deepEqual(f.events, ['copied', 'sent', 'closed']);
});

test('raw copied geometry follows visibleRect, not rotated display dimensions', async () => {
  const f = await fixture(pixels => { pixels.fill(55); return Promise.resolve([]); });
  await f.run();
  assert.equal(f.sent[0].width, 8);
  assert.equal(f.sent[0].height, 4);
  assert.equal(f.sent[0].format, 'NV12');
});

test('a failed pixel copy releases the queue slot and reports the failure', async () => {
  const f = await fixture(() => { throw new Error('copy unavailable'); });
  await f.run();
  assert.equal(f.sent.length, 0);
  assert.equal(f.nodes.framesInFlight.innerHTML, 0);
  assert(f.events.includes('error:copy unavailable'));
  assert(f.events.includes('closed'));
  assert.equal(f.callbacks.length, 2, 'Capture remains scheduled after a failed frame');
});
