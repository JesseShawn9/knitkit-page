const assert = require('node:assert/strict');
const { test } = require('node:test');
require('../src/image-pool.js');
test('image workers stay warm while old leases, queued frames and late responses are discarded', async () => {
  const physical = [];
  const pool = KnitImagePool.create(() => {
    const worker = new EventTarget(); worker.sent = []; worker.stops = 0;
    worker.postMessage = (...args) => worker.sent.push(args); worker.terminate = () => worker.stops++;
    physical.push(worker); return worker;
  });
  const old = pool.borrow('blob:test'), first = physical[0], oldResults = [];
  old.onmessage = event => oldResults.push(event.data);
  const emit = data => first.dispatchEvent(new MessageEvent('message', { data }));
  emit({ ready: true });
  const bytes = new Uint8Array([1, 2, 3]); old.postMessage({ pixels: bytes }, [bytes.buffer]);
  old.postMessage({ pixels: new Uint8Array([4]) });
  assert.equal(first.sent.length, 1, 'Only one frame per physical worker may be in flight');
  assert.equal(first.sent[0][0].pixels, bytes, 'No pixel or mode rewriting');
  pool.retire();
  const fresh = pool.borrow('blob:fresh'), results = []; fresh.onmessage = event => results.push(event.data);
  await Promise.resolve(); assert.deepEqual(results, [{ ready: true }]);
  fresh.postMessage({ pixels: new Uint8Array([5]) });
  emit({ buff: new Uint8Array([9]) });
  assert.equal(oldResults.length, 1, 'Late old response cannot reenter retired decoder');
  assert.equal(results.length, 1, 'Late old response cannot enter the new decoder');
  assert.equal(first.sent.length, 2, 'Old queued frame was dropped, not replayed');
  assert.deepEqual(Array.from(first.sent[1][0].pixels), [5]);
  const current = { buff: new Uint8Array([6]), mode: 68 }; emit(current);
  assert.equal(results[1], current, 'New results pass through unchanged');
  for (let i = 0; i < 40; i++) { pool.retire(); pool.borrow('blob:next'); }
  assert.equal(physical.length, 1); assert.equal(first.stops, 0);
  pool.clear(); assert.equal(first.stops, 1);
  pool.borrow('blob:new'); assert.equal(physical.length, 2);
  pool.clear();
});
test('pool owns at most four physical workers and honors all four readiness events', () => {
  const workers = [], ready = [];
  const pool = KnitImagePool.create(() => {
    const worker = new EventTarget(); worker.postMessage = () => {}; worker.terminate = () => {};
    workers.push(worker); return worker;
  });
  for (let i = 0; i < 4; i++) { const lease = pool.borrow('blob:test'); lease.onmessage = event => ready.push(event.data); }
  assert.throws(() => pool.borrow('blob:extra'), /limit/);
  for (const worker of workers) worker.dispatchEvent(new MessageEvent('message', { data: { ready: true } }));
  assert.equal(ready.length, 4); pool.clear();
});
