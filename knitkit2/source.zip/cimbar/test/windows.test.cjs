const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext(), sender = await context.newPage();
    await sender.goto('file://' + path.join(root, 'dist/knitkit2.html')); await sender.waitForFunction(() => initialized);
    const input = randomBytes(10 * 65536);
    await sender.locator('#pattern').setInputFiles({ name: 'windows.bin', mimeType: 'application/octet-stream', buffer: input });
    await sender.waitForFunction(() => ready && !preparing);
    const html = fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'), 'utf8');
    const embedded = id => Buffer.from(html.match(new RegExp('<script id="' + id + '"[^>]*>([\\s\\S]*?)<\\/script>'))[1], 'base64').toString();
    const fixtures = await sender.evaluate(async workerSource => {
      manifest = await B.prepare(file, 65536); order = manifest.hashes.map((_, i) => i);
      const canvas = document.querySelector('#canvas'), copy = document.createElement('canvas'); copy.width = copy.height = 1040;
      const ctx = copy.getContext('2d', { willReadFrequently: true }), sets = [];
      const url = URL.createObjectURL(new Blob([workerSource], { type: 'text/javascript' })), worker = new Worker(url); URL.revokeObjectURL(url);
      await new Promise((resolve, reject) => { worker.onmessage = e => e.data.ready && resolve(); worker.onerror = e => reject(new Error(e.message)); });
      try {
        for (let i = 0; i < 10; i++) {
          await selectBatch(i); const frames = [];
          for (let f = 0; frames.length < 18 && f < 36; f++) {
            Module._cimbare_render(); ctx.drawImage(canvas, 0, 0);
            const pixels = ctx.getImageData(0, 0, 1040, 1040).data;
            const bytes = await new Promise(resolve => { worker.onmessage = e => resolve(e.data.buff); worker.postMessage({ pixels, format: 'RGBA', width: 1040, height: 1040, mode: 68 }, [pixels.buffer]); });
            if (bytes?.length) frames.push(Array.from(bytes)); Module._cimbare_next_frame(false);
          }
          if (frames.length !== 18) throw new Error('No extracted fixture for ' + i); sets.push(frames);
        }
        return sets;
      } finally { worker.terminate(); }
    }, 'var console={log:()=>{},info:()=>{},error:()=>{},warn:()=>{}};\n' + embedded('readerSource') + ';\n' + embedded('nativeRuntime'));
    const reader = await context.newPage();
    await reader.addInitScript(() => {
      if (window === parent) { window.testStreams = []; return; }
      window.testEpoch = parent.KnitNativeSources?.session;
      navigator.mediaDevices.getUserMedia = async () => { const canvas = document.createElement('canvas'); canvas.width = 1920; canvas.height = 1080; const stream = canvas.captureStream(15); parent.testStreams.push(stream); return stream; };
    });
    await reader.goto('http://127.0.0.1:' + server.address().port); await reader.locator('#read').click();
    let engine;
    const readyEngine = async () => {
      await reader.waitForFunction(() => {
        const view = document.querySelector('#nativeView').contentWindow;
        return view.testEpoch === nativeEpoch && view.Module?._cimbard_get_bufsize;
      });
      engine = reader.frames().find(frame => frame.parentFrame());
    };
    const send = items => engine.evaluate(frames => {
      for (const bytes of frames) workers[0].dispatchEvent(new MessageEvent('message', { data: { buff: new Uint8Array(bytes), mode: 68 } }));
    }, items);
    const switchWindow = async index => {
      const epoch = await reader.evaluate(() => nativeEpoch);
      await send(fixtures[index].slice(0, 2)); await reader.waitForFunction(previous => nativeEpoch > previous, epoch);
      await readyEngine(); assert(await engine.evaluate(() => sources.session === parent.KnitNativeSources.session), 'A fresh native document must replace the old context');
      assert(await reader.evaluate(() => testStreams.slice(0, -1).every(stream => stream.getTracks().every(track => track.readyState === 'ended'))));
      assert.deepEqual(await engine.evaluate(() => Sink.get_report() || []), [], 'Fresh page cannot retain any old partial streams');
    };
    await readyEngine(); await send(fixtures[0]); await reader.waitForFunction(() => have.size === 1);
    for (let i = 1; i < 9; i++) {
      await switchWindow(i); await send(fixtures[i].slice(0, 1));
      await reader.waitForFunction(() => document.querySelector('#partialProgress').value > 0 && document.querySelector('#partialProgress').value < 1);
      assert.equal(await reader.evaluate(() => have.size), 1, 'Expired incomplete segments remain missing; saved segment survives');
      assert.equal(await engine.evaluate(() => Sink.get_report().length), 1);
    }
    await switchWindow(9); await send(fixtures[9]); await reader.waitForFunction(() => have.size === 2);
    await switchWindow(1); await send(fixtures[1].slice(0, 1));
    assert.equal(await reader.evaluate(() => have.size), 2, 'Returning to an earlier window must not resume its old native state');
    await send(fixtures[1]); await reader.waitForFunction(() => have.size === 3);
    for (let i = 2; i < 9; i++) { await switchWindow(i); await send(fixtures[i]); await reader.waitForFunction(n => have.size === n, i + 2); }
    await reader.locator('#saveArea').waitFor({ state: 'visible' });
    assert.equal(await reader.evaluate(async () => B.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), createHash('sha256').update(input).digest('hex'));
    await context.close();
    console.log('PASS: eight incomplete native windows discarded, automatic fresh workers/camera, saved parts retained, prior-window restart from zero, exact final assembly');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
