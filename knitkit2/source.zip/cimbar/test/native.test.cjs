const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const mode = process.env.KNIT_TEST_MODE || '68';
const reportDir = process.env.KNIT_TEST_OUTPUT || '/private/tmp/knitkit2-native-check';
fs.mkdirSync(reportDir, { recursive: true });
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const sender = await context.newPage();
    const senderPath = process.env.KNIT_SENDER_PATH || path.join(root, 'dist/knitkit2.html');
    await sender.goto('file://' + senderPath);
    await sender.waitForFunction(() => initialized);
    assert.equal(await sender.locator('#mode').inputValue(), '68', 'Fresh Encoder keeps the original B default');
    if (mode !== '68') await sender.locator('#mode').selectOption(mode);
    const input = randomBytes(2 * 1024 * 1024);
    await sender.locator('#pattern').setInputFiles({ name: '原版外壳-测试.zip', mimeType: 'application/zip', buffer: input });
    await sender.waitForFunction(() => ready && !preparing);
    assert.equal(await sender.locator('#fps').inputValue(), '15');
    assert.equal(await sender.locator('#mode').inputValue(), mode);
    const fixtures = await sender.evaluate(async frames => {
      const sets = [], canvas = document.querySelector('#canvas');
      const copy = document.createElement('canvas'), ctx = copy.getContext('2d');
      for (const index of [0, 1]) {
        await selectBatch(index); const images = [];
        copy.width = canvas.width; copy.height = canvas.height;
        for (let f = 0; f < frames; f++) { Module._cimbare_render(); ctx.drawImage(canvas, 0, 0); images.push(copy.toDataURL()); Module._cimbare_next_frame(false); }
        sets.push(images);
      }
      return sets;
    }, mode === '66' ? 340 : 180);
    const styledSource = await context.newPage(); await styledSource.goto('file://' + path.join(root, 'dist/knitkit2.html'));
    await styledSource.waitForFunction(() => initialized);
    await styledSource.locator('#pattern').setInputFiles({ name: '原版外壳-测试.zip', mimeType: 'application/zip', buffer: input });
    await styledSource.waitForFunction(() => ready && !preparing);
    await styledSource.screenshot({ path: path.join(reportDir, 'source-desktop.png') });
    const reader = await context.newPage(), errors = [];
    reader.on('pageerror', e => errors.push(e.message));
    await reader.addInitScript(() => {
      if (window === parent) { window.testStreams = []; window.testConstraints = []; return; }
      const canvas = document.createElement('canvas'); canvas.width = 1920; canvas.height = 1080;
      const ctx = canvas.getContext('2d'); ctx.fillStyle = '#333'; ctx.fillRect(0, 0, 1920, 1080);
      window.fixture = { canvas, ctx, constraints: [], epoch: parent.KnitNativeSources?.session };
      navigator.mediaDevices.getUserMedia = async constraints => { await new Promise(resolve => setTimeout(resolve, 500)); parent.testConstraints.push(constraints); fixture.stream = canvas.captureStream(15); parent.testStreams.push(fixture.stream); setTimeout(() => ctx.drawImage(canvas, 0, 0), 50); return fixture.stream; };
    });
    await reader.goto('http://127.0.0.1:' + server.address().port);
    await reader.locator('#read').click(); await reader.waitForFunction(() => reading).catch(async error => {
      console.log('SHELL', await reader.evaluate(() => ({ engineReady, starting, reading, hint: document.querySelector('#stateHint').textContent })));
      console.log('ERRORS', errors); throw error;
    });
    let native = reader.frames().find(f => f.parentFrame());
    let sawProgress = false, capturedNativeView = false;
    for (let phase = 0; phase < fixtures.length; phase++) {
      if (phase) {
        assert.equal(await reader.evaluate(() => reading), true, 'Camera must stay active between segments');
        assert.equal(await reader.locator('#gathered').textContent(), '1 / 2');
      }
      for (const image of fixtures[phase]) {
        await reader.waitForFunction(() => {
          const view = document.querySelector('#nativeView').contentWindow;
          return view.fixture?.epoch === nativeEpoch && view.Module?._cimbard_get_bufsize;
        });
        native = reader.frames().find(f => f.parentFrame());
        try { await native.evaluate(async src => { const image = new Image(); image.src = src; await image.decode(); const scale = Math.min(1040 / image.naturalWidth, 1040 / image.naturalHeight); fixture.ctx.clearRect(0, 0, 1920, 1080); fixture.ctx.drawImage(image, (1920 - image.naturalWidth * scale) / 2, (1080 - image.naturalHeight * scale) / 2, image.naturalWidth * scale, image.naturalHeight * scale); }, image); }
        catch (error) { if (native.isDetached() || /Execution context was destroyed/.test(error.message)) continue; throw error; }
        await reader.waitForTimeout(100);
        const progress = await reader.locator('#partialProgress').evaluate(el => el.value); if (progress > 0 && progress < 1) sawProgress = true;
        if (sawProgress && !capturedNativeView) { await reader.screenshot({ path: path.join(reportDir, 'reader-native-desktop.png') }); capturedNativeView = true; }
        if (await reader.locator('#gathered').textContent() === (phase + 1) + ' / 2') break;
      }
      await reader.waitForFunction(n => document.querySelector('#gathered').textContent === n + ' / 2', phase + 1, { timeout: 10000 }).catch(async error => {
        console.log(await reader.evaluate(() => ({ title: document.querySelector('#stateTitle').textContent, hint: document.querySelector('#stateHint').textContent })));
        throw error;
      });
    }
    assert(sawProgress, 'Native intermediate progress must be displayed');
    await reader.locator('#saveArea').waitFor({ state: 'visible' });
    const hash = await reader.evaluate(async () => KnitBatches.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer()));
    assert.equal(hash, createHash('sha256').update(input).digest('hex'));
    const constraints = await reader.evaluate(() => testConstraints[0]);
    assert.deepEqual(constraints.video.width, { min: 720, ideal: 1920 });
    assert.deepEqual(constraints.video.height, { min: 720, ideal: 1080 });
    assert.equal(constraints.video.focusMode, 'continuous'); assert.equal(constraints.video.exposureMode, 'continuous');
    assert.deepEqual(constraints.video.frameRate, { ideal: 15 });
    await reader.waitForTimeout(1200);
    assert(await reader.evaluate(() => testStreams.every(s => s.getTracks().every(t => t.readyState === 'ended'))));
    assert.equal(await reader.evaluate(() => testConstraints.length), 2, 'New stream must replace the old native page automatically, with no manual Pause/Read or watchdog reopen');
    assert.equal(await reader.locator('#gathered').textContent(), '2 / 2');
    await reader.screenshot({ path: path.join(reportDir, 'reader-desktop.png') });
    await reader.setViewportSize({ width: 393, height: 852 });
    const text = await reader.locator('body').innerText();
    assert.equal((text.match(/CimbarPlus/g) || []).length, 1, 'The wrapper must not duplicate its own page');
    console.log('PHONE CONTENT', text.replace(/\s+/g, ' ').slice(0, 800));
    await reader.screenshot({ path: path.join(reportDir, 'reader-phone.png'), fullPage: true });
    assert.equal(await reader.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    await reader.reload();
    await reader.locator('#taskList').selectOption({ index: 1 }); await reader.locator('#saveArea').waitFor({ state: 'visible' });
    assert.deepEqual(errors, []);
    console.log('PASS: sender ' + senderPath + '; mode ' + mode + '; 2 x 1MiB through unchanged original VideoFrame/worker/WASM Auto detection, native partial progress, sequential batches, verified final merge, completed-task refresh recovery, original camera constraints and responsive layouts');
    await context.close();
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
