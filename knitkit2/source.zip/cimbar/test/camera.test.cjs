const assert = require('node:assert/strict');
const { test } = require('node:test');
require('../src/camera.js');
function fakeStream() {
  const track = { readyState: 'live', stopped: 0, stop() { this.readyState = 'ended'; this.stopped++; } };
  return { track, getTracks: () => [track], getVideoTracks: () => [track] };
}
test('camera lease forwards native constraints once and survives decoder replacement', async () => {
  let active = true, calls = 0, release;
  const stream = fakeStream(), constraints = Object.freeze({ audio: false, video: Object.freeze({ facingMode: 'environment', frameRate: { ideal: 15 } }) });
  const lease = KnitCameraLease.create(value => { assert.equal(value, constraints); calls++; return new Promise(resolve => { release = resolve; }); }, () => active);
  const first = lease.acquire(constraints), second = lease.acquire(constraints);
  assert.equal(first, second); await Promise.resolve(); assert.equal(calls, 1);
  release(stream); assert.equal(await first, stream);
  for (let i = 0; i < 20; i++) assert.equal(await lease.acquire(constraints), stream);
  assert.equal(calls, 1); assert.equal(stream.track.stopped, 0);
  active = false; lease.release(); lease.release(); assert.equal(stream.track.stopped, 1);
  await assert.rejects(lease.acquire(constraints), { name: 'AbortError' });
});
test('late permission result cannot reopen a paused camera or invalidate a newer lease', async () => {
  let active = true, resolveOld, resolveNew, calls = 0;
  const lease = KnitCameraLease.create(() => new Promise(resolve => { if (++calls === 1) resolveOld = resolve; else resolveNew = resolve; }), () => active);
  const old = lease.acquire({}); await Promise.resolve(); const rejected = assert.rejects(old, { name: 'AbortError' });
  active = false; lease.release(); active = true;
  const next = lease.acquire({}); await Promise.resolve();
  const stale = fakeStream(); resolveOld(stale); await rejected;
  assert.equal(stale.track.readyState, 'ended'); assert.equal(lease.acquire({}), next);
  const current = fakeStream(); resolveNew(current); assert.equal(await next, current);
  current.track.stop(); const replacement = lease.acquire({}); await Promise.resolve();
  const last = fakeStream(); resolveNew(last); assert.equal(await replacement, last);
  lease.release(); assert.equal(last.track.readyState, 'ended');
});
