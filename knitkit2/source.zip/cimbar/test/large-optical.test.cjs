const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');

(async () => {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const context = await browser.newContext({ offline: true });
    const page = await context.newPage();
    await page.goto('file://' + path.join(root, 'dist/knitkit2.html'));
    await page.waitForFunction(() => initialized);
    const input = randomBytes(10 * 1024 * 1024);
    await page.locator('#pattern').setInputFiles({ name: '10MiB-random.bin', mimeType: 'application/octet-stream', buffer: input });
    await page.waitForFunction(() => ready && !preparing, null, { timeout: 60000 });
    const workerSource = Buffer.from(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'), 'utf8').match(/<script id="readerSource"[^>]*>([\s\S]*?)<\/script>/)[1], 'base64').toString();
    const result = await page.evaluate(async source => {
      const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
      const worker = new Worker(url); URL.revokeObjectURL(url);
      const copy = document.createElement('canvas'); copy.width = 1040; copy.height = 1040;
      const ctx = copy.getContext('2d', { willReadFrequently: true });
      let frames = 0;
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => { worker.terminate(); reject(new Error('Large optical test timeout after ' + frames + ' frames')); }, 180000);
        worker.onerror = error => { clearTimeout(timer); worker.terminate(); reject(new Error(error.message)); };
        worker.onmessage = async event => {
          const data = event.data;
          if (data.kind === 'complete') {
            clearTimeout(timer); worker.terminate();
            try {
              const packet = await KnitBatches.unpack(new Blob([data.buffer]));
              resolve({ frames, size: packet.data.size, hash: await KnitBatches.hash(await packet.data.arrayBuffer()) });
            } catch (error) { reject(error); }
          } else if (data.kind === 'error' || data.kind === 'switch') {
            clearTimeout(timer); worker.terminate(); reject(new Error(JSON.stringify(data)));
          } else {
            frames++;
            // Repeated images and skipped symbols exercise the actual fountain decoder.
            if (frames % 7 !== 0) Module._cimbare_next_frame(false);
            if (frames % 5 === 0) Module._cimbare_next_frame(false);
            Module._cimbare_render(); ctx.drawImage(document.querySelector('#canvas'), 0, 0);
            const pixels = ctx.getImageData(0, 0, 1040, 1040).data;
            worker.postMessage({ pixels, width: 1040, height: 1040 }, [pixels.buffer]);
          }
        };
      });
    }, workerSource);
    assert.equal(result.size, input.length);
    assert.equal(result.hash, createHash('sha256').update(input).digest('hex'));
    console.log('PASS: actual optical encode/decode of 10MiB incompressible binary with repeated/skipped symbols, exact SHA-256; processed ' + result.frames + ' synthetic images (not a camera throughput benchmark)');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
