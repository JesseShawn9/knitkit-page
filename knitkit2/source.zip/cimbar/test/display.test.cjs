const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { randomBytes } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
require('../src/batches.js');
const B = globalThis.KnitBatches, root = path.resolve(__dirname, '..');
const report = process.env.DISPLAY_REPORT || '/private/tmp/cimbarplus-display-check';
const assets = {
  '/recv.html': 'native-page.html', '/recv.2026-08-21T2336.js': 'native-receiver.js',
  '/recv-worker.2026-08-21T2336.js': 'native-worker.js', '/zstd.2026-08-21T2336.js': 'native-zstd.js',
  '/cimbar_js.2026-08-21T2336.js': 'cimbar.js', '/cimbar_js.2026-08-21T2336.wasm': 'cimbar.wasm'
};
const server = http.createServer((req, res) => {
  const name = assets[req.url];
  if (!name) { res.statusCode = 404; res.end(); return; }
  res.setHeader('Content-Type', name.endsWith('.wasm') ? 'application/wasm' : name.endsWith('.html') ? 'text/html' : 'application/javascript');
  res.end(fs.readFileSync(path.join(root, 'vendor', name)));
});
(async () => {
  fs.mkdirSync(report, { recursive: true });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--disable-background-timer-throttling', '--disable-renderer-backgrounding'] });
  try {
    const results = [];
    for (const [mode, width, height] of [[68, 1440, 900], [68, 1366, 768], [68, 1920, 1080], [66, 1440, 900], [66, 1366, 768], [66, 1920, 1080]]) {
      const context = await browser.newContext({ viewport: { width, height }, serviceWorkers: 'block' });
      const sender = await context.newPage();
      await sender.goto('file://' + path.join(root, 'dist/knitkit2.html'));
      await sender.waitForFunction(() => initialized);
      assert.equal(await sender.locator('#mode').inputValue(), '68');
      await sender.locator('#mode').selectOption(String(mode));
      if (mode === 66) { await sender.locator('#dwell').fill('120'); await sender.locator('#dwell').press('Tab'); }
      const input = randomBytes(200000);
      await sender.locator('#pattern').setInputFiles({ name: 'display.bin', mimeType: 'application/octet-stream', buffer: input });
      await sender.waitForFunction(() => ready && !preparing);
      const reader = await context.newPage();
      await reader.addInitScript(() => { navigator.mediaDevices.getUserMedia = () => new Promise(() => {}); });
      await reader.goto('http://127.0.0.1:' + server.address().port + '/recv.html');
      await reader.waitForFunction(() => Module._cimbard_get_bufsize);
      await reader.evaluate(async mode => {
        await Recv.ww_ready;
        window.completed = null; window.extracted = 0; window.failures = [];
        Zstd.download_blob = async (name, blob) => { completed = { name, bytes: Array.from(new Uint8Array(await blob.arrayBuffer())) }; };
        const worker = new Worker('recv-worker.2026-08-21T2336.js');
        await new Promise((resolve, reject) => { worker.onmessage = e => { if (e.data.ready) resolve(); }; worker.onerror = reject; });
        window.scanScreenshot = async src => {
          const image = new Image(); image.src = src; await image.decode();
          const canvas = document.createElement('canvas'); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight;
          const ctx = canvas.getContext('2d', { willReadFrequently: true }); ctx.drawImage(image, 0, 0);
          const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
          const data = await new Promise(resolve => { worker.onmessage = event => resolve(event.data); worker.postMessage({ pixels, format: 'RGBA', width: canvas.width, height: canvas.height, mode }, [pixels.buffer]); });
          if (data.buff?.length) { extracted++; Recv.frames_in_flight_incr(); Recv.on_decode(0, data); }
          else failures.push(data.res || 'no bytes');
        };
      }, mode);
      await sender.bringToFront(); await sender.locator('#play').click();
      const geometry = await sender.locator('#canvas').evaluate(canvas => ({ intrinsic: [canvas.width, canvas.height], css: [canvas.clientWidth, canvas.clientHeight], dpr: devicePixelRatio }));
      let frames = 0;
      for (; frames < 100; frames++) {
        const png = await sender.locator('#canvas').screenshot({ type: 'png' });
        if (!frames) {
          fs.writeFileSync(path.join(report, 'source-' + mode + '-' + width + '.png'), png);
          await sender.screenshot({ path: path.join(report, 'workspace-' + mode + '-' + width + '.png') });
        }
        await reader.evaluate(src => scanScreenshot(src), 'data:image/png;base64,' + png.toString('base64'));
        if (await reader.evaluate(() => !!completed)) break;
        if (!await sender.evaluate(() => playing)) break;
      }
      const evidence = await reader.evaluate(() => ({ extracted, failures: failures.slice(0, 3), completed }));
      const state = await sender.evaluate(() => ({ playing, count, selected, title: document.querySelector('#stateTitle').textContent }));
      console.log(JSON.stringify({ mode, width, height, geometry, frames: frames + 1, extracted: evidence.extracted, failures: evidence.failures, state, completedBytes: evidence.completed?.bytes.length }));
      assert(evidence.completed, 'Actual rendered sender frames must decode in the pristine official receiver at ' + width);
      const value = await B.unpack(new Blob([new Uint8Array(evidence.completed.bytes)]));
      assert.equal(value.index, 0); assert.equal(value.manifest.size, input.length);
      assert.equal(await B.hash(await value.data.arrayBuffer()), await B.hash(input));
      results.push({ mode, width, height, geometry, frames: frames + 1, extracted: evidence.extracted, exact: true });
      await sender.locator('#play').click(); await context.close();
    }
    fs.writeFileSync(path.join(report, 'results.json'), JSON.stringify(results, null, 2));
    for (const low of results.filter(r => r.mode === 66)) {
      const high = results.find(r => r.mode === 68 && r.width === low.width);
      const pitch = (item, columns) => Math.min(item.geometry.css[0] / item.geometry.intrinsic[0], item.geometry.css[1] / item.geometry.intrinsic[1]) * (item.geometry.intrinsic[0] - 16) / columns;
      assert(pitch(low, 80) > pitch(high, 112) * 1.1, 'Low density must enlarge displayed cells, not just shrink the image');
    }
    console.log('PASS: B/Bu current Encoder playback screenshots decode byte-exact at three desktop sizes; low-density cells are measurably larger');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
