const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { randomBytes, createHash } = require('node:crypto');
const playwrightPath = process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright';
const { chromium } = require(playwrightPath);
const root = path.resolve(__dirname, '..');
const reportDir = process.env.KNIT_TEST_OUTPUT || '/private/tmp/knitkit2-browser-check';
fs.mkdirSync(reportDir, { recursive: true });
const profile = fs.mkdtempSync('/private/tmp/knitkit2-profile-');
const server = http.createServer((req, res) => {
  if (req.url !== '/reader.html') { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html')));
});

(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = 'http://127.0.0.1:' + server.address().port + '/reader.html';
  let context = await chromium.launchPersistentContext(profile, { channel: 'chrome', headless: true, viewport: { width: 1440, height: 900 }, offline: true });
  try {
    const sender = await context.newPage();
    const errors = [], external = [];
    sender.on('pageerror', e => errors.push(e.message));
    sender.on('request', r => { if (/^https?:/.test(r.url())) external.push(r.url()); });
    await sender.goto('file://' + path.join(root, 'dist/knitkit2.html'));
    await sender.waitForFunction(() => typeof initialized !== 'undefined' && initialized, { timeout: 30000 });
    assert.equal(await sender.locator('#partSize').inputValue(), '1');
    assert.equal(await sender.locator('#mode').inputValue(), '68');
    assert.equal(await sender.locator('#fps').inputValue(), '15');
    assert.equal(await sender.locator('#batchList').count(), 0);
    assert.equal(await sender.locator('#full').count(), 0);
    // Keep high-density legacy optical fixtures; a separate test exercises the mobile default.
    await sender.selectOption('#mode', '68');
    const input = randomBytes(96 * 1024 + 17);
    await sender.locator('#pattern').setInputFiles({ name: '中文-二进制.zip', mimeType: 'application/zip', buffer: input });
    await sender.waitForFunction(() => ready && !preparing, { timeout: 30000 });
    // Smaller batches exercise switches, missing lists and merge with actual image decoding in a short test.
    await sender.evaluate(async () => {
      manifest = await KnitBatches.prepare(file, 32768); selected = 0; order = manifest.hashes.map((_, i) => i);
      document.querySelector('#total').textContent = manifest.hashes.length;
      await selectBatch(0);
    });
    assert.equal(await sender.locator('#total').textContent(), '4');
    await sender.locator('#play').click(); await sender.locator('#play').click();
    assert.equal(await sender.locator('#partSize').isDisabled(), true);
    assert.equal(await sender.locator('#fps').isEnabled(), true);
    await sender.screenshot({ path: path.join(reportDir, 'sender-desktop.png') });
    const workerSource = Buffer.from(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'), 'utf8').match(/<script id="readerSource"[^>]*>([\s\S]*?)<\/script>/)[1], 'base64').toString();
    await sender.evaluate(source => { window.opticalWorkerSource = source; }, workerSource);
    const packets = [];
    for (const index of [2, 0, 3, 1]) {
      await sender.evaluate(i => selectBatch(i), index);
      const packet = await sender.evaluate(async () => {
        const blobURL = URL.createObjectURL(new Blob([window.opticalWorkerSource], { type: 'text/javascript' }));
        const reader = new Worker(blobURL); URL.revokeObjectURL(blobURL);
        const scratch = document.createElement('canvas'); scratch.width = 1040; scratch.height = 1040;
        const ctx = scratch.getContext('2d', { willReadFrequently: true });
        let sent = 0;
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => { reader.terminate(); reject(new Error('Optical decode timeout after ' + sent + ' frames')); }, 40000);
          function feed() {
            if (++sent > 100) { clearTimeout(timer); reader.terminate(); reject(new Error('No optical completion')); return; }
            Module._cimbare_next_frame(false); Module._cimbare_render();
            ctx.drawImage(document.querySelector('#canvas'), 0, 0);
            const pixels = ctx.getImageData(0, 0, 1040, 1040).data;
            reader.postMessage({ pixels, width: 1040, height: 1040 }, [pixels.buffer]);
          }
          reader.onerror = e => { clearTimeout(timer); reader.terminate(); reject(new Error(e.message)); };
          reader.onmessage = async event => {
            const value = event.data;
            if (value.kind === 'ready' || value.kind === 'frame') feed();
            else if (value.kind === 'error' || value.kind === 'switch') {
              clearTimeout(timer); reader.terminate(); reject(new Error(JSON.stringify(value)));
            } else if (value.kind === 'complete') {
              clearTimeout(timer); reader.terminate();
              const bytes = new Uint8Array(value.buffer);
              let binary = ''; for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
              resolve({ base64: btoa(binary), frames: sent });
            }
          };
        });
      });
      packets.push(packet); console.log('Optical batch ' + (index + 1) + ': ' + packet.frames + ' frames');
    }
    assert.deepEqual(external, []); assert.deepEqual(errors, []);
    const cameraFixtures = [];
    for (const index of [2, 0]) {
      await sender.evaluate(i => selectBatch(i), index);
      cameraFixtures.push(await sender.evaluate(() => {
        const copy = document.createElement('canvas'); copy.width = 1040; copy.height = 1040;
        const ctx = copy.getContext('2d'); const images = [];
        for (let i = 0; i < 12; i++) {
          Module._cimbare_next_frame(false); Module._cimbare_render();
          ctx.drawImage(document.querySelector('#canvas'), 0, 0);
          images.push(copy.toDataURL('image/png'));
        }
        return images;
      }));
    }

    await context.setOffline(false);
    const receiver = await context.newPage();
    receiver.on('pageerror', e => errors.push(e.message));
    await receiver.goto(url);
    await context.setOffline(true);
    await receiver.evaluate(() => {
      const canvas = document.createElement('canvas'); canvas.width = 1040; canvas.height = 1040;
      const ctx = canvas.getContext('2d'); ctx.fillStyle = 'white'; ctx.fillRect(0, 0, 1040, 1040);
      window.syntheticCamera = { canvas, ctx, lastStream: null };
      navigator.mediaDevices.getUserMedia = async () => {
        syntheticCamera.lastStream = canvas.captureStream(30);
        setTimeout(() => ctx.drawImage(canvas, 0, 0), 50);
        return syntheticCamera.lastStream;
      };
    });
    await receiver.locator('#read').click();
    await receiver.waitForFunction(() => reading && workerReady, { timeout: 30000 }).catch(async error => {
      console.log(await receiver.evaluate(() => ({ title: document.querySelector('#stateTitle').textContent, hint: document.querySelector('#stateHint').textContent, reading, starting, workerReady, video: [document.querySelector('#video').readyState, document.querySelector('#video').videoWidth], camera: !!syntheticCamera.lastStream })));
      throw error;
    });
    assert.equal(await receiver.locator('#read').isDisabled(), true);
    assert.equal(await receiver.locator('#pause').isEnabled(), true);
    await receiver.evaluate(() => worker.postMessage({ pixels: new Uint8Array(), width: 0, height: 0 }));
    await receiver.waitForFunction(() => document.querySelector('#stateHint').textContent === '画面尺寸不正确。');
    assert.equal(await receiver.locator('#read').isEnabled(), true);
    await receiver.locator('#read').click();
    await receiver.waitForFunction(() => reading && workerReady);
    await receiver.evaluate(() => {
      window.initialWorkers = pool.map(s => s.worker); window.initialCollector = collector;
      for (const slot of pool) {
        const original = slot.worker.onmessage;
        slot.worker.onmessage = event => setTimeout(() => original(event), event.data.sequence % 2 ? 180 : 0);
      }
    });
    for (let phase = 0; phase < cameraFixtures.length; phase++) {
      for (let round = 0; round < 2; round++) {
        await receiver.evaluate(async images => {
          for (const src of images) {
            const image = new Image(); image.src = src; await image.decode();
            syntheticCamera.ctx.drawImage(image, 0, 0);
            await new Promise(resolve => setTimeout(resolve, 110));
          }
        }, cameraFixtures[phase]);
        if (await receiver.locator('#gathered').textContent() === (phase + 1) + ' / 4') break;
      }
      await receiver.waitForFunction(n => document.querySelector('#gathered').textContent === n + ' / 4', phase + 1, { timeout: 20000 }).catch(async error => {
        console.log(await receiver.evaluate(() => ({ reading, workerReady, inFlight, frames, captured, title: document.querySelector('#stateTitle').textContent, hint: document.querySelector('#stateHint').textContent, partials: [...partials.values()].map(s => ({ count: s.count, progress: s.progress, done: s.done })) })));
        throw error;
      });
      assert(await receiver.evaluate(() => pool.every((s, i) => s.worker === initialWorkers[i]) && collector === initialCollector), 'Switching must retain extraction and collector workers');
      assert(await receiver.evaluate(() => inFlight <= workerCount * 2), 'Capture and aggregation must remain bounded');
    }
    await receiver.locator('#pause').click();
    assert(await receiver.evaluate(() => syntheticCamera.lastStream.getTracks().every(t => t.readyState === 'ended')));
    const accept = packet => receiver.evaluate(async b64 => {
      const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      return KnitReceiver.accept(new Blob([bytes]));
    }, packet.base64);
    await accept(packets[0]); await accept(packets[1]); await accept(packets[1]);
    assert.equal(await receiver.locator('#gathered').textContent(), '2 / 4');
    assert.equal(await receiver.locator('#missing').textContent(), '2');
    assert.equal(await receiver.locator('#totalProgress').getAttribute('value'), '0.5');
    const mendingCode = await receiver.locator('#mending').inputValue();
    await sender.locator('#mending').fill('2, 4');
    await sender.locator('#apply').click();
    await sender.waitForFunction(() => ready && !preparing);
    assert.deepEqual(await sender.evaluate(() => order), [1, 3]);
    await sender.locator('#mending').fill(mendingCode);
    await sender.locator('#apply').click();
    await sender.waitForFunction(() => ready && !preparing);
    assert.deepEqual(await sender.evaluate(() => order), [1, 3]);
    await sender.locator('#play').click();
    await sender.evaluate(() => { elapsed = Number(document.querySelector('#dwell').value); });
    await sender.waitForFunction(() => selected === 3 && ready && !preparing);
    await sender.evaluate(() => { elapsed = Number(document.querySelector('#dwell').value); });
    await sender.waitForFunction(() => roundDone && !playing);
    assert.equal(await sender.locator('#lapProgress').getAttribute('value'), '1');
    assert.equal(await receiver.evaluate(async () => {
      const other = new File(['other file'], 'other.txt');
      const m = await KnitBatches.prepare(other, 100);
      return KnitReceiver.accept(await KnitBatches.packet(other, m, 0));
    }), false);
    assert.equal(await receiver.locator('#gathered').textContent(), '2 / 4');
    await receiver.screenshot({ path: path.join(reportDir, 'reader-desktop.png') });
    await receiver.setViewportSize({ width: 390, height: 844 });
    await receiver.screenshot({ path: path.join(reportDir, 'reader-mobile.png'), fullPage: true });
    assert(await receiver.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert(await receiver.locator('#partialProgress').isVisible());
    assert((await receiver.locator('#pause').boundingBox()).y < 250);
    assert.equal(await receiver.getByText('开源许可', { exact: true }).count(), 0);
    await context.setOffline(false); await receiver.reload();
    await receiver.locator('#taskList button').first().click();
    await receiver.waitForFunction(() => document.querySelector('#gathered').textContent === '2 / 4');
    assert.equal(await receiver.locator('#gathered').textContent(), '2 / 4');
    await receiver.close();
    const reopened = await context.newPage();
    await reopened.goto(url); await reopened.locator('#taskList button').first().click();
    await reopened.waitForFunction(() => document.querySelector('#gathered').textContent === '2 / 4');
    assert.equal(await reopened.locator('#gathered').textContent(), '2 / 4');
    const acceptAgain = packet => reopened.evaluate(async b64 => KnitReceiver.accept(new Blob([Uint8Array.from(atob(b64), c => c.charCodeAt(0))])), packet.base64);
    await acceptAgain(packets[2]); await acceptAgain(packets[3]);
    assert.equal(await reopened.locator('#gathered').textContent(), '4 / 4');
    const outputHash = await reopened.evaluate(async () => {
      const blob = await (await fetch(document.querySelector('#save').href)).arrayBuffer();
      return KnitBatches.hash(blob);
    });
    assert.equal(outputHash, createHash('sha256').update(input).digest('hex'));
    assert.equal(await reopened.locator('#save').getAttribute('download'), '中文-二进制.zip');
    assert.equal(await reopened.locator('#read').isDisabled(), true);
    await sender.setViewportSize({ width: 390, height: 844 });
    await sender.screenshot({ path: path.join(reportDir, 'sender-mobile.png'), fullPage: true });
    assert(await sender.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert.deepEqual(errors, []);
    await context.close();
    context = await chromium.launchPersistentContext(profile, { channel: 'chrome', headless: true });
    const afterRestart = await context.newPage();
    await afterRestart.goto(url); await afterRestart.locator('#taskList button').first().click();
    await afterRestart.locator('#saveArea').waitFor({ state: 'visible' });
    assert.equal(await afterRestart.locator('#gathered').textContent(), '4 / 4');
    fs.writeFileSync(path.join(reportDir, 'result.json'), JSON.stringify({ passed: true, packetFrames: packets.map(p => p.frames), fileHash: outputHash, externalRequests: external, pageErrors: errors, realCameraTested: false }, null, 2));
    console.log('PASS: offline file sender + real WASM image encode/decode; synthetic video camera capture, batch switching, pause/track release; out-of-order/duplicate/mixed-task collection; refresh/tab reopen/browser-process restart recovery; exact download SHA-256; desktop/mobile layouts');
  } finally { await context.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => { server.close(); fs.rmSync(profile, { recursive: true, force: true }); });
