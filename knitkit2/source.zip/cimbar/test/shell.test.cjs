const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { randomBytes, createHash } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
require('../src/batches.js');
const B = globalThis.KnitBatches, root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(req.url === '/blank' ? '<!doctype html><title>Test</title>' : fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  const data = randomBytes(40001), file = new File([data], '历史任务.zip', { type: 'application/zip' });
  const m = await B.prepare(file, 16000), packets = [];
  for (let i = 0; i < m.hashes.length; i++) packets.push(Buffer.from(await (await B.packet(file, m, i)).arrayBuffer()).toString('base64'));
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage(), url = 'http://127.0.0.1:' + server.address().port;
    await page.goto(url + '/blank');
    await page.evaluate(async ({ manifest, first }) => {
      await new Promise((resolve, reject) => {
        const r = indexedDB.open('knitkit2-batches', 1);
        r.onupgradeneeded = () => { r.result.createObjectStore('tasks', { keyPath: 'id' }); r.result.createObjectStore('parts', { keyPath: ['id', 'index'] }).createIndex('task', 'id'); };
        r.onerror = () => reject(r.error);
        r.onsuccess = () => {
          const tx = r.result.transaction(['tasks', 'parts'], 'readwrite');
          tx.objectStore('tasks').put({ id: manifest.id, manifest, updated: 1 });
          tx.objectStore('parts').put({ id: manifest.id, index: 0, data: new Blob([new Uint8Array(first)]) });
          tx.oncomplete = () => { r.result.close(); resolve(); };
        };
      });
    }, { manifest: m, first: [...data.subarray(0, 16000)] });
    await page.goto(url); await page.waitForFunction(() => document.querySelector('#taskList').options.length > 1);
    assert.equal(await page.evaluate(() => engineRequested), false, 'Downloading saved tasks must not start the camera engine');
    await page.locator('#taskList').selectOption(m.id);
    await page.waitForFunction(() => document.querySelector('#gathered').textContent === '1 / 3');
    assert.equal(await page.locator('#gathered').textContent(), '1 / 3');
    await page.evaluate(() => {
      document.execCommand = () => false;
      Object.defineProperty(navigator, 'clipboard', { value: { writeText: async text => { window.testCode = text; } } });
    });
    await page.locator('#copy').click();
    assert.equal(await page.evaluate(() => testCode), 'KK2M:' + m.id + ':2-3');
    const accept = b64 => page.evaluate(text => KnitReceiver.accept(new Blob([Uint8Array.from(atob(text), c => c.charCodeAt(0))])), b64);
    await accept(packets[0]); assert.equal(await page.locator('#gathered').textContent(), '1 / 3');
    const other = new File(['other'], 'other.txt'), om = await B.prepare(other, 16000);
    assert.equal(await accept(Buffer.from(await (await B.packet(other, om, 0)).arrayBuffer()).toString('base64')), false);
    await page.evaluate(() => KnitStore.journal({ key: 'legacy-unused', count: 1 }, [{ block: 3, bytes: new Uint8Array([1, 2]) }]));
    await accept(packets[2]); assert.equal(await page.locator('#gathered').textContent(), '2 / 3');
    assert.equal(await page.evaluate(async () => {
      const db = await new Promise((resolve, reject) => { const r = indexedDB.open('knitkit2-batches', 2); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); });
      const row = await new Promise((resolve, reject) => { const r = db.transaction(['parts']).objectStore('parts').get([manifest.id, 2]); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); });
      db.close(); return row.data instanceof ArrayBuffer;
    }), true, 'New completed parts persist owned ArrayBuffer bytes, not decoded sliced Blobs');
    await accept(packets[1]); await page.locator('#saveArea').waitFor({ state: 'visible' });
    assert.equal(await page.evaluate(async () => KnitBatches.hash(await (await fetch(document.querySelector('#save').href)).arrayBuffer())), createHash('sha256').update(data).digest('hex'));
    await page.reload(); await page.locator('#taskList').selectOption(m.id); await page.locator('#saveArea').waitFor({ state: 'visible' });
    assert.equal(await page.evaluate(async () => (await KnitStore.stitches('legacy-unused')).length), 1, 'Stopping experimental resume must not purge existing journals');
    await page.evaluate(m => KnitStore.remember(m), om);
    page.once('dialog', dialog => dialog.dismiss());
    await page.locator('#clear').click();
    assert.equal(await page.evaluate(async () => (await KnitStore.indices(manifest.id)).length), m.hashes.length, 'Cancel deletion preserves every completed part');
    page.once('dialog', dialog => dialog.accept());
    await page.locator('#clear').click();
    await page.waitForFunction(() => manifest === null && document.querySelector('#stateTitle').textContent === 'Task cleared');
    assert.deepEqual(await page.evaluate(id => KnitStore.indices(id), m.id), []);
    assert.deepEqual(await page.evaluate(async () => (await KnitStore.tasks()).map(t => t.id)), [om.id], 'Delete only the selected completed task');
    assert.equal(await page.locator('#saveArea').isVisible(), false);
    await page.reload();
    assert.deepEqual(await page.evaluate(async () => (await KnitStore.tasks()).map(t => t.id)), [om.id], 'Deleted completed task stays removed after refresh');
    console.log('PASS: migration, missing codes, duplicate/foreign rejection, merge/refresh recovery, completed-task confirmed deletion/cancel, unrelated task retained');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
