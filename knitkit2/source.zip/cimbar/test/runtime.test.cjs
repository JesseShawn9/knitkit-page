const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'), 'utf8');
const source = Buffer.from(html.match(/<script id="nativeRuntime"[^>]*>([\s\S]*?)<\/script>/)[1], 'base64').toString();
const binary = Buffer.from(JSON.parse(source.match(/^var knitBytes=Uint8Array\.from\(atob\(("[^"]+")\)/)[1]), 'base64');
assert(binary.equals(fs.readFileSync(path.join(root, 'vendor/cimbar.wasm'))));
const engine = Buffer.from(html.match(/<script id="nativeEngine"[^>]*>([\s\S]*?)<\/script>/)[1], 'base64').toString();
const receiver = engine.match(/<script>(var Sink =[\s\S]*?)<\/script>/)[1];
const upstream = receiver
  .replace('on_frame: async function (now, metadata) {', 'on_frame: function (now, metadata) {')
  .replace('const width = vf.visibleRect.width;\n          const height = vf.visibleRect.height;', 'const width = vf.displayWidth;\n          const height = vf.displayHeight;')
  .replace('await vf.copyTo(buff, vfparams);', 'vf.copyTo(buff, vfparams);')
  .replace('Recv.frames_in_flight_decr();\n          Recv.on_capture_error(e);', 'console.log(e);');
assert.equal(upstream, fs.readFileSync(path.join(root, 'vendor/native-receiver.js'), 'utf8'));
assert(engine.includes(fs.readFileSync(path.join(root, 'vendor/native-zstd.js'), 'utf8')));
assert(!html.includes('fzstd'));
console.log('PASS: byte-identical upstream WASM/Zstd; receive source differs only in four audited WebCodecs capture fixes; no custom symbol collector');
