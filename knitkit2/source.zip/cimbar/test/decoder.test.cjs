const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.resolve(__dirname, '../dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 393, height: 852 } });
    await page.addInitScript(() => {
      if (window !== parent) { navigator.mediaDevices.getUserMedia = () => new Promise(() => {}); return; }
      Object.defineProperty(navigator, 'clipboard', { value: { writeText: async text => { window.copied = text; } } });
      document.execCommand = () => false;
    });
    await page.goto('http://127.0.0.1:' + server.address().port);
    await page.waitForFunction(() => !document.querySelector('#read').disabled);
    assert.equal(await page.locator('html').getAttribute('lang'), 'en');
    assert.doesNotMatch(await page.locator('body').innerText(), /[\u4e00-\u9fff]/);
    assert.deepEqual(await page.locator('button').allTextContents(), ['Read', 'Copy IDs', 'Copy code', 'Clear']);
    assert.equal(await page.locator('#badge,#other,#pause,details,.scan-heading').count(), 0);
    assert.deepEqual(await page.locator('.sidebar > section').evaluateAll(sections => sections.map(el => el.className)), ['status-block', 'reader-repair', 'task-actions']);
    await page.locator('#read').click();
    assert.equal(await page.locator('#read').textContent(), 'Pause');
    assert.equal(await page.locator('button').count(), 4, 'Live view reuses the same four controls');
    const epoch = await page.evaluate(() => nativeEpoch);
    await page.evaluate(() => {
      window.dispatchEvent(new MessageEvent('message', { source: document.querySelector('#nativeView').contentWindow, origin: location.origin, data: { knitNative: true, session: nativeEpoch, kind: 'progress', report: [.45] } }));
    });
    assert.equal(await page.locator('#partial').textContent(), '45%');
    await page.evaluate(async () => {
      window.sample = new File([new Uint8Array(9000)], 'Archive.zip');
      window.sampleManifest = await KnitBatches.prepare(sample, 3000);
      await KnitReceiver.accept(await KnitBatches.packet(sample, sampleManifest, 0));
    });
    assert.equal(await page.locator('#missingText').inputValue(), '2-3');
    assert.equal(await page.locator('#gathered').textContent(), '1 / 3');
    await page.locator('#copyIDs').click(); assert.equal(await page.evaluate(() => copied), '2-3');
    await page.locator('#copy').click(); assert.equal(await page.evaluate(() => copied), await page.evaluate(() => KnitBatches.mending(sampleManifest, have)));
    assert.equal(await page.evaluate(() => reading && nativeEpoch), epoch);
    assert.equal(await page.locator('#clear').isDisabled(), true);
    await page.locator('#read').click();
    assert.equal(await page.locator('#read').textContent(), 'Read');
    assert.equal(await page.evaluate(() => !reading && !starting && have.size === 1), true);
    assert.equal(await page.locator('#mending').isVisible(), true);
    await page.reload();
    await page.locator('#taskList').selectOption(await page.evaluate(async () => (await KnitStore.tasks())[0].id));
    await page.waitForFunction(() => manifest && pending === 0);
    assert.equal(await page.evaluate(() => engineRequested), false, 'Restoring a saved task must not open the camera');
    assert.equal(await page.locator('#gathered').textContent(), '1 / 3');
    page.once('dialog', dialog => dialog.dismiss()); await page.locator('#clear').click();
    assert.equal(await page.evaluate(() => have.size), 1);
    page.once('dialog', dialog => dialog.accept()); await page.locator('#clear').click();
    await page.waitForFunction(() => manifest === null && pending === 0);
    assert.equal(await page.locator('#missingText').inputValue(), '');
    assert.equal(await page.locator('#mending').inputValue(), '');
    assert.equal(await page.locator('#partial').textContent(), '0%');
    assert.equal(await page.locator('#totalPercent').textContent(), '0%');
    assert.equal(await page.locator('#stateTitle').textContent(), 'Task cleared');
    assert.doesNotMatch(await page.locator('body').innerText(), /[\u4e00-\u9fff]/);
    assert.equal(await page.locator('button').count(), 4);
    console.log('PASS: English four-button Decoder, ordered sections, live ID/code copying, one Read/Pause toggle, task dropdown restore and confirmed Clear');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
