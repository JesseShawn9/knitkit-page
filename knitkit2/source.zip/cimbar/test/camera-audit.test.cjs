const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = process.env.KNIT_CAMERA_AUDIT_URL || 'http://127.0.0.1:' + server.address().port;
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    // Exercise the original iOS watchdog in Chrome; this is not physical Safari evidence.
    const context = await browser.newContext({ viewport: { width: 393, height: 852 }, userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1' });
    await context.addInitScript(() => {
      if (window !== parent) {
        const descriptor = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'srcObject');
        Object.defineProperty(HTMLMediaElement.prototype, 'srcObject', {
          ...descriptor,
          set(value) {
            parent.audit.events.push({ kind: value ? 'attach' : 'detach', session: parent.KnitNativeSources?.session, at: Date.now(), track: value?.getVideoTracks()[0]?.id });
            descriptor.set.call(this, value);
          }
        });
        return;
      }
      const canvas = document.createElement('canvas'); canvas.width = 1920; canvas.height = 1080;
      const ctx = canvas.getContext('2d');
      window.audit = { events: [], streams: [], timer: 0, tick: 0 };
      window.auditFeed = () => {
        clearInterval(audit.timer);
        audit.timer = setInterval(() => {
          ctx.fillStyle = ++audit.tick % 2 ? '#111' : '#222'; ctx.fillRect(0, 0, canvas.width, canvas.height);
          for (const stream of audit.streams) stream.getVideoTracks()[0].requestFrame();
        }, 100);
      };
      navigator.mediaDevices.getUserMedia = async constraints => {
        const stream = canvas.captureStream(0), track = stream.getVideoTracks()[0], stop = track.stop.bind(track);
        audit.events.push({ kind: 'request', at: Date.now(), track: track.id, constraints });
        track.stop = () => { audit.events.push({ kind: 'stop', at: Date.now(), track: track.id }); stop(); };
        audit.streams.push(stream); auditFeed(); return stream;
      };
    });
    const page = await context.newPage();
    await page.goto(url);
    await page.evaluate(() => {
      const acquire = KnitCamera.acquire;
      KnitCamera.acquire = async (...args) => {
        audit.events.push({ kind: 'lease', at: Date.now(), session: args[1] });
        return acquire(...args);
      };
    });
    await page.locator('#read').click(); await page.waitForFunction(() => reading);
    const gaps = [];
    for (let index = 1; index <= 8; index++) {
      const at = Date.now();
      await page.evaluate(key => changeWindow(key), index.toString(16).padStart(8, '0'));
      await page.waitForFunction(() => reading);
      gaps.push(Date.now() - at);
      assert(await page.evaluate(() => audit.streams.length === 1 && audit.streams[0].getVideoTracks()[0].readyState === 'live'));
    }
    await page.evaluate(() => recoverScanner()); await page.waitForFunction(() => reading);
    const beforeWatchdog = await page.evaluate(() => {
      clearInterval(audit.timer);
      return audit.events.filter(e => e.kind === 'attach').length;
    });
    await page.waitForFunction(count => audit.events.filter(e => e.kind === 'attach').length > count, beforeWatchdog, { timeout: 8000 });
    const active = await page.evaluate(() => ({ events: audit.events, state: audit.streams[0].getVideoTracks()[0].readyState }));
    assert.equal(active.events.filter(e => e.kind === 'request').length, 1, 'Transitions, fault recovery and iOS watchdog must share one physical request');
    assert.equal(active.events.filter(e => e.kind === 'stop').length, 0);
    assert.equal(active.state, 'live');
    assert.equal(new Set(active.events.filter(e => e.kind === 'attach').map(e => e.track)).size, 1);
    await page.locator('#read').click();
    assert.equal(await page.evaluate(() => audit.streams[0].getVideoTracks()[0].readyState), 'ended', 'Explicit Pause releases camera');
    await page.locator('#read').click(); await page.waitForFunction(() => reading);
    assert.equal(await page.evaluate(() => audit.streams.length), 2, 'Read after explicit Pause intentionally acquires a new camera');
    await page.evaluate(() => {
      Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'hidden' });
      document.dispatchEvent(new Event('visibilitychange'));
    });
    assert(await page.evaluate(() => !reading && !starting && audit.streams.every(s => s.getVideoTracks()[0].readyState === 'ended')), 'Backgrounding intentionally releases camera');
    const report = {
      url, environment: 'Chrome with iPhone user-agent; synthetic canvas camera, not physical Safari',
      segmentTransitions: gaps.length, transitionWaitMs: gaps,
      physicalRequestsBeforePause: active.events.filter(e => e.kind === 'request').length,
      cameraStopsBeforePause: active.events.filter(e => e.kind === 'stop').length,
      originalPreviewAttachmentsBeforePause: active.events.filter(e => e.kind === 'attach').length,
      iosWatchdogReattachedSameLiveTrack: true, pauseAndBackgroundRelease: true,
      events: active.events
    };
    if (process.env.KNIT_CAMERA_AUDIT_REPORT) fs.writeFileSync(process.env.KNIT_CAMERA_AUDIT_REPORT, JSON.stringify(report, null, 2));
    console.log('PASS: ' + JSON.stringify({ ...report, events: undefined }));
    await context.close();
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
