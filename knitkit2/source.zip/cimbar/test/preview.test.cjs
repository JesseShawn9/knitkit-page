const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), http = require('node:http');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(root, 'dist/knitkit2-reader.html'))); });
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    for (const viewport of [{ width: 393, height: 852 }, { width: 1440, height: 900 }]) {
      const context = await browser.newContext({ viewport });
      await context.addInitScript(() => {
        if (window !== parent) return;
        window.audit = { streams: [], workers: [], bindings: 0, pauses: 0, emptied: 0, color: '#2468ac', hold: false };
        const NativeWorker = Worker;
        window.Worker = function (...args) { const worker = new NativeWorker(...args); audit.workers.push(worker); return worker; };
        const descriptor = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'srcObject');
        Object.defineProperty(HTMLMediaElement.prototype, 'srcObject', { ...descriptor, set(value) { if (this.id === 'cameraPreview' && value) audit.bindings++; descriptor.set.call(this, value); } });
        document.addEventListener('pause', event => { if (event.target.id === 'cameraPreview') audit.pauses++; }, true);
        document.addEventListener('emptied', event => { if (event.target.id === 'cameraPreview') audit.emptied++; }, true);
        navigator.mediaDevices.getUserMedia = async () => {
          const canvas = document.createElement('canvas'); canvas.width = 1920; canvas.height = 1080;
          const ctx = canvas.getContext('2d'), paint = () => { ctx.fillStyle = audit.color; ctx.fillRect(0, 0, 1920, 1080); };
          paint(); const stream = canvas.captureStream(15); audit.streams.push(stream);
          setInterval(paint, 50); return stream;
        };
      });
      const page = await context.newPage(), errors = []; page.on('pageerror', error => errors.push(error.message));
      await page.goto(process.env.KNIT_PREVIEW_URL || 'http://127.0.0.1:' + server.address().port);
      await page.evaluate(() => {
        const acquire = KnitCamera.acquire;
        KnitCamera.acquire = async (...args) => {
          if (audit.hold) await new Promise(resolve => { audit.resume = resolve; });
          return acquire(...args);
        };
      });
      await page.locator('#read').click(); await page.waitForFunction(() => reading);
      await page.evaluate(() => { audit.preview = document.querySelector('#cameraPreview'); audit.track = audit.preview.srcObject.getVideoTracks()[0]; });
      await page.evaluate(() => { audit.hold = true; changeWindow('00000001'); });
      await page.waitForFunction(() => typeof audit.resume === 'function');
      const time = await page.evaluate(() => audit.preview.currentTime);
      for (const [color, expected] of [['#2468ac', [36, 104, 172]], ['#ac6824', [172, 104, 36]]]) {
        await page.evaluate(color => { audit.color = color; }, color); await page.waitForTimeout(200);
        const image = await page.screenshot({ ...(process.env.KNIT_PREVIEW_REPORT ? { path: path.join(process.env.KNIT_PREVIEW_REPORT, 'preview-' + viewport.width + '-' + color.slice(1) + '.png') } : {}) });
        const pixel = await page.evaluate(async base64 => {
          const image = new Image(); image.src = 'data:image/png;base64,' + base64; await image.decode();
          const canvas = document.createElement('canvas'); canvas.width = image.width; canvas.height = image.height;
          const ctx = canvas.getContext('2d'); ctx.drawImage(image, 0, 0);
          return Array.from(ctx.getImageData(10, Math.floor(innerHeight * .8), 1, 1).data).slice(0, 3);
        }, image.toString('base64'));
        assert(pixel.every((value, index) => Math.abs(value - expected[index]) <= 3), 'Rendered preview must remain live, not black or a frozen screenshot: ' + pixel);
        assert(await page.evaluate(() => starting && !reading && audit.preview === document.querySelector('#cameraPreview') && audit.preview.srcObject.getVideoTracks()[0] === audit.track && !audit.preview.paused));
      }
      assert(await page.evaluate(time => audit.preview.currentTime > time, time), 'Preview playback time must advance while decoder is held');
      await page.evaluate(() => { audit.hold = false; audit.resume(); }); await page.waitForFunction(() => reading);
      for (let index = 2; index <= 9; index++) {
        await page.evaluate(key => changeWindow(key), index.toString(16).padStart(8, '0'));
        await page.waitForFunction(() => reading);
      }
      assert.deepEqual(await page.evaluate(() => [audit.streams.length, audit.workers.length, audit.bindings, audit.pauses, audit.emptied]), [1, 4, 1, 0, 0]);
      await page.evaluate(() => recoverScanner()); await page.waitForFunction(() => reading);
      assert.deepEqual(await page.evaluate(() => [audit.streams.length, audit.workers.length, audit.bindings, audit.pauses, audit.emptied]), [1, 8, 1, 0, 0]);
      await page.locator('#read').click();
      assert(await page.evaluate(() => audit.track.readyState === 'ended' && audit.preview.srcObject === null));
      assert.deepEqual(errors, []); await context.close();
    }
    console.log('PASS: desktop/mobile composited live pixels during delayed decoder startup; one stable preview binding, no pause/emptied across nine transitions; four reused workers; fault workers replaced without interrupting preview');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => server.close());
