const assert = require('node:assert/strict'), path = require('node:path');
const { randomBytes } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    await page.goto('file://' + path.resolve(__dirname, '../dist/knitkit2.html'));
    await page.waitForFunction(() => initialized);
    assert.equal(await page.title(), 'CimbarPlus Encoder');
    assert.equal(await page.locator('html').getAttribute('lang'), 'en');
    assert.doesNotMatch(await page.locator('body').innerText(), /[\u4e00-\u9fff]/, 'All built-in sender copy is English');
    assert.deepEqual(await page.locator('.sidebar > section').evaluateAll(sections => sections.map(el => el.className)), ['status-block', 'configuration', 'task-actions']);
    assert.equal(await page.locator('.configuration #mending').count(), 1);
    assert.equal(await page.locator('#replace').count(), 0, 'No redundant change-file action');
    assert.deepEqual(await page.locator('.task-actions button').allTextContents(), ['Start', 'Reset', 'Clear']);
    const regions = await page.locator('.status-block,.configuration,.task-actions').evaluateAll(items => items.map(el => el.getBoundingClientRect().toJSON()));
    assert.ok(regions[0].bottom <= regions[1].top && regions[1].bottom <= regions[2].top, 'Progress, configuration and actions do not overlap');
    assert.equal(await page.getByText('状态', { exact: true }).count(), 0);
    assert.equal(await page.locator('.caption').count(), 0);
    assert.deepEqual(await page.locator('#partSize option').allTextContents(), ['1M', '2M', '5M', '10M', '20M']);
    assert.deepEqual(await page.locator('#dwell option').evaluateAll(options => options.slice(0, 12).map(el => Number(el.value))), Array.from({ length: 12 }, (_, i) => (i + 1) * 5));
    assert.equal(await page.locator('#dwell').inputValue(), '20');
    for (const text of await page.locator('button').allTextContents()) assert.match(text, /^[A-Za-z]+(?: [A-Za-z]+)?$/);
    assert.equal(await page.locator('#reset').isDisabled(), true);
    assert.equal(await page.locator('#clear').isDisabled(), true);
    const chooser = page.waitForEvent('filechooser'); await page.locator('#choose').click();
    await (await chooser).setFiles({ name: 'picker.bin', mimeType: 'application/octet-stream', buffer: Buffer.from('picker') });
    await page.waitForFunction(() => ready && !preparing);
    const bytes = randomBytes(2 * 1048576 + 17).toString('base64');
    const drop = async target => {
      const data = await page.evaluateHandle(text => {
        const transfer = new DataTransfer();
        transfer.items.add(new File([Uint8Array.from(atob(text), c => c.charCodeAt(0))], '拖拽文件.bin'));
        return transfer;
      }, bytes);
      try { await page.locator(target).dispatchEvent('dragenter', { dataTransfer: data }); await page.locator(target).dispatchEvent('drop', { dataTransfer: data }); }
      finally { await data.dispose(); }
    };
    await drop('#dropZone'); await page.waitForFunction(() => ready && !preparing && file.name === '拖拽文件.bin');
    const id = await page.evaluate(() => manifest.id);
    assert.equal(await page.evaluate(() => manifest.partSize), 1048576);
    assert.equal(await page.locator('#fileSize').textContent(), '2.0M');
    assert.equal(await page.evaluate(() => manifest.hashes.length), 3);
    assert.equal(await page.locator('#dropZone').getAttribute('class'), 'visual');
    await page.locator('#play').click(); await page.waitForFunction(() => elapsed > .2);
    for (const value of ['15', '5', '25', '20']) {
      await page.locator('#dwell').selectOption(value);
      assert.equal(await page.evaluate(() => playing && ready && manifest.id), id, 'Fast dwell options must not restart or re-plan');
    }
    await page.locator('#mending').fill('3');
    await page.waitForFunction(() => playing && selected === 2 && !preparing);
    await page.locator('#reset').click(); await page.waitForFunction(() => ready && !preparing && selected === 0);
    assert.equal(await page.evaluate(() => manifest.id), id, 'Reset keeps identical packets and task identity');
    assert.deepEqual(await page.evaluate(() => order), [0, 1, 2]);
    assert.equal(await page.evaluate(() => playing || locked || mending || elapsed !== 0), false);
    assert.equal(await page.locator('#partSize').isDisabled(), false);
    assert.equal(await page.locator('#dwell').inputValue(), '20');
    await page.locator('#mending').fill('2'); await page.locator('#clear').click(); await page.waitForTimeout(850);
    assert.equal(await page.evaluate(() => !file && !manifest && !ready && !playing && order.length === 0), true);
    assert.equal(await page.locator('#mending').inputValue(), '');
    assert.equal(await page.locator('#pattern').inputValue(), '');
    assert.equal(await page.locator('#empty').isVisible(), true);
    assert.equal(await page.locator('#canvas').isVisible(), false);
    assert.equal(await page.locator('#dashboard').isVisible(), false);
    assert.equal(await page.locator('#lapProgress').getAttribute('value'), '0');
    assert.equal(await page.locator('#play').isDisabled(), true);
    assert.doesNotMatch(await page.locator('body').innerText(), /[\u4e00-\u9fff]/, 'Clear restores an English empty state');
    await page.evaluate(() => {
      window.originalPrepare = B.prepare;
      B.prepare = async (...args) => { await new Promise(resolve => setTimeout(resolve, 300)); return originalPrepare(...args); };
    });
    await drop('#empty'); await page.waitForFunction(() => preparing);
    assert.equal(await page.locator('#reset').isDisabled(), true);
    assert.equal(await page.locator('#clear').isDisabled(), true);
    await page.waitForFunction(() => ready && !preparing);
    assert.equal(await page.evaluate(() => manifest.id), id, 'Dropping the same file again works after clear');
    await page.evaluate(() => { B.prepare = originalPrepare; });
    assert.equal(await page.locator('#fps').inputValue(), '15');
    assert.equal(await page.locator('#mode').inputValue(), '68');
    await page.screenshot({ path: '/private/tmp/cimbarplus-workspace.png' });
    await page.locator('#clear').click();
    console.log('PASS: central file drop and picker, 5-second fast dwell steps, native defaults, deterministic reset, safe clear, queued replay cancellation and prepare guard');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
