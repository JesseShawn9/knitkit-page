const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const { test } = require('node:test');
test('read-only stream observation requests one fresh page per confirmed boundary', () => {
  const messages = [], handlers = {};
  const parent = { location: { origin: 'http://test' }, KnitNativeSources: { session: 9, worker: '', runtime: '' }, postMessage: data => messages.push(data) };
  const worker = { addEventListener: (name, fn) => { handlers[name] = fn; }, terminate() {} };
  const window = { Worker: function () { return worker; }, addEventListener() {} };
  const video = { readyState: 0, addEventListener() {} };
  const context = vm.createContext({ parent, window, Blob, Recv: { render_progress() {} }, Zstd: {}, setInterval: () => 1, clearInterval() {}, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} }, document: { getElementById: () => video } });
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../src/native-bridge.js'), 'utf8'), context);
  new window.Worker('recv-worker.2026-08-21T2336.js');
  const a = Uint8Array.from([5, 0, 1, 0, 0, 1, 99]), b = Uint8Array.from([6, 0, 1, 0, 0, 1, 88]);
  const original = Array.from(b), send = buff => handlers.message({ data: { buff } });
  send(a); assert.equal(messages[0].kind, 'stream'); assert.equal(messages[0].key, '05000100');
  send(b); send(a); send(b); assert.equal(messages.length, 1, 'Late old results cannot confirm a new boundary by themselves');
  send(b); assert.equal(messages[1].kind, 'segment'); assert.equal(messages[1].key, '06000100');
  send(a); send(b); assert.equal(messages.length, 2, 'Only one transition can be requested before disposal');
  assert.deepEqual(Array.from(b), original, 'Native symbol bytes must stay unmodified');
});
