const assert = require('node:assert/strict'), path = require('node:path');
const { randomBytes } = require('node:crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/jesse/Desktop/codingtools/playwright-cli/0.1.23/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage();
    await page.goto('file://' + path.resolve(__dirname, '../dist/knitkit2.html'));
    await page.waitForFunction(() => initialized);
    await page.locator('#pattern').setInputFiles({ name: 'replay.bin', mimeType: 'application/octet-stream', buffer: randomBytes(2 * 1024 * 1024 + 17) });
    await page.waitForFunction(() => ready && !preparing);
    assert.equal(await page.locator('#dwell').inputValue(), '30');
    await page.locator('#dwell').selectOption('20');
    const id = await page.evaluate(() => manifest.id);
    await page.locator('#play').click();
    await page.locator('#mending').fill('3'); await page.locator('#apply').click();
    await page.waitForFunction(() => playing && selected === 2 && !preparing);
    assert.deepEqual(await page.evaluate(() => order), [2]);
    assert.equal(await page.evaluate(() => manifest.id), id);
    await page.locator('#mending').fill('99'); await page.locator('#apply').click();
    assert.equal(await page.evaluate(() => playing && selected === 2), true, 'Invalid input must not interrupt current playback');
    await page.locator('#mending').fill('KK2M:' + id + ':1-2'); await page.locator('#apply').click();
    await page.waitForFunction(() => playing && selected === 0 && !preparing);
    assert.deepEqual(await page.evaluate(() => order), [0, 1]);
    assert.equal(await page.locator('#fps').inputValue(), '15'); assert.equal(await page.locator('#mode').inputValue(), '68');
    await page.locator('#play').click();
    console.log('PASS: numeric replay and task shortcode start immediately during playback, invalid input preserves current playback, 20/30s dwell and original 15fps/B parameters');
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
