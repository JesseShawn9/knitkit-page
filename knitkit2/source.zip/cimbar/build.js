const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const script = s => s.replace(/<\/script/gi, '<\\/script');
const wasm = fs.readFileSync(path.join(root, 'vendor/cimbar.wasm'));
const glue = read('vendor/cimbar.js');
for (const [data, expected] of [[wasm, '019a0d79419bdee0b918f409cdcfff919c172b75131dac5a36a44385151ca5af'],
  [glue, 'c18d4c47ffd9ad4bf6c5e6c9fb1e8a8aabf52eadf5dfa70844b904b1c67d5418']]) {
  if (crypto.createHash('sha256').update(data).digest('hex') !== expected) throw new Error('Unexpected vendor snapshot; verify provenance before updating');
}
function readerMemory(binary) {
  const output = Buffer.from(binary);
  let offset = 8;
  function unsigned() {
    let value = 0, shift = 0, byte;
    do {
      if (offset >= output.length || shift > 28) throw new Error('Invalid WASM section length');
      byte = output[offset++]; value += (byte & 127) * 2 ** shift; shift += 7;
    } while (byte & 128);
    return value;
  }
  while (offset < output.length) {
    const section = output[offset++], length = unsigned(), end = offset + length;
    if (end > output.length) throw new Error('Invalid WASM section boundary');
    if (section === 5) {
      // The pinned upstream has fixed 128MiB memory. Only change its limits to 512MiB.
      const before = Buffer.from([1, 1, 128, 16, 128, 16]);
      if (!output.subarray(offset, end).equals(before)) throw new Error('Unexpected upstream memory layout');
      Buffer.from([1, 1, 128, 64, 128, 64]).copy(output, offset);
      return output;
    }
    offset = end;
  }
  throw new Error('Upstream WASM memory section missing');
}
const readerWasm = readerMemory(wasm);
const memoryOffsets = [...readerWasm.keys()].filter(i => readerWasm[i] !== wasm[i]);
function boot(ready) {
  const binary = ready === 'worker' ? readerWasm : wasm;
  return `var knitBytes=Uint8Array.from(atob(${JSON.stringify(binary.toString('base64'))}),c=>c.charCodeAt(0));\nvar Module={canvas:typeof document==='undefined'?undefined:document.getElementById('canvas'),print:()=>{},printErr:()=>{},onAbort:e=>${ready === 'worker' ? "postMessage({kind:'error',message:String(e)})" : 'knitRuntimeFailed(e)'},instantiateWasm:(imports,success)=>{WebAssembly.instantiate(knitBytes,imports).then(r=>success(r.instance,r.module)).catch(e=>Module.onAbort(e));return {};},onRuntimeInitialized:()=>{${ready === 'worker' ? "postMessage({kind:'ready'})" : 'knitRuntimeReady()'}}};\n`;
}
function build(template, parts) {
  return read('src/' + template).replace(/__([A-Z]+)__/g, (token, name) => {
    if (!(name in parts)) throw new Error('Missing build token ' + token);
    return parts[name];
  });
}
const common = { STYLE: read('src/style.css'), PROTOCOL: script(read('src/batches.js')) };
if (crypto.createHash('sha256').update(read('vendor/fzstd.js')).digest('hex') !== 'fbea1c25c4413b620ca3f59e6037d9f6c675c5c7f690e4d660143188f686461d') throw new Error('Unexpected fzstd snapshot');
const workerBoot = boot('worker').replace('\nvar Module=', '\nif(typeof knitRole!=="undefined"&&knitRole==="collector"){' + memoryOffsets.map(i => 'knitBytes[' + i + ']=16;').join('') + '}\nvar Module=');
const worker = workerBoot + glue + ';\n' + read('vendor/fzstd.js') + ';\n' + read('src/batches.js') + ';\n' + read('src/storage.js') + ';\n' + read('src/reader-worker.js');
const output = path.join(root, 'dist'); fs.mkdirSync(output, { recursive: true });
if (!process.argv.includes('--reader-only')) fs.writeFileSync(path.join(output, 'knitkit2.html'), build('sender.html', {
  ...common, SENDER: script(read('src/sender.js')), RUNTIME: script(boot('sender') + glue)
}));
fs.writeFileSync(path.join(output, 'knitkit2-reader.html'), build('receiver.html', {
  ...common, STORAGE: script(read('src/storage.js')), RECEIVER: script(read('src/receiver.js')),
  WORKER: Buffer.from(worker).toString('base64')
}));
const sums = ['knitkit2.html', 'knitkit2-reader.html'].map(name =>
  crypto.createHash('sha256').update(fs.readFileSync(path.join(output, name))).digest('hex') + '  ' + name).join('\n') + '\n';
fs.writeFileSync(path.join(output, 'SHA256SUMS'), sums);
fs.copyFileSync(path.join(root, 'vendor/LICENSE'), path.join(output, 'LICENSE'));
fs.copyFileSync(path.join(root, 'vendor/fzstd-LICENSE'), path.join(output, 'fzstd-LICENSE'));
fs.writeFileSync(path.join(output, 'NOTICE.txt'), 'KnitKit2 uses libcimbar v0.6.8 (MPL-2.0).\nImage-reader builds change only the WASM memory limits from 128MiB to 512MiB; the fountain-only collector retains 128MiB. Codec instructions and vendor snapshots are unchanged.\nUpstream source: https://github.com/sz3/libcimbar/tree/v0.6.8\nfzstd 0.1.1 (MIT) reads partial Zstandard prefixes. Source: https://github.com/101arrowz/fzstd ; notice: fzstd-LICENSE.\nExtension and build source are included in the release source archive.\n');
console.log('Built independent KnitKit2 pages in ' + output);
