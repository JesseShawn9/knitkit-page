const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const script = s => s.replace(/<\/script/gi, '<\\/script');
const html = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const wasm = fs.readFileSync(path.join(root, 'vendor/cimbar.wasm'));
const glue = read('vendor/cimbar.js');
for (const [data, expected] of [[wasm, '019a0d79419bdee0b918f409cdcfff919c172b75131dac5a36a44385151ca5af'],
  [glue, 'c18d4c47ffd9ad4bf6c5e6c9fb1e8a8aabf52eadf5dfa70844b904b1c67d5418']]) {
  if (crypto.createHash('sha256').update(data).digest('hex') !== expected) throw new Error('Unexpected vendor snapshot; verify provenance before updating');
}
function boot(ready) {
  return `var knitBytes=Uint8Array.from(atob(${JSON.stringify(wasm.toString('base64'))}),c=>c.charCodeAt(0));\nvar Module={canvas:typeof document==='undefined'?undefined:document.getElementById('canvas'),print:()=>{},printErr:()=>{},onAbort:e=>${ready === 'worker' ? "postMessage({kind:'error',message:String(e)})" : 'knitRuntimeFailed(e)'},instantiateWasm:(imports,success)=>{WebAssembly.instantiate(knitBytes,imports).then(r=>success(r.instance,r.module)).catch(e=>Module.onAbort(e));return {};},onRuntimeInitialized:()=>{${ready === 'worker' ? "postMessage({kind:'ready'})" : 'knitRuntimeReady()'}}};\n`;
}
const license = `<details><summary>开源许可</summary><p>使用 libcimbar v0.6.8 内核。<a href="https://github.com/sz3/libcimbar/tree/v0.6.8">对应源码</a>。本扩展源码随包提供。</p><pre>${html(read('vendor/LICENSE'))}</pre></details>`;
function build(template, parts) {
  return read('src/' + template).replace(/__([A-Z]+)__/g, (token, name) => {
    if (!(name in parts)) throw new Error('Missing build token ' + token);
    return parts[name];
  });
}
const common = { STYLE: read('src/style.css'), PROTOCOL: script(read('src/batches.js')), LICENSE: license };
const worker = boot('worker') + glue + '\n' + read('src/reader-worker.js');
const output = path.join(root, 'dist'); fs.mkdirSync(output, { recursive: true });
fs.writeFileSync(path.join(output, 'knitkit2.html'), build('sender.html', {
  ...common, SENDER: script(read('src/sender.js')), RUNTIME: script(boot('sender') + glue)
}));
fs.writeFileSync(path.join(output, 'knitkit2-reader.html'), build('receiver.html', {
  ...common, STORAGE: script(read('src/storage.js')), RECEIVER: script(read('src/receiver.js')),
  WORKER: Buffer.from(worker).toString('base64')
}));
const sums = ['knitkit2.html', 'knitkit2-reader.html'].map(name =>
  crypto.createHash('sha256').update(fs.readFileSync(path.join(output, name))).digest('hex') + '  ' + name).join('\n') + '\n';
fs.writeFileSync(path.join(output, 'SHA256SUMS'), sums);
console.log('Built independent KnitKit2 pages in ' + output);
