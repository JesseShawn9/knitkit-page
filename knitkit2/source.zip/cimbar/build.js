const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const script = s => s.replace(/<\/script/gi, '<\\/script');
const wasm = fs.readFileSync(path.join(root, 'vendor/cimbar.wasm'));
const glue = read('vendor/cimbar.js');
const pinned = {
  'cimbar.wasm': '019a0d79419bdee0b918f409cdcfff919c172b75131dac5a36a44385151ca5af',
  'cimbar.js': 'c18d4c47ffd9ad4bf6c5e6c9fb1e8a8aabf52eadf5dfa70844b904b1c67d5418',
  'native-receiver.js': '55f2d37ece3930e6c79a7aa82e3f9dbfff7cd2d3497dd4743f1ba2ba8e4f6444',
  'native-worker.js': 'ab1ddadecc6ca25a92fd30b5daed03ff9f3e8b1c67aa3a47e98f795439d5e439',
  'native-zstd.js': '47feb486b4986140f2350f9068b2905195f905a6ba628f405105dc0e1a7596be',
  'native-page.html': '7e05e62c97bd99702fbf228008d890e31cf070fa80e140a92cbbb2bdd6a0659a'
};
for (const [name, expected] of Object.entries(pinned)) {
  if (crypto.createHash('sha256').update(fs.readFileSync(path.join(root, 'vendor', name))).digest('hex') !== expected) throw new Error('Unexpected upstream snapshot: ' + name);
}
function build(template, parts) {
  return read('src/' + template).replace(/__([A-Z]+)__/g, (token, name) => {
    if (!(name in parts)) throw new Error('Missing build token ' + token);
    return parts[name];
  });
}
const binary = JSON.stringify(wasm.toString('base64'));
const nativeRuntime = `var knitBytes=Uint8Array.from(atob(${binary}),c=>c.charCodeAt(0));
Module.print=()=>{};Module.printErr=()=>{};
Module.onAbort=Module.onAbort||(e=>{if(typeof KnitEngine!=='undefined')KnitEngine.fail(String(e));else postMessage({fatal:true,error:true,res:String(e)});});
Module.instantiateWasm=(imports,success)=>{WebAssembly.instantiate(knitBytes,imports).then(r=>success(r.instance,r.module)).catch(e=>Module.onAbort(e));return {};};
` + glue;
const nativeWorker = read('vendor/native-worker.js').replace("importScripts('cimbar_js.2026-08-21T2336.js');", '');
// Inline assets only. Camera capture, mode detection and decoding stay upstream.
const engine = read('vendor/native-page.html')
  .replace('  <link rel="manifest" href="pwa-recv.2026-08-21T2336.json">', '')
  .replace("    if ('serviceWorker' in navigator) {\n      navigator.serviceWorker.register('./recv-sw.js', { scope: '/recv.html' });\n    }", '')
  .replace('<script src="recv.2026-08-21T2336.js"></script>', () => '<script>var console={log:()=>{},info:()=>{},error:()=>{},warn:()=>{}};</script>\n<script>' + script(read('vendor/native-receiver.js')) + '</script>')
  .replace('<script src="zstd.2026-08-21T2336.js"></script>', () => '<script>' + script(read('vendor/native-zstd.js')) + '</script>\n<script>' + script(read('src/native-bridge.js')) + '</script>')
  .replace('<script src="cimbar_js.2026-08-21T2336.js"></script>', '<script>var knitRuntime=document.createElement("script");knitRuntime.textContent=parent.KnitNativeSources.runtime;document.head.appendChild(knitRuntime);</script>');
const common = { STYLE: read('src/style.css'), PROTOCOL: script(read('src/batches.js')) };
const output = path.join(root, 'dist'); fs.mkdirSync(output, { recursive: true });
if (!process.argv.includes('--reader-only')) fs.writeFileSync(path.join(output, 'knitkit2.html'), build('sender.html', {
  ...common, SENDER: script(read('src/sender.js')),
  RUNTIME: script(`var Module={canvas:document.getElementById('canvas'),onRuntimeInitialized:()=>knitRuntimeReady(),onAbort:e=>knitRuntimeFailed(e)};\n` + nativeRuntime)
}));
fs.writeFileSync(path.join(output, 'knitkit2-reader.html'), build('receiver.html', {
  ...common, STORAGE: script(read('src/storage.js')), RECEIVER: script(read('src/receiver.js')),
  RUNTIME: Buffer.from(nativeRuntime).toString('base64'),
  WORKER: Buffer.from(nativeWorker).toString('base64'), ENGINE: Buffer.from(engine).toString('base64')
}));
const sums = ['knitkit2.html', 'knitkit2-reader.html'].map(name =>
  crypto.createHash('sha256').update(fs.readFileSync(path.join(output, name))).digest('hex') + '  ' + name).join('\n') + '\n';
fs.writeFileSync(path.join(output, 'SHA256SUMS'), sums);
fs.copyFileSync(path.join(root, 'vendor/LICENSE'), path.join(output, 'LICENSE'));
fs.writeFileSync(path.join(output, 'NOTICE.txt'), 'KnitKit2 uses libcimbar v0.6.8 (MPL-2.0).\nThe original 2026-08-21 browser page, receiver, worker and Zstandard scripts are vendored unchanged.\nPackaging inlines assets and omits optional PWA registration; camera capture, native CSS, modes, decoding, WASM bytes and memory limits are unchanged.\nThe shell observes native progress and intercepts complete files for local validation, batch storage and assembly. Pause disposes the embedded page.\nUpstream: https://github.com/sz3/libcimbar/tree/v0.6.8 and https://cimbar.org/recv.html\nExtension and build source are included in the release source archive.\n');
console.log('Built standalone pages with the original Cimbar receiver runtime');
