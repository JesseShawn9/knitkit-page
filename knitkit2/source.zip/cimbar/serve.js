const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const pages = new Map([
  ['/', 'knitkit2-reader.html'],
  ['/knitkit2-reader.html', 'knitkit2-reader.html'],
  ['/knitkit2.html', 'knitkit2.html']
]);
const server = http.createServer((request, response) => {
  const name = pages.get(new URL(request.url, 'http://localhost').pathname);
  if (!name) { response.writeHead(404); response.end('Not found'); return; }
  fs.readFile(path.join(__dirname, 'dist', name), (error, data) => {
    if (error) { response.writeHead(500); response.end('Build pages first'); return; }
    response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(data);
  });
});
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.listen(Number(process.env.PORT || 4186), '127.0.0.1', () => {
  console.log('KnitKit2 reader: http://localhost:' + server.address().port + '/');
});
