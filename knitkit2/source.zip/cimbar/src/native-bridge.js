'use strict';
const hostOrigin = parent.location.origin;
const sources = parent.KnitNativeSources;
const emit = data => parent.postMessage({ knitNative: true, session: sources.session, ...data }, hostOrigin);
const cameraVideo = document.getElementById('video');
const BrowserWorker = window.Worker, workers = [];
const workerURL = URL.createObjectURL(new Blob([
  'var console={log:()=>{},info:()=>{},error:()=>{},warn:()=>{}};\n',
  sources.worker, ';\n', sources.runtime
], { type: 'text/javascript' }));
window.Worker = function (url, options) {
  const worker = new BrowserWorker(url === 'recv-worker.2026-08-21T2336.js' ? workerURL : url, options);
  workers.push(worker);
  return worker;
};
const nativeProgress = Recv.render_progress;
Recv.render_progress = report => {
  nativeProgress(report);
  emit({ kind: 'progress', report });
};
Zstd.download_blob = (name, blob) => emit({ kind: 'file', name, blob });
cameraVideo.addEventListener('playing', () => emit({ kind: 'camera', width: cameraVideo.videoWidth, height: cameraVideo.videoHeight }));
function disposeNative() {
  if (cameraVideo.srcObject) cameraVideo.srcObject.getTracks().forEach(track => track.stop());
  workers.forEach(worker => worker.terminate());
  URL.revokeObjectURL(workerURL);
}
window.addEventListener('pagehide', disposeNative);
window.addEventListener('message', event => {
  if (event.source === parent && event.origin === hostOrigin && event.data?.knitShell && event.data.kind === 'pause') disposeNative();
});
