'use strict';
const hostOrigin = parent.location.origin;
const session = parent.KnitNativeSources.session;
const emit = data => parent.postMessage({ knitNative: true, session, ...data }, hostOrigin);
const nativeMatchMedia = window.matchMedia.bind(window);
window.matchMedia = query => query === 'all and (orientation:landscape)' ? parent.matchMedia(query) : nativeMatchMedia(query);
const video = document.getElementById('video');
let active = false, runtimeReady = false, workersReady = 0, stream = null, epoch = 0, captures = 0, decoded = 0, lastReport = 0;
let frameSequence = 0, latestSequence = 0, currentWire = null, decompressing = false;
let submitted = 0, returned = 0, extractedEmpty = 0, extractFailed = 0, workerErrors = 0, diagnose = false;
let pixelInput = null, lastResult = '等待识别器返回';
const waiting = [];
function reportPipeline() {
  return { submitted, returned, extractedEmpty, extractFailed, workerErrors, decoded, pixelInput, lastResult };
}
const browserWorker = window.Worker;
const workerURL = URL.createObjectURL(new Blob([
  'var console={log:()=>{},info:()=>{},error:()=>{},warn:()=>{}};\n',
  parent.KnitNativeSources.worker, ';\n', parent.KnitNativeSources.runtime
], { type: 'text/javascript' }));
window.Worker = function () {
  const worker = new browserWorker(workerURL);
  const requests = [], post = worker.postMessage.bind(worker);
  worker.postMessage = (data, transfer) => {
    if (data.type === 'proc') {
      requests.push(++frameSequence); submitted++;
      pixelInput = { width: data.width, height: data.height, format: data.format, mode: data.mode, byteLength: data.pixels.byteLength };
      if (diagnose) {
        diagnose = false;
        emit({ kind: 'diagnostic-frame', input: pixelInput, pipeline: reportPipeline(), pixels: new Blob([data.pixels]) });
      }
    }
    post(data, transfer);
  };
  worker.addEventListener('message', event => {
    if (!event.data.ready) {
      event.data.shellSequence = requests.shift() || 0; returned++;
      if (event.data.buff && event.data.buff.length) lastResult = '已解出数据';
      else if (event.data.failed_extract) { extractFailed++; lastResult = '图案提取失败'; }
      else if (event.data.nodata) { extractedEmpty++; lastResult = '提取完成，未解出数据'; }
      else { workerErrors++; lastResult = '识别器报告异常'; }
    }
    if (event.data.ready && ++workersReady === 4 && runtimeReady) emit({ kind: 'ready' });
    if (event.data.fatal) emit({ kind: 'error', message: '原版识别引擎未能启动，请重新打开页面。' });
  });
  worker.addEventListener('error', () => emit({ kind: 'error', message: '原版识别引擎异常，请暂停后重试。' }));
  return worker;
};
const nativeMedia = navigator.mediaDevices && navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
if (nativeMedia) navigator.mediaDevices.getUserMedia = async constraints => {
  const token = epoch;
  const next = await nativeMedia(constraints);
  if (!active || token !== epoch) { next.getTracks().forEach(t => t.stop()); throw new DOMException('Paused', 'AbortError'); }
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = next; return next;
};
const initVideo = Recv.init_video, onFrame = Recv.on_frame, onDecode = Recv.on_decode;
Recv.init_video = value => { if (active) initVideo(value); };
Recv.on_frame = (now, metadata) => {
  if (!active) return;
  captures++;
  if (now - lastReport > 250) { lastReport = now; emit({ kind: 'capture', captures, decoded, pipeline: reportPipeline() }); }
  onFrame(now, metadata);
};
function receiveNative(wid, data) {
  if (data.buff && data.buff.length >= 4) {
    const wire = new DataView(data.buff.buffer, data.buff.byteOffset, 4).getUint32(0, true);
    if (wire !== currentWire) {
      if ((data.shellSequence || 0) < latestSequence) { Recv.frames_in_flight_decr(); return; }
      if (currentWire !== null) {
        // One independent original decoder session per segment; never rewrite symbols.
        Module._cimbard_configure_decode(data.mode === 68 ? 66 : 68);
        Module._cimbard_configure_decode(data.mode);
      }
      currentWire = wire;
    }
    latestSequence = Math.max(latestSequence, data.shellSequence || 0);
    decoded++; emit({ kind: 'decoded', captures, decoded });
  }
  onDecode(wid, data);
}
Recv.on_decode = (wid, data) => {
  if (decompressing && data.buff) waiting.push({ wid, data });
  else receiveNative(wid, data);
};
Recv.set_HTML = () => {};
Recv.on_capture_error = error => emit({ kind: 'error', message: '相机像素读取失败（' + (error.name || 'Error') + '），请暂停后重新读取。' });
Recv.set_error = message => { if (active) emit({ kind: 'error', message: String(message) }); return false; };
Recv.update_visual_state = () => {};
Recv.render_progress = report => emit({ kind: 'progress', report });
const decompress = Zstd.decompress;
Zstd.decompress = (name, id) => { decompressing = true; decompress(name, id); };
Zstd.download_blob = (name, blob) => {
  emit({ kind: 'file', name, blob }); decompressing = false;
  while (!decompressing && waiting.length) { const next = waiting.shift(); receiveNative(next.wid, next.data); }
};
video.addEventListener('playing', () => {
  if (active) emit({ kind: 'camera', width: video.videoWidth, height: video.videoHeight });
});
video.addEventListener('resize', () => emit({ kind: 'size', width: video.videoWidth, height: video.videoHeight }));
function pauseNative() {
  active = false; diagnose = false; epoch++;
  if (stream) stream.getTracks().forEach(t => t.stop());
  if (video.srcObject) video.srcObject.getTracks().forEach(t => t.stop());
  stream = null; video.srcObject = null;
}
window.addEventListener('message', event => {
  if (event.source !== parent || event.origin !== hostOrigin || !event.data.knitShell) return;
  if (event.data.kind === 'start') {
    if (active || !runtimeReady || workersReady !== 4) return;
    if (typeof VideoFrame === 'undefined') { emit({ kind: 'error', message: '此浏览器不支持原版取图接口，请更新Safari或Chrome。' }); return; }
    active = true; epoch++; Recv.init_video(video);
  } else if (event.data.kind === 'pause') pauseNative();
  else if (event.data.kind === 'diagnose' && active) diagnose = true;
});
window.addEventListener('pagehide', pauseNative);
window.KnitEngine = {
  fail: () => emit({ kind: 'error', message: '原版运行时未能加载，请重新打开页面。' }),
  ready() { runtimeReady = true; Recv.init_ww(4); }
};
var Module = { onRuntimeInitialized: () => KnitEngine.ready() };
const runtime = document.createElement('script'); runtime.textContent = parent.KnitNativeSources.runtime; document.head.appendChild(runtime);
