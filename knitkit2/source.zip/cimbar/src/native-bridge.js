'use strict';
const hostOrigin = parent.location.origin;
const sources = parent.KnitNativeSources;
const emit = data => parent.postMessage({ knitNative: true, session: sources.session, ...data }, hostOrigin);
const cameraVideo = document.getElementById('video');
const BrowserWorker = window.Worker, workers = [];
let disposed = false, cameraReported = false, lastWorkerReturn = Date.now(), stalled = false, progressKey = '';
let activeStream = sources.streamKey || '', nextStream = '', nextStreamFrames = 0, boundaryPending = false;
function observeStream(event) {
  lastWorkerReturn = Date.now();
  const bytes = event.data?.buff;
  if (disposed || boundaryPending || !ArrayBuffer.isView(bytes) || bytes.BYTES_PER_ELEMENT !== 1 || bytes.length < 6) return;
  const size = ((bytes[0] & 128) << 17) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];
  if (!size) return;
  // Original FountainMetadata bytes 0..3 identify a stream; never alter its data.
  const key = Array.from(bytes.subarray(0, 4), byte => byte.toString(16).padStart(2, '0')).join('');
  if (!activeStream) { activeStream = key; emit({ kind: 'stream', key }); }
  if (key === activeStream) { nextStream = ''; nextStreamFrames = 0; return; }
  if (key !== nextStream) { nextStream = key; nextStreamFrames = 0; }
  if (++nextStreamFrames < 2) return;
  boundaryPending = true; emit({ kind: 'segment', key });
}
function reportStall() {
  if (disposed || stalled || boundaryPending) return;
  stalled = true; emit({ kind: 'stalled' });
}
const workerURL = URL.createObjectURL(new Blob([
  'var console={log:()=>{},info:()=>{},error:()=>{},warn:()=>{}};\n',
  sources.worker, ';\n', sources.runtime
], { type: 'text/javascript' }));
window.Worker = function (url, options) {
  const worker = new BrowserWorker(url === 'recv-worker.2026-08-21T2336.js' ? workerURL : url, options);
  worker.addEventListener('message', observeStream);
  worker.addEventListener('error', reportStall);
  worker.addEventListener('messageerror', reportStall);
  workers.push(worker);
  return worker;
};
const nativeProgress = Recv.render_progress;
Recv.render_progress = report => {
  nativeProgress(report);
  const key = JSON.stringify(report.map(value => Math.floor(value * 100)));
  if (key !== progressKey) { progressKey = key; emit({ kind: 'progress', report }); }
};
Zstd.download_blob = (name, blob) => emit({ kind: 'file', name, blob });
function reportCameraReady() {
  if (disposed || cameraReported || cameraVideo.readyState < 2 || cameraVideo.paused || !cameraVideo.videoWidth || !cameraVideo.videoHeight) return;
  cameraReported = true; clearInterval(cameraReadyTimer);
  emit({ kind: 'camera', width: cameraVideo.videoWidth, height: cameraVideo.videoHeight });
}
for (const event of ['playing', 'loadeddata', 'canplay', 'resize', 'timeupdate']) cameraVideo.addEventListener(event, reportCameraReady);
// Read metadata only: a missed playing event must not leave the shell waiting.
const cameraReadyTimer = setInterval(reportCameraReady, 250);
// Observe only queue metadata; no decoded progress is not evidence of a stall.
const healthTimer = setInterval(() => {
  const queued = Number(document.getElementById('framesInFlight')?.textContent);
  if (cameraReported && queued > 20 && Date.now() - lastWorkerReturn >= 8000) reportStall();
}, 1000);
reportCameraReady();
function disposeNative() {
  if (disposed) return;
  disposed = true; clearInterval(cameraReadyTimer); clearInterval(healthTimer);
  if (cameraVideo.srcObject) cameraVideo.srcObject.getTracks().forEach(track => track.stop());
  cameraVideo.srcObject = null;
  workers.splice(0).forEach(worker => worker.terminate());
  URL.revokeObjectURL(workerURL);
}
window.addEventListener('pagehide', disposeNative);
window.addEventListener('message', event => {
  if (event.source === parent && event.origin === hostOrigin && event.data?.knitShell && event.data.kind === 'pause') disposeNative();
});
