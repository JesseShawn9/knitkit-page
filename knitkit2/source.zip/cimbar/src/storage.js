(function (root) {
  'use strict';
  let opening;
  function db() {
    if (!opening) opening = new Promise((resolve, reject) => {
      if (!root.indexedDB) { reject(new Error('此浏览器不能保存任务，请使用普通浏览模式。')); return; }
      const request = indexedDB.open('knitkit2-batches', 1);
      request.onupgradeneeded = () => {
        request.result.createObjectStore('tasks', { keyPath: 'id' });
        request.result.createObjectStore('parts', { keyPath: ['id', 'index'] }).createIndex('task', 'id');
      };
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('任务存储被其他页面占用，请关闭重复页面后重试。'));
      request.onsuccess = () => { request.result.onversionchange = () => request.result.close(); resolve(request.result); };
    });
    return opening;
  }
  async function transact(stores, mode, action) {
    const connection = await db();
    return new Promise((resolve, reject) => {
      const tx = connection.transaction(stores, mode);
      let value;
      try { value = action(tx); } catch (error) { tx.abort(); reject(error); return; }
      tx.oncomplete = () => resolve(typeof value === 'function' ? value() : value);
      tx.onabort = tx.onerror = () => reject(tx.error || new Error('本地任务保存失败，可能空间不足。'));
    });
  }
  root.KnitStore = {
    async tasks() {
      return transact(['tasks'], 'readonly', tx => {
        const request = tx.objectStore('tasks').getAll();
        return () => request.result.sort((a, b) => b.updated - a.updated);
      });
    },
    async put(manifest, index, data) {
      return transact(['tasks', 'parts'], 'readwrite', tx => {
        tx.objectStore('tasks').put({ id: manifest.id, manifest, updated: Date.now() });
        tx.objectStore('parts').put({ id: manifest.id, index, data });
      });
    },
    async indices(id) {
      return transact(['parts'], 'readonly', tx => {
        const request = tx.objectStore('parts').index('task').getAllKeys(IDBKeyRange.only(id));
        return () => request.result.map(key => key[1]);
      });
    },
    async part(id, index) {
      return transact(['parts'], 'readonly', tx => {
        const request = tx.objectStore('parts').get([id, index]);
        return () => request.result && request.result.data;
      });
    },
    async remove(id) {
      return transact(['tasks', 'parts'], 'readwrite', tx => {
        tx.objectStore('tasks').delete(id);
        const request = tx.objectStore('parts').index('task').openCursor(IDBKeyRange.only(id));
        request.onsuccess = () => { const cursor = request.result; if (cursor) { cursor.delete(); cursor.continue(); } };
      });
    }
  };
})(globalThis);
