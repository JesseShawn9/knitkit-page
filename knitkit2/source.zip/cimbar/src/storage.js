(function (root) {
  'use strict';
  let opening;
  function db() {
    if (!opening) opening = new Promise((resolve, reject) => {
      if (!root.indexedDB) { reject(new Error('此浏览器不能保存任务，请使用普通浏览模式。')); return; }
      const request = indexedDB.open('knitkit2-batches', 2);
      request.onupgradeneeded = () => {
        const d = request.result;
        if (!d.objectStoreNames.contains('tasks')) d.createObjectStore('tasks', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('parts')) d.createObjectStore('parts', { keyPath: ['id', 'index'] }).createIndex('task', 'id');
        if (!d.objectStoreNames.contains('skeins')) d.createObjectStore('skeins', { keyPath: 'key' });
        if (!d.objectStoreNames.contains('stitches')) d.createObjectStore('stitches', { keyPath: ['key', 'block'] }).createIndex('skein', 'key');
      };
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('任务存储被其他页面占用，请关闭重复页面后重试。'));
      request.onsuccess = () => { request.result.onversionchange = () => request.result.close(); resolve(request.result); };
    });
    return opening;
  }
  async function transact(stores, mode, action) {
    const connection = await db();
    return new Promise((resolve, reject) => {
      let tx;
      try { tx = connection.transaction(stores, mode, { durability: 'strict' }); }
      catch (error) { if (!(error instanceof TypeError)) throw error; tx = connection.transaction(stores, mode); }
      let value;
      try { value = action(tx); } catch (error) { tx.abort(); reject(error); return; }
      tx.oncomplete = () => resolve(typeof value === 'function' ? value() : value);
      tx.onabort = tx.onerror = () => reject(tx.error && tx.error.name !== 'QuotaExceededError' ? tx.error : new Error('本地任务保存失败，可能空间不足。已保存的进度仍在，请先释放空间。'));
    });
  }
  root.KnitStore = {
    async remember(manifest) {
      return transact(['tasks'], 'readwrite', tx => tx.objectStore('tasks').put({ id: manifest.id, manifest, updated: Date.now() }));
    },
    async skeins() {
      return transact(['skeins'], 'readonly', tx => {
        const r = tx.objectStore('skeins').getAll(); return () => r.result.sort((a, b) => b.updated - a.updated);
      });
    },
    async stitches(key) {
      return transact(['stitches'], 'readonly', tx => {
        const r = tx.objectStore('stitches').index('skein').getAll(IDBKeyRange.only(key)); return () => r.result;
      });
    },
    async journal(skein, stitches) {
      return transact(['skeins', 'stitches'], 'readwrite', tx => {
        tx.objectStore('skeins').put({ ...skein, updated: Date.now() });
        for (const stitch of stitches) tx.objectStore('stitches').put({ key: skein.key, block: stitch.block, bytes: stitch.bytes });
      });
    },
    async dropSkein(key) {
      return transact(['skeins', 'stitches'], 'readwrite', tx => {
        tx.objectStore('skeins').delete(key);
        const r = tx.objectStore('stitches').index('skein').openCursor(IDBKeyRange.only(key));
        r.onsuccess = () => { const c = r.result; if (c) { c.delete(); c.continue(); } };
      });
    },
    async tasks() {
      return transact(['tasks'], 'readonly', tx => {
        const request = tx.objectStore('tasks').getAll();
        return () => request.result.sort((a, b) => b.updated - a.updated);
      });
    },
    async put(manifest, index, data) {
      // Persist owned bytes, not a sliced Blob backed by the native download.
      const bytes = await data.arrayBuffer();
      return transact(['tasks', 'parts'], 'readwrite', tx => {
        tx.objectStore('tasks').put({ id: manifest.id, manifest, updated: Date.now() });
        tx.objectStore('parts').put({ id: manifest.id, index, data: bytes });
      });
    },
    async indices(id) {
      return transact(['parts'], 'readonly', tx => {
        const request = tx.objectStore('parts').index('task').getAllKeys(IDBKeyRange.only(id));
        return () => request.result.map(key => key[1]);
      });
    },
    async part(id, index) {
      return transact(['parts'], 'readonly', tx => {
        const request = tx.objectStore('parts').get([id, index]);
        return () => {
          const data = request.result && request.result.data;
          return data == null || data instanceof Blob ? data : new Blob([data]);
        };
      });
    },
    async dropPart(id, index) {
      return transact(['parts'], 'readwrite', tx => tx.objectStore('parts').delete([id, index]));
    },
    async remove(id) {
      for (const s of await this.skeins()) if (s.task === id) await this.dropSkein(s.key);
      return transact(['tasks', 'parts'], 'readwrite', tx => {
        tx.objectStore('tasks').delete(id);
        const request = tx.objectStore('parts').index('task').openCursor(IDBKeyRange.only(id));
        request.onsuccess = () => { const cursor = request.result; if (cursor) { cursor.delete(); cursor.continue(); } };
      });
    }
  };
})(globalThis);
