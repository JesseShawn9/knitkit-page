'use strict';
const B = KnitBatches, $ = id => document.getElementById(id);
let manifest = null, have = new Set(), reading = false, starting = false, merging = false, pending = 0;
let engineReady = false, engineRequested = false, outputURL = null, serial = Promise.resolve(), lamp = null, readTimer = 0;
let nativeEpoch = 0;
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint; $('status').dataset.error = error;
  $('liveNotice').textContent = title; $('liveNotice').dataset.error = error;
}
function controls() {
  const done = manifest && have.size === manifest.hashes.length;
  $('read').disabled = reading || starting || merging || pending > 0 || (done && !!outputURL);
  $('pause').disabled = !reading && !starting;
  $('copy').disabled = $('liveCopy').disabled = !manifest || done || merging || pending > 0;
  $('livePause').disabled = !reading && !starting;
  $('clear').disabled = $('other').disabled = !manifest || reading || starting || merging || pending > 0;
  for (const button of $('taskList').children) button.disabled = reading || starting || merging || pending > 0;
}
function render() {
  const total = manifest ? manifest.hashes.length : 0;
  $('gathered').textContent = manifest ? have.size + ' / ' + total : '0';
  $('missing').textContent = manifest ? String(total - have.size) : '等待首段';
  $('filename').hidden = !manifest; $('batches').hidden = !manifest;
  $('filenameArea').hidden = !manifest;
  $('mendingArea').hidden = !manifest || have.size === total;
  $('mending').value = manifest && have.size < total ? B.mending(manifest, have) : '';
  $('missingText').textContent = manifest ? '待收：' + (B.ranges(manifest.hashes.map((_, i) => i).filter(i => !have.has(i))) || '已全部收齐') : '';
  $('liveSaved').textContent = manifest ? '已存 ' + have.size + ' / ' + total : '等待首段';
  $('liveMissing').textContent = manifest ? '待补：' + (B.ranges(manifest.hashes.map((_, i) => i).filter(i => !have.has(i))) || '无') : '待补：首段收齐后显示';
  $('totalProgress').value = total ? have.size / total : 0;
  $('totalPercent').textContent = total ? Math.floor(have.size / total * 100) + '%' : '0%';
  $('totalLabel').textContent = manifest ? '已保存 ' + have.size + ' / ' + total + ' 段' : '总进度';
  $('batchList').replaceChildren();
  if (manifest) {
    $('filename').textContent = manifest.name; $('filename').title = manifest.name;
    for (let i = 0; i < total; i++) {
      const item = document.createElement('span'); item.className = 'batch-item'; item.dataset.done = String(have.has(i));
      item.textContent = String(i + 1); item.title = '第' + (i + 1) + '段：' + (have.has(i) ? '已保存' : '待收');
      const state = document.createElement('small'); state.textContent = have.has(i) ? '已存' : '待收'; item.appendChild(state);
      item.setAttribute('aria-label', item.title); $('batchList').appendChild(item);
    }
  }
  controls();
}
function revokeOutput() {
  if (outputURL) URL.revokeObjectURL(outputURL);
  outputURL = null; $('saveArea').hidden = true; $('save').removeAttribute('href');
}
async function tasks() {
  const list = await KnitStore.tasks(); $('tasks').hidden = list.length === 0; $('taskList').replaceChildren();
  for (const task of list) {
    const button = document.createElement('button'); button.type = 'button';
    const name = document.createElement('span'); name.textContent = task.manifest.name;
    const date = document.createElement('small'); date.textContent = new Date(task.updated).toLocaleString();
    button.append(name, date); button.title = task.manifest.name;
    button.addEventListener('click', () => restore(task.manifest).catch(fail)); $('taskList').appendChild(button);
  }
  controls();
}
async function restore(value) {
  if (reading || starting || merging || pending) return;
  pending++; controls();
  try {
    await B.validate(value); resetEngine(); revokeOutput(); manifest = value; have = new Set(await KnitStore.indices(value.id));
    $('tasks').hidden = true; render();
    status('已恢复任务', '已保存段不必重扫。点击读取，再让源端播放待收段。');
    if (have.size === manifest.hashes.length) await merge();
  } finally { pending--; controls(); }
}
function command(kind) { $('nativeView').contentWindow.postMessage({ knitShell: true, kind }, location.origin); }
function pause() {
  reading = starting = false; clearTimeout(readTimer); command('pause');
  resetEngine(); document.body.classList.remove('native-active');
  $('scanDock').hidden = true;
  if (lamp) { lamp.release().catch(() => {}); lamp = null; }
  $('badge').textContent = '已暂停'; $('empty').hidden = false; $('empty').textContent = '已暂停'; controls();
}
function resetEngine() {
  nativeEpoch++; engineReady = engineRequested = false; $('nativeView').srcdoc = '';
}
function fail(error) { pause(); status('需要处理后继续', error.message || String(error), true); }
function markReading() {
  if (!starting && !reading) return false;
  clearTimeout(readTimer);
  if (reading) return true;
  starting = false; reading = engineReady = true; $('empty').hidden = true; $('badge').textContent = '读取中';
  status('正在识别图案', '完整段会自动保存，接着读取下一段。'); controls();
  if (navigator.wakeLock) navigator.wakeLock.request('screen').then(lock => { if (reading) lamp = lock; else lock.release().catch(() => {}); }).catch(() => {});
  return true;
}
async function start() {
  if (reading || starting || merging || pending) return;
  resetEngine();
  $('partialProgress').value = 0; $('partial').textContent = '0%'; $('scanState').textContent = '等待识别图案'; $('extraProgress').replaceChildren();
  starting = true; controls(); $('badge').textContent = '开启相机';
  status('正在打开原版接收页', '相机就绪后，对准完整图案。');
  engineRequested = true;
  window.KnitNativeSources = { runtime: decode('nativeRuntime'), worker: decode('readerSource'), session: nativeEpoch };
  document.body.classList.add('native-active');
  $('scanDock').hidden = false;
  $('nativeView').srcdoc = decode('nativeEngine');
  readTimer = setTimeout(() => { if (starting) status('等待原版相机就绪', '若权限提示已处理，请继续等待；相机不会因计时自动关闭。'); }, 30000);
}
async function merge() {
  if (merging || !manifest || have.size !== manifest.hashes.length) return;
  merging = true; controls(); revokeOutput();
  try {
    const blob = await B.assemble(manifest, i => KnitStore.part(manifest.id, i), (done, total) => status('正在合并原文件', '校验 ' + done + ' / ' + total + ' 段，请勿关闭页面。'));
    pause();
    outputURL = URL.createObjectURL(blob); $('save').href = outputURL; $('save').download = B.safeName(manifest.name);
    $('saveArea').hidden = false; $('badge').textContent = '全部完成';
    $('partialProgress').value = 1; $('partial').textContent = '100%'; $('scanState').textContent = '全部分段已收齐'; $('extraProgress').replaceChildren();
    status('已收齐，保存原文件', '全部分段的内容、顺序和大小已校验通过。');
  } catch (error) {
    if (!Number.isSafeInteger(error.partIndex) || error.partIndex < 0 || error.partIndex >= manifest.hashes.length) throw error;
    have.delete(error.partIndex); render(); await KnitStore.dropPart(manifest.id, error.partIndex);
    status('需要补收第' + (error.partIndex + 1) + '段', reading ? '其余已保存段保留，相机继续读取。' : '其余已保存段保留，可复制待补短码后继续读取。', true);
  } finally { merging = false; controls(); }
}
async function accept(blob) {
  let value;
  try { value = await B.unpack(blob); }
  catch (error) {
    const title = manifest && error.taskId === manifest.id && Number.isSafeInteger(error.partIndex) ? '第' + (error.partIndex + 1) + '段未通过校验' : '这一段未通过校验';
    status(title, '未计入完成，其他进度不变。继续读取，稍后补收。' + error.message, true); return false;
  }
  if (manifest && manifest.id !== value.manifest.id) {
    status('不是当前任务', '当前任务没有改变。请播放当前文件的待收段，或暂停后切换任务。', true); return false;
  }
  if (!manifest) { manifest = value.manifest; revokeOutput(); have = new Set(await KnitStore.indices(manifest.id)); }
  if (!have.has(value.index)) { await KnitStore.put(manifest, value.index, value.data); have.add(value.index); }
  $('tasks').hidden = true; render();
  status('第' + (value.index + 1) + '段已保存', reading ? '等待源端自动切到下一段。本轮结束后可复制待收短码补收。' : '点击读取继续，或复制待收短码到源端。');
  if (have.size === manifest.hashes.length) await merge(); return true;
}
window.addEventListener('message', event => {
  if (event.source !== $('nativeView').contentWindow || event.origin !== location.origin || !event.data || !event.data.knitNative || event.data.session !== nativeEpoch) return;
  const data = event.data;
  if (data.kind === 'camera') {
    if (!markReading()) { command('pause'); return; }
  }
  if (data.kind === 'progress' && Array.isArray(data.report) && (!manifest || have.size < manifest.hashes.length)) {
    markReading();
    const list = data.report.map(Number).filter(Number.isFinite).map(v => Math.max(0, Math.min(1, v)));
    $('partialProgress').value = list[0] || 0; $('partial').textContent = Math.floor((list[0] || 0) * 100) + '%';
    $('scanState').textContent = list.length > 1 ? '识别进度（' + list.length + '组）' : list.length ? '本段识别进度' : '等待下一段';
    $('extraProgress').replaceChildren();
    for (const value of list.slice(1)) { const progress = document.createElement('progress'); progress.max = 1; progress.value = value; progress.setAttribute('aria-label', '其他原版识别进度'); $('extraProgress').appendChild(progress); }
  }
  if (data.kind === 'file') {
    markReading();
    pending++; controls(); serial = serial.then(() => accept(data.blob)).catch(fail).finally(() => { pending--; controls(); });
  }
  if (data.kind === 'error') fail(new Error(data.message));
});
$('read').addEventListener('click', start);
$('pause').addEventListener('click', () => { pause(); status('已暂停', '已保存的完整段保留。未完成段会在补收轮重新读取。'); });
async function copyMissing() {
  if (!manifest || have.size === manifest.hashes.length) return;
  const code = B.mending(manifest, have);
  try { await navigator.clipboard.writeText(code); $('liveCode').hidden = true; status('待补短码已复制', reading ? '扫描继续。可在源端粘贴短码，播放指定待补段。' : '粘贴到源端，读取待补段即可。'); }
  catch {
    const field = reading || starting ? $('liveCode') : $('mending');
    field.value = code; field.hidden = false; field.focus(); field.select();
    status('请长按复制选中的短码', '当前浏览器没有自动复制权限，扫描不会因此暂停。');
  }
}
$('copy').addEventListener('click', copyMissing);
$('liveCopy').addEventListener('click', copyMissing);
$('livePause').addEventListener('click', () => $('pause').click());
$('other').addEventListener('click', async () => {
  if (reading || starting || merging || pending) return;
  resetEngine(); revokeOutput(); manifest = null; have.clear(); render(); await tasks(); status('选择任务，或读取新文件', '已保存任务没有删除。');
});
$('clear').addEventListener('click', async () => {
  if (reading || starting || merging || pending || !manifest || !confirm('删除当前任务及已保存段？此操作不可撤销。')) return;
  try { await KnitStore.remove(manifest.id); revokeOutput(); manifest = null; have.clear(); render(); await tasks(); status('任务已删除', '可以读取新的文件。'); } catch (error) { fail(error); }
});
window.addEventListener('pagehide', pause);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && (reading || starting)) { pause(); status('读取已暂停', '返回页面后点击读取。已完成段仍保留。'); } });
const decode = id => new TextDecoder().decode(Uint8Array.from(atob($(id).textContent.trim()), c => c.charCodeAt(0)));
window.KnitReceiver = { start, pause, accept, restore };
tasks().catch(fail); render();
