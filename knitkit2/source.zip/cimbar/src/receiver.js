'use strict';
const B = KnitBatches;
const $ = id => document.getElementById(id);
let manifest = null, have = new Set(), reading = false, starting = false, merging = false;
let stream = null, worker = null, workerReady = false, busy = false, clock = 0, videoCallback = 0;
let frames = 0, outputURL = null, serial = Promise.resolve(), pending = 0;
let cameraEpoch = 0, lamp = null;
let cameraRatio = 16 / 9;
let captured = 0, lastDecoded = 0, lastResult = 0;
let pool = [], collector = null, collectorTimer = 0, workerSource = null, inFlight = 0, sequence = 0, nextSequence = 1, lastCapture = 0;
let workerEpoch = 0, lastCollected = 0;
const results = new Map(), partials = new Map();
const touchApple = /iPhone|iPad|iPod/.test(navigator.userAgent) || (/Mac/.test(navigator.platform) && navigator.maxTouchPoints > 1);
const phone = /iPhone|iPod/.test(navigator.userAgent);
const workerCount = phone ? 1 : touchApple ? 2 : Math.max(1, Math.min(4, Math.floor((navigator.hardwareConcurrency || 4) / 3)));
const cadence = phone ? 120 : touchApple ? 80 : 50;
const capture = document.createElement('canvas');
const context = capture.getContext('2d', { willReadFrequently: true });
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint; $('status').dataset.error = error;
}
function controls() {
  $('read').disabled = reading || starting || merging || (manifest && have.size === manifest.hashes.length);
  $('pause').disabled = !reading && !starting;
  $('copy').disabled = !manifest || have.size === manifest.hashes.length;
  $('clear').disabled = !manifest || reading || starting || merging || pending > 0 || inFlight > 0;
  $('other').disabled = !manifest || reading || starting || merging || pending > 0 || inFlight > 0;
  $('clearUnbound').hidden = ![...partials.values()].some(s => !s.task);
  $('clearUnbound').disabled = reading || starting || merging || pending > 0 || inFlight > 0;
  for (const button of $('taskList').children) button.disabled = reading || starting || merging || pending > 0 || inFlight > 0;
  if (workerReady) $('engineState').textContent = pool.length + ' 路识别 · 1 路汇总' + (inFlight ? ' · ' + inFlight + ' 张处理中' : '');
  if (!reading && !starting && !merging && !pending && !inFlight && partials.size && (!manifest || have.size < manifest.hashes.length)) $('scanState').textContent = '已暂存 · 等待继续读取';
}
function render() {
  $('gathered').textContent = manifest ? have.size + ' / ' + manifest.hashes.length : '0';
  $('missing').textContent = manifest ? String(manifest.hashes.length - have.size) : '尚未确定';
  $('batches').hidden = !manifest; $('filename').hidden = !manifest;
  $('mendingArea').hidden = !manifest || have.size === manifest.hashes.length;
  $('mending').value = manifest && have.size < manifest.hashes.length ? B.mending(manifest, have) : '';
  $('missingText').textContent = manifest ? '待收段：' + (B.ranges(manifest.hashes.map((_, i) => i).filter(i => !have.has(i))) || '已全部收齐') : '';
  const fraction = manifest ? have.size / manifest.hashes.length : 0;
  $('totalProgress').value = fraction; $('totalPercent').textContent = Math.floor(fraction * 100) + '%';
  $('totalLabel').textContent = manifest ? '已保存 ' + have.size + ' / ' + manifest.hashes.length + ' 段' : '总进度 · 等待首段完成';
  if (manifest) {
    $('filename').textContent = manifest.name; $('filename').title = manifest.name;
    const list = $('batchList'); list.replaceChildren();
    for (let i = 0; i < manifest.hashes.length; i++) {
      const button = document.createElement('button'); button.type = 'button';
      button.dataset.done = String(have.has(i));
      button.setAttribute('aria-label', '第' + (i + 1) + '段，' + (have.has(i) ? '已完成' : '待收'));
      button.append(String(i + 1).padStart(2, '0'));
      const label = document.createElement('small'); label.textContent = have.has(i) ? '已完成' : '待收'; button.append(label);
      const cached = [...partials.values()].find(s => s.task === manifest.id && s.index === i && !s.done);
      if (cached && !have.has(i)) label.textContent = Math.floor(cached.progress * 100) + '% · 已暂存';
      button.title = '复制待收短码到源端，补收这一段';
      button.addEventListener('click', () => status('第' + (i + 1) + '段' + (have.has(i) ? '已完成' : '待收'),
        have.has(i) ? '这一段已经保存在本浏览器，无需重扫。' : '复制待收短码到源端，载入补收轮。轮到这一段时会接续已有进度。'));
      list.append(button);
    }
  }
  controls();
}
function renderPartials() {
  const list = [...partials.values()].filter(s => !s.done && !s.consumed && (!manifest || !s.task || s.task === manifest.id));
  $('unfinished').hidden = list.length === 0;
  $('unfinishedText').textContent = list.slice(0, 30).map(s => (s.task ? '第' + (s.index + 1) + '段' : '待确认分段') + ' ' + Math.floor((s.progress || 0) * 100) + '%').join(' · ') + (list.length > 30 ? ' · 共' + list.length + '段' : '');
  $('storageHint').textContent = list.length ? '已暂存 ' + list.length + ' 个未完成段。轮到同一段会尝试自动接续；不要清理网站数据。' : '已完成段与未完成进度保存在此浏览器，不要清理网站数据。';
}
function cameraLayout() {
  const video = $('video');
  if (video.videoWidth && video.videoHeight) cameraRatio = video.videoWidth / video.videoHeight;
  video.closest('.stage').style.setProperty('--camera-ratio', $('wideView').checked ? 16 / 9 : cameraRatio);
}
function partial(value, label) {
  value = Math.max(0, Math.min(1, value));
  $('partialProgress').value = value; $('partial').textContent = Math.floor(value * 100) + '%';
  if (label) $('scanState').textContent = label;
}
function revokeOutput() {
  if (outputURL) URL.revokeObjectURL(outputURL);
  outputURL = null; $('saveArea').hidden = true; $('save').removeAttribute('href');
}
async function tasks() {
  const list = await KnitStore.tasks();
  $('tasks').hidden = list.length === 0;
  $('taskList').replaceChildren();
  for (const task of list) {
    const button = document.createElement('button'); button.type = 'button';
    const name = document.createElement('span'); name.textContent = task.manifest.name;
    const date = document.createElement('small'); date.textContent = new Date(task.updated).toLocaleString();
    button.append(name, date); button.title = task.manifest.name;
    button.addEventListener('click', () => restore(task.manifest).catch(fail));
    $('taskList').append(button);
  }
  controls();
}
async function restore(value) {
  if (reading || starting || merging || pending || inFlight) return;
  await B.validate(value);
  disposeWorker(); revokeOutput(); manifest = value;
  have = new Set(await KnitStore.indices(value.id));
  $('tasks').hidden = true; render();
  renderPartials();
  const cached = [...partials.values()].filter(s => s.task === value.id && !s.done).sort((a, b) => (b.updated || 0) - (a.updated || 0))[0];
  partial(cached ? cached.progress : 0, cached ? '第' + (cached.index + 1) + '段已暂存 · 等待继续' : '等待读取待收段');
  status('已恢复任务', '已完成段与暂存进度仍在。点击读取，再让源端播放待收序号。');
  if (have.size === manifest.hashes.length) await merge();
}
function fail(error) {
  pause();
  status('需要处理后再继续', error.message || String(error), true);
  controls();
}
async function merge() {
  if (merging || !manifest || have.size !== manifest.hashes.length) return;
  pause(); merging = true; controls(); revokeOutput();
  try {
    const blob = await B.assemble(manifest, i => KnitStore.part(manifest.id, i), (done, total) => {
      status('正在自动合并', '逐段复核 ' + done + ' / ' + total + '，请不要关闭页面。');
    });
    outputURL = URL.createObjectURL(blob);
    $('save').href = outputURL; $('save').download = B.safeName(manifest.name); $('saveArea').hidden = false;
    $('badge').textContent = '全部完成'; partial(1, '全部分段已收齐');
    status('已合并，可以保存原文件', '全部分段的SHA-256与原清单一致，顺序和总大小校验通过。');
  } finally { merging = false; controls(); }
}
async function accept(blob) {
  const value = await B.unpack(blob);
  if (manifest && manifest.id !== value.manifest.id) {
    status('读到了其他任务', '当前任务未改变。请让源端播放当前文件，或暂停后选择其他历史任务。', true);
    return false;
  }
  if (!manifest) {
    manifest = value.manifest; revokeOutput();
    have = new Set(await KnitStore.indices(manifest.id));
  }
  if (!have.has(value.index)) {
    await KnitStore.put(manifest, value.index, value.data);
    have.add(value.index);
  }
  $('tasks').hidden = true; render();
  status('第' + (value.index + 1) + '段已保存',
    reading ? '等待源端自动切段；本轮结束后暂停，复制待收短码补收。' : '这一段已保存。点击读取继续，或复制待收短码到源端补收。');
  partial(1, '第' + (value.index + 1) + '段已保存，等待下一段');
  if (have.size === manifest.hashes.length) await merge();
  return true;
}
function disposeWorker() {
  workerEpoch++;
  for (const slot of pool) { clearTimeout(slot.timeout); slot.worker.terminate(); }
  clearTimeout(collectorTimer);
  if (collector) collector.terminate();
  pool = []; collector = null; worker = null; workerReady = false; busy = false;
  inFlight = 0; results.clear(); sequence = 0; nextSequence = 1;
  $('engineState').textContent = '读取引擎待启动'; controls();
}
function makeWorker() {
  disposeWorker();
  const epoch = workerEpoch;
  if (!workerSource) workerSource = new TextDecoder().decode(Uint8Array.from(atob($('readerSource').textContent.trim()), c => c.charCodeAt(0)));
  const create = (role, handler) => {
    const url = URL.createObjectURL(new Blob(['var knitRole=' + JSON.stringify(role) + ';\n', workerSource], { type: 'text/javascript' }));
    const next = new Worker(url); URL.revokeObjectURL(url);
    next.onerror = () => { if (epoch === workerEpoch) { disposeWorker(); fail(new Error('读取引擎异常；已暂存的进度仍在，点击读取重试。')); } };
    next.onmessage = event => {
      if (epoch !== workerEpoch) return;
      if (event.data.kind === 'error') { disposeWorker(); fail(new Error(event.data.message)); return; }
      handler(event.data);
    };
    return next;
  };
  let collectorReady = false;
  const ready = () => {
    workerReady = collectorReady && pool.every(s => s.ready);
    $('engineState').textContent = workerReady ? pool.length + ' 路识别 · 1 路汇总' : '读取引擎启动中';
  };
  collector = create('collector', data => {
    if (data.kind === 'ready') { clearTimeout(collectorTimer); collectorReady = true; collector.postMessage({ kind: 'inventory' }); ready(); return; }
    if (data.kind === 'inventory') {
      for (const meta of data.skeins) partials.set(meta.key, meta);
      renderPartials(); render(); return;
    }
    if (data.kind === 'notice') { status('这一段需要确认', data.message, true); return; }
    if (data.meta) {
      partials.set(data.key, data.meta); renderPartials();
      if (!manifest && data.meta.manifest) {
        manifest = data.meta.manifest;
        pending++;
        serial = serial.then(async () => { have = new Set(await KnitStore.indices(manifest.id)); render(); })
          .catch(fail).finally(() => { pending--; controls(); });
      }
      if ((!manifest || have.size < manifest.hashes.length) && (!manifest || !data.meta.task || data.meta.task === manifest.id)) {
        partial(data.meta.progress || 0, data.meta.task ? '正在接续第' + (data.meta.index + 1) + '段' : '正在累计当前段 · 序号待确认');
      }
    }
    if (data.kind === 'settled') { lastCollected = performance.now(); inFlight = Math.max(0, inFlight - 1); controls(); }
    if (data.kind === 'complete') {
      const target = collector;
      pending++; controls(); partial(1, '正在校验并保存当前段');
      serial = serial.then(async () => {
        const accepted = await accept(new Blob([data.buffer]));
        if (accepted && collector === target) target.postMessage({ kind: 'saved', key: data.key, task: manifest.id, index: data.meta.index });
      }).catch(error => { disposeWorker(); fail(error); }).finally(() => { pending--; controls(); });
    }
    if (data.kind === 'saved') {
      const meta = partials.get(data.key);
      if (meta) {
        meta.done = true;
        const prior = partials.get(meta.assisted); if (prior) prior.consumed = true;
      }
      renderPartials(); render();
    }
  });
  collectorTimer = setTimeout(() => { if (!collectorReady) { disposeWorker(); fail(new Error('汇总引擎启动超时，请重新读取。')); } }, 20000);
  for (let i = 0; i < workerCount; i++) {
    const slot = { ready: false, busy: false, since: 0 };
    slot.worker = create('extract', data => {
      if (data.kind === 'ready') { slot.ready = true; clearTimeout(slot.timeout); ready(); return; }
      slot.busy = false; busy = pool.every(s => s.busy); lastResult = performance.now();
      results.set(data.sequence, data);
      while (results.has(nextSequence)) {
        const result = results.get(nextSequence); results.delete(nextSequence++);
        if (result.kind === 'symbols') {
          $('frames').textContent = String(++frames); lastDecoded = performance.now();
          collector.postMessage({ kind: 'collect', ...result }, [result.bytes.buffer]);
        } else inFlight = Math.max(0, inFlight - 1);
      }
      if (reading && performance.now() - lastDecoded > 4000) {
        $('scanState').textContent = '正在定位画面 · 尚未读到有效内容';
        $('cameraHint').textContent = '已取 ' + captured + ' 张原图。让四角完整入镜，保持稳定；竖向画面可尝试横持设备。';
      }
      controls();
    });
    slot.timeout = setTimeout(() => { if (!slot.ready) { disposeWorker(); fail(new Error('读取引擎启动超时，请重新读取。')); } }, 20000);
    pool.push(slot);
  }
  worker = pool[0].worker;
}
function captureFrame() {
  const slot = pool.find(s => s.ready && !s.busy);
  if (!reading || !workerReady || !slot || inFlight >= workerCount * 2 || performance.now() - lastCapture < cadence || !$('video').videoWidth || $('video').readyState < 2) return;
  const video = $('video');
  try {
    const width = video.videoWidth, height = video.videoHeight;
    if (width > 8192 || height > 8192 || width * height > 16777216) throw new Error('摄像头原图超过当前读取容量，请使用不超过1600万像素的画面。');
    if (capture.width !== width) capture.width = width;
    if (capture.height !== height) capture.height = height;
    context.drawImage(video, 0, 0);
    const pixels = context.getImageData(0, 0, capture.width, capture.height).data;
    slot.busy = true; slot.since = lastCapture = performance.now(); busy = pool.every(s => s.busy);
    if (!inFlight) lastCollected = performance.now();
    inFlight++; $('captured').textContent = String(++captured);
    slot.worker.postMessage({ pixels, width: capture.width, height: capture.height, sequence: ++sequence }, [pixels.buffer]);
  } catch (error) { busy = false; fail(error); }
}
function scheduleVideo(epoch) {
  if (!reading || epoch !== cameraEpoch) return;
  videoCallback = $('video').requestVideoFrameCallback(() => { captureFrame(); scheduleVideo(epoch); });
}
function pause() {
  cameraEpoch++;
  reading = false; starting = false;
  clearInterval(clock); clock = 0;
  if (videoCallback && $('video').cancelVideoFrameCallback) $('video').cancelVideoFrameCallback(videoCallback);
  videoCallback = 0;
  if (stream) stream.getTracks().forEach(track => track.stop());
  stream = null; $('video').srcObject = null;
  if (lamp) { lamp.release().catch(() => {}); lamp = null; }
  $('empty').hidden = false; $('empty').textContent = '已暂停';
  $('badge').textContent = '已暂停'; controls();
}
async function start() {
  if (reading || starting || merging) return;
  const epoch = ++cameraEpoch;
  starting = true; controls(); status('正在开启摄像头', '请允许访问摄像头，并对准完整彩色画面。');
  try {
    await KnitStore.tasks();
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('摄像头不可用，请通过可信HTTPS网址打开接收页。');
    const local = await navigator.mediaDevices.getUserMedia({ audio: false, video: {
      facingMode: { ideal: 'environment' }, width: { ideal: 3840 }, height: { ideal: 2160 }, frameRate: { ideal: 30 }
    } });
    if (!starting || epoch !== cameraEpoch) { local.getTracks().forEach(track => track.stop()); return; }
    stream = local; $('video').srcObject = stream;
    for (const track of stream.getVideoTracks()) track.addEventListener('ended', () => {
      if (epoch === cameraEpoch && (reading || starting)) fail(new Error('摄像头已断开，请重新点击读取。'));
    });
    await $('video').play();
    if (!starting || epoch !== cameraEpoch) return;
    cameraLayout();
    if (!worker) makeWorker();
    reading = true; starting = false; lastDecoded = performance.now(); lastResult = lastDecoded;
    if (navigator.wakeLock) navigator.wakeLock.request('screen').then(lock => {
      if (reading && epoch === cameraEpoch) lamp = lock;
      else lock.release().catch(() => {});
    }).catch(() => {});
    $('empty').hidden = true; $('badge').textContent = '正在读取';
    if ($('video').requestVideoFrameCallback) scheduleVideo(epoch);
    clock = setInterval(() => {
      if (pool.some(s => s.busy && performance.now() - s.since > 15000)) { disposeWorker(); fail(new Error('读取引擎响应超时，请点击读取重试；已暂存进度仍在。')); return; }
      if (inFlight && pool.every(s => !s.busy) && performance.now() - lastCollected > 30000) { disposeWorker(); fail(new Error('本地汇总或保存超时，请重新读取；已暂存进度仍在。')); return; }
      if (performance.now() - lastResult > 150) captureFrame();
    }, 100);
    $('cameraHint').textContent = '原图读取 · ' + $('video').videoWidth + ' × ' + $('video').videoHeight + ' · 四角完整入镜';
    $('scanState').textContent = '正在定位画面';
    status('正在读取当前段', '每段收齐会自动保存。源端播完一轮后暂停，再复制待收短码。'); controls();
  } catch (error) { if (epoch === cameraEpoch) fail(error); }
}
$('read').addEventListener('click', start);
$('pause').addEventListener('click', () => { pause(); status('已暂停，进度保留', '正在处理的少量画面会继续保存。未完成段也会暂存，下次轮到同一段时自动接续。'); });
$('copy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(B.mending(manifest, have)); status('待收短码已复制', '在源端暂停，粘贴并载入待收段；再点击读取，开始补收轮。'); }
  catch { $('mending').focus(); $('mending').select(); status('请复制选中的短码', '剪贴板不可用，可长按选中内容复制。', true); }
});
$('other').addEventListener('click', async () => {
  if (reading || starting || merging || pending || inFlight) return;
  disposeWorker(); revokeOutput(); manifest = null; have = new Set();
  partial(0, '等待读取任务'); frames = 0; $('frames').textContent = '0'; render();
  try { await tasks(); status('选择任务，或读取新文件', '旧任务仍在本浏览器中，没有删除。'); }
  catch (error) { fail(error); }
});
$('clear').addEventListener('click', async () => {
  if (reading || starting || merging || pending || inFlight || !manifest || !confirm('删除此任务、已完成分段及已确认属于此任务的未完成进度？此操作不可撤销。')) return;
  try {
    await KnitStore.remove(manifest.id); disposeWorker(); revokeOutput(); manifest = null; have.clear();
    partials.clear(); for (const s of await KnitStore.skeins()) partials.set(s.key, s); renderPartials();
    partial(0, '等待读取任务'); frames = 0; $('frames').textContent = '0'; render(); await tasks();
    status('任务已删除', '可以读取新的文件任务。');
  } catch (error) { fail(error); }
});
$('clearUnbound').addEventListener('click', async () => {
  if (reading || starting || merging || pending || inFlight || !confirm('清理所有未确认归属的读取缓存？这些进度将无法恢复，已完成段不受影响。')) return;
  try {
    disposeWorker();
    for (const s of await KnitStore.skeins()) if (!s.task) { await KnitStore.dropSkein(s.key); partials.delete(s.key); }
    renderPartials(); render(); status('未确认缓存已清理', '已完成段及已确认任务的进度没有改变。');
  } catch (error) { fail(error); }
});
window.addEventListener('pagehide', () => { pause(); disposeWorker(); });
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && (reading || starting)) {
    pause(); status('页面已隐藏，读取暂停', '已暂存的完整段与未完成进度保留。返回后点击读取继续。');
  }
});
// The decoder and browser tests share this same validated entry point; no file-import UI is added.
window.KnitReceiver = { accept, start, pause, restore };
$('wideView').addEventListener('change', cameraLayout);
$('video').addEventListener('resize', cameraLayout);
window.addEventListener('resize', cameraLayout);
window.addEventListener('orientationchange', cameraLayout);
tasks().catch(fail);
KnitStore.skeins().then(list => { for (const s of list) partials.set(s.key, s); renderPartials(); }).catch(fail);
cameraLayout(); render();
