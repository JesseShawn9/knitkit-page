'use strict';
const B = KnitBatches, $ = id => document.getElementById(id);
let manifest = null, have = new Set(), reading = false, starting = false, merging = false, pending = 0;
let engineReady = false, engineRequested = false, outputURL = null, lamp = null, readTimer = 0;
let nativeEpoch = 0;
const candidates = [], candidateNames = new Set();
let processing = false, candidateBytes = 0, recoveryNeeded = false, recoveries = [];
let streamKey = '', windowRestart = false, restartTitle = '';
const camera = KnitCameraLease.create(constraints => navigator.mediaDevices.getUserMedia(constraints), () => reading || starting);
window.KnitCamera = {
  async acquire(constraints, session) {
    if (session !== nativeEpoch || !engineRequested) throw new DOMException('Retired decoder', 'AbortError');
    const stream = await camera.acquire(constraints);
    if (session !== nativeEpoch || !engineRequested) throw new DOMException('Retired decoder', 'AbortError');
    return stream;
  }
};
const errors = {
  '任务清单格式不正确。': 'Invalid manifest.',
  '任务清单过大，请增大每段容量。': 'Manifest too large. Increase segment size.',
  '任务清单校验失败。': 'Manifest verification failed.',
  '不是有效的KnitKit2分段。': 'Invalid segment file.',
  '请使用配套的KnitKit2源端生成分段。': 'Use a compatible Encoder.',
  '分段头部已损坏。': 'Invalid segment header.',
  '分段格式版本不支持。': 'Unsupported segment version.',
  '分段序号超出清单范围。': 'Segment number is outside this file.',
  '缓存中没有这一段': 'Missing from local storage',
  '内容摘要不符': 'Hash mismatch',
  '无法读取已保存内容': 'Stored bytes are unreadable',
  '合并后大小不一致。': 'Assembled file size mismatch.',
  '此浏览器不能保存任务，请使用普通浏览模式。': 'Storage unavailable. Use normal browsing mode.',
  '任务存储被其他页面占用，请关闭重复页面后重试。': 'Storage blocked. Close duplicate tabs and retry.',
  '本地任务保存失败，可能空间不足。已保存的进度仍在，请先释放空间。': 'Storage failed. Free some space; saved segments are retained.'
};
function errorText(message) {
  const text = String(message);
  if (errors[text]) return errors[text];
  const length = /^长度不符（(.+)）$/.exec(text);
  if (length) return 'Length mismatch (' + length[1] + ')';
  const part = /^第(.+)段内容校验失败：(.+)。$/.exec(text);
  return part ? 'Segment ' + part[1] + ': ' + errorText(part[2]) : text;
}
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint; $('status').dataset.error = error;
}
function controls() {
  const done = manifest && have.size === manifest.hashes.length;
  $('read').disabled = !(reading || starting) && (merging || pending > 0 || (done && !!outputURL));
  $('read').textContent = reading || starting ? 'Pause' : 'Read';
  $('read').setAttribute('aria-pressed', String(reading || starting));
  $('copy').disabled = $('copyIDs').disabled = !manifest || done || merging;
  $('clear').disabled = !manifest || reading || starting || merging || pending > 0;
  $('taskList').disabled = reading || starting || merging || pending > 0;
}
function render() {
  const total = manifest ? manifest.hashes.length : 0;
  $('gathered').textContent = manifest ? have.size + ' / ' + total : '0';
  $('missing').textContent = manifest ? String(total - have.size) : '—';
  $('filename').hidden = !manifest;
  $('filenameArea').hidden = !manifest;
  $('mending').value = manifest && have.size < total ? B.mending(manifest, have) : '';
  $('missingText').value = manifest ? B.ranges(manifest.hashes.map((_, i) => i).filter(i => !have.has(i))) : '';
  $('totalProgress').value = total ? have.size / total : 0;
  $('totalPercent').textContent = total ? Math.floor(have.size / total * 100) + '%' : '0%';
  $('totalLabel').textContent = 'Total progress';
  if (manifest) {
    $('filename').textContent = manifest.name; $('filename').title = manifest.name;
  }
  controls();
}
function revokeOutput() {
  if (outputURL) URL.revokeObjectURL(outputURL);
  outputURL = null; $('saveArea').hidden = true; $('save').removeAttribute('href');
}
async function tasks() {
  const list = await KnitStore.tasks(); $('tasks').hidden = list.length === 0; $('taskList').replaceChildren();
  const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Select a task';
  placeholder.disabled = placeholder.selected = true; $('taskList').appendChild(placeholder);
  for (const task of list) {
    const option = document.createElement('option'); option.value = task.id; option.textContent = task.manifest.name;
    $('taskList').appendChild(option);
  }
  $('taskList').onchange = () => { const task = list.find(t => t.id === $('taskList').value); if (task) restore(task.manifest).catch(fail); };
  controls();
}
async function restore(value) {
  if (reading || starting || merging || pending) return;
  pending++; controls();
  try {
    await B.validate(value); resetEngine(); revokeOutput(); manifest = value; have = new Set(await KnitStore.indices(value.id));
    $('tasks').hidden = true; render();
    status('Task restored', '');
    if (have.size === manifest.hashes.length) await merge();
  } finally { pending--; controls(); }
}
function command(kind) { $('nativeView').contentWindow.postMessage({ knitShell: true, kind }, location.origin); }
function pause() {
  reading = starting = false; clearTimeout(readTimer); command('pause');
  camera.release();
  recoveryNeeded = windowRestart = false; clearCandidates();
  resetEngine(); document.body.classList.remove('native-active');
  $('codeField').classList.remove('copy-fallback');
  if (lamp) { lamp.release().catch(() => {}); lamp = null; }
  $('empty').hidden = false; $('empty').textContent = 'Paused'; controls();
}
function resetEngine() {
  nativeEpoch++; engineReady = engineRequested = false; $('nativeView').srcdoc = '';
}
function fail(error) { pause(); status('Unable to continue', errorText(error.message || error), true); }
function markReading(kind = 'camera') {
  if (!starting && !reading) return false;
  clearTimeout(readTimer);
  if (reading) return true;
  starting = false; reading = engineReady = true; $('empty').hidden = true;
  status(kind === 'camera' ? 'Looking for pattern' : 'Receiving data', ''); controls();
  if (navigator.wakeLock && !lamp) navigator.wakeLock.request('screen').then(lock => { if (reading) lamp = lock; else lock.release().catch(() => {}); }).catch(() => {});
  return true;
}
async function start(recovering = false) {
  if (reading || starting || merging || pending) return;
  if (!recovering) { recoveries = []; streamKey = ''; }
  openEngine(recovering ? 'Restarting scanner' : 'Opening camera');
}
function openEngine(title) {
  resetEngine();
  $('partialProgress').value = 0; $('partial').textContent = '0%'; $('scanState').textContent = 'Current segment'; $('extraProgress').replaceChildren();
  starting = true; controls();
  status(title, '');
  engineRequested = true;
  window.KnitNativeSources = { runtime: decode('nativeRuntime'), worker: decode('readerSource'), session: nativeEpoch, streamKey };
  document.body.classList.add('native-active');
  $('nativeView').srcdoc = decode('nativeEngine');
  readTimer = setTimeout(() => { if (starting) status('Waiting for camera', ''); }, 30000);
}
function changeWindow(key) {
  if ((!reading && !starting) || key === streamKey) return;
  streamKey = key; replaceEngine('Reading next segment');
}
function replaceEngine(title) {
  clearTimeout(readTimer); command('pause'); resetEngine();
  reading = false; starting = windowRestart = true; recoveryNeeded = false;
  restartTitle = title;
  $('partialProgress').value = 0; $('partial').textContent = '0%'; $('extraProgress').replaceChildren();
  status('Switching segment', ''); controls(); resumeWindow();
}
function resumeWindow() {
  if (!windowRestart || !starting || merging) return;
  windowRestart = false; openEngine(restartTitle);
}
async function merge() {
  if (merging || !manifest || have.size !== manifest.hashes.length) return;
  merging = true; controls(); revokeOutput();
  try {
    const blob = await B.assemble(manifest, i => KnitStore.part(manifest.id, i), (done, total) => status('Verifying ' + done + ' / ' + total, ''));
    pause();
    outputURL = URL.createObjectURL(blob); $('save').href = outputURL; $('save').download = B.safeName(manifest.name);
    $('saveArea').hidden = false;
    $('partialProgress').value = 1; $('partial').textContent = '100%'; $('scanState').textContent = 'All segments received'; $('extraProgress').replaceChildren();
    status('File verified', '');
  } catch (error) {
    if (!Number.isSafeInteger(error.partIndex) || error.partIndex < 0 || error.partIndex >= manifest.hashes.length) throw error;
    const indices = error.partIndices || [error.partIndex];
    for (const index of indices) have.delete(index);
    render();
    for (const index of indices) await KnitStore.dropPart(manifest.id, index);
    const detail = (error.partIssues || []).slice(0, 3).map(issue => 'Segment ' + (issue.index + 1) + ': ' + errorText(issue.reason)).join('; ');
    status('Missing segments: ' + B.ranges(indices), detail, true);
  } finally { merging = false; controls(); }
}
async function accept(blob) {
  let value;
  try { value = await B.unpack(blob); }
  catch (error) {
    const title = manifest && error.taskId === manifest.id && Number.isSafeInteger(error.partIndex) ? 'Segment ' + (error.partIndex + 1) + ' rejected' : 'Segment rejected';
    status(title, errorText(error.message), true); return false;
  }
  if (manifest && manifest.id !== value.manifest.id) {
    status('Different file detected', 'Current progress is retained. Use the matching Encoder file.', true); return false;
  }
  if (!manifest) { manifest = value.manifest; revokeOutput(); have = new Set(await KnitStore.indices(manifest.id)); }
  if (!have.has(value.index)) {
    await KnitStore.put(manifest, value.index, value.data);
    const issue = await B.partIssue(manifest, value.index, await KnitStore.part(manifest.id, value.index));
    if (issue) {
      await KnitStore.dropPart(manifest.id, value.index); render();
      status('Segment ' + (value.index + 1) + ' not saved', errorText(issue), true); return false;
    }
    have.add(value.index);
  }
  $('tasks').hidden = true; render();
  status('Segment ' + (value.index + 1) + ' saved', '');
  if (have.size === manifest.hashes.length) await merge(); return true;
}
function clearCandidates() {
  for (const item of candidates.splice(0)) {
    candidateBytes -= item.blob.size; candidateNames.delete(item.name); item.blob = null; pending--;
  }
}
function recoverScanner() {
  if (!reading && !starting) return;
  if (processing || merging) { recoveryNeeded = true; return; }
  const now = Date.now(); recoveries = recoveries.filter(time => now - time < 60000);
  if (recoveries.length >= 2) { fail(new Error('Scanner stopped responding. Saved segments are retained. Tap Read to retry.')); return; }
  recoveries.push(now);
  replaceEngine('Restarting scanner');
}
async function drainCandidates() {
  if (processing) return;
  processing = true;
  try {
    while (candidates.length) {
      const item = candidates.shift();
      try { await accept(item.blob); }
      catch (error) { fail(error); }
      finally {
        candidateBytes -= item.blob.size; candidateNames.delete(item.name); item.blob = null;
        pending--; controls();
      }
    }
  } finally {
    processing = false;
    if (windowRestart) resumeWindow();
    else if (recoveryNeeded) { recoveryNeeded = false; recoverScanner(); }
  }
}
function enqueueCandidate(data) {
  if ((!reading && !starting) || !(data.blob instanceof Blob)) return;
  const name = typeof data.name === 'string' ? data.name : '';
  if (name && candidateNames.has(name)) return;
  // Bound waiting completed files without touching original camera/decoder queues.
  if (pending >= 4 || candidateBytes + data.blob.size > 48 * 1048576) {
    status('Save queue full', 'This candidate was skipped. Copy missing IDs after the round.', true); return;
  }
  if (name) candidateNames.add(name);
  candidates.push({ name, blob: data.blob }); candidateBytes += data.blob.size;
  pending++; controls(); drainCandidates();
}
window.addEventListener('message', event => {
  if (event.source !== $('nativeView').contentWindow || event.origin !== location.origin || !event.data || !event.data.knitNative || event.data.session !== nativeEpoch) return;
  const data = event.data;
  if ((data.kind === 'stream' || data.kind === 'segment') && typeof data.key === 'string' && /^[0-9a-f]{8}$/.test(data.key)) {
    if (data.kind === 'stream' && !streamKey) streamKey = data.key;
    else if (data.kind === 'segment') changeWindow(data.key);
  }
  if (data.kind === 'camera') {
    if (!markReading()) { command('pause'); return; }
  }
  if (data.kind === 'progress' && Array.isArray(data.report) && (!manifest || have.size < manifest.hashes.length)) {
    markReading('progress');
    const list = data.report.map(Number).filter(Number.isFinite).map(v => Math.max(0, Math.min(1, v)));
    if (list.length && $('stateTitle').textContent === 'Looking for pattern') status('Receiving data', '');
    $('partialProgress').value = list[0] || 0; $('partial').textContent = Math.floor((list[0] || 0) * 100) + '%';
    $('scanState').textContent = list.length > 1 ? 'Active streams: ' + list.length : list.length ? 'Current segment' : 'Waiting for next segment';
    $('extraProgress').replaceChildren();
    for (const value of list.slice(1)) { const progress = document.createElement('progress'); progress.max = 1; progress.value = value; progress.setAttribute('aria-label', 'Additional stream progress'); $('extraProgress').appendChild(progress); }
  }
  if (data.kind === 'file') {
    markReading('file');
    enqueueCandidate(data);
  }
  if (data.kind === 'stalled') recoverScanner();
  if (data.kind === 'error') fail(new Error(data.message));
});
$('read').addEventListener('click', () => {
  if (reading || starting) { pause(); status('Paused', ''); }
  else start();
});
async function copyMissing(kind = 'code') {
  if (!manifest || have.size === manifest.hashes.length) return;
  const code = kind === 'ids' ? B.ranges(manifest.hashes.map((_, i) => i).filter(i => !have.has(i))) : B.mending(manifest, have);
  try {
    if (!legacyCopy(code)) await navigator.clipboard.writeText(code);
    $('codeField').classList.remove('copy-fallback'); status(kind === 'ids' ? 'IDs copied' : 'Code copied', '');
  }
  catch {
    const field = kind === 'ids' ? $('missingText') : $('mending');
    if (kind !== 'ids') $('codeField').classList.add('copy-fallback');
    field.value = code; field.focus(); field.select();
    status('Copy selected text', '');
  }
}
function legacyCopy(text) {
  const active = document.activeElement, field = document.createElement('textarea');
  field.value = text; field.readOnly = true; field.setAttribute('aria-hidden', 'true');
  field.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none';
  document.body.appendChild(field);
  try { field.focus({ preventScroll: true }); field.select(); field.setSelectionRange(0, text.length); return document.execCommand('copy') === true; }
  catch { return false; }
  finally { field.remove(); active?.focus({ preventScroll: true }); }
}
$('copy').addEventListener('click', () => copyMissing());
$('copyIDs').addEventListener('click', () => copyMissing('ids'));
$('clear').addEventListener('click', async () => {
  if (reading || starting || merging || pending || !manifest || !confirm('Clear this task and its saved segments? This cannot be undone.')) return;
  pending++; controls();
  try {
    await KnitStore.remove(manifest.id); revokeOutput(); manifest = null; have.clear(); render(); await tasks();
    $('partialProgress').value = 0; $('partial').textContent = '0%'; $('scanState').textContent = 'Current segment'; $('extraProgress').replaceChildren();
    $('empty').hidden = false; $('empty').textContent = 'Camera idle'; $('codeField').classList.remove('copy-fallback');
    status('Task cleared', '');
  } catch (error) { fail(error); }
  finally { pending--; controls(); }
});
window.addEventListener('pagehide', pause);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && (reading || starting)) { pause(); status('Paused in background', ''); } });
const decode = id => new TextDecoder().decode(Uint8Array.from(atob($(id).textContent.trim()), c => c.charCodeAt(0)));
window.KnitReceiver = { start, pause, accept, restore };
tasks().catch(fail); render();
