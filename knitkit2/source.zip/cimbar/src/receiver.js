'use strict';
const B = KnitBatches, $ = id => document.getElementById(id);
let manifest = null, have = new Set(), reading = false, starting = false, merging = false, pending = 0;
let engineReady = false, engineRequested = false, outputURL = null, serial = Promise.resolve(), lamp = null, readTimer = 0;
let nativeEpoch = 0;
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint; $('status').dataset.error = error;
}
function controls() {
  const done = manifest && have.size === manifest.hashes.length;
  $('read').disabled = reading || starting || merging || pending > 0 || done;
  $('pause').disabled = !reading && !starting;
  $('copy').disabled = !manifest || done || reading || starting || merging || pending > 0;
  $('clear').disabled = $('other').disabled = !manifest || reading || starting || merging || pending > 0;
  for (const button of $('taskList').children) button.disabled = reading || starting || merging || pending > 0;
}
function render() {
  const total = manifest ? manifest.hashes.length : 0;
  $('gathered').textContent = manifest ? have.size + ' / ' + total : '0';
  $('missing').textContent = manifest ? String(total - have.size) : '等待首段';
  $('filename').hidden = !manifest; $('batches').hidden = !manifest;
  $('filenameArea').hidden = !manifest;
  $('mendingArea').hidden = !manifest || have.size === total;
  $('mending').value = manifest && have.size < total ? B.mending(manifest, have) : '';
  $('missingText').textContent = manifest ? '待收：' + (B.ranges(manifest.hashes.map((_, i) => i).filter(i => !have.has(i))) || '已全部收齐') : '';
  $('totalProgress').value = total ? have.size / total : 0;
  $('totalPercent').textContent = total ? Math.floor(have.size / total * 100) + '%' : '0%';
  $('totalLabel').textContent = manifest ? '已保存 ' + have.size + ' / ' + total + ' 段' : '总进度';
  $('batchList').replaceChildren();
  if (manifest) {
    $('filename').textContent = manifest.name; $('filename').title = manifest.name;
    for (let i = 0; i < total; i++) {
      const item = document.createElement('span'); item.className = 'batch-item'; item.dataset.done = String(have.has(i));
      item.textContent = String(i + 1); item.title = '第' + (i + 1) + '段：' + (have.has(i) ? '已保存' : '待收');
      const state = document.createElement('small'); state.textContent = have.has(i) ? '已存' : '待收'; item.appendChild(state);
      item.setAttribute('aria-label', item.title); $('batchList').appendChild(item);
    }
  }
  controls();
}
function revokeOutput() {
  if (outputURL) URL.revokeObjectURL(outputURL);
  outputURL = null; $('saveArea').hidden = true; $('save').removeAttribute('href');
}
async function tasks() {
  const list = await KnitStore.tasks(); $('tasks').hidden = list.length === 0; $('taskList').replaceChildren();
  for (const task of list) {
    const button = document.createElement('button'); button.type = 'button';
    const name = document.createElement('span'); name.textContent = task.manifest.name;
    const date = document.createElement('small'); date.textContent = new Date(task.updated).toLocaleString();
    button.append(name, date); button.title = task.manifest.name;
    button.addEventListener('click', () => restore(task.manifest).catch(fail)); $('taskList').appendChild(button);
  }
  controls();
}
async function restore(value) {
  if (reading || starting || merging || pending) return;
  pending++; controls();
  try {
    await B.validate(value); resetEngine(); revokeOutput(); manifest = value; have = new Set(await KnitStore.indices(value.id));
    $('tasks').hidden = true; render();
    status('已恢复任务', '已保存段不必重扫。点击读取，再让源端播放待收段。');
    if (have.size === manifest.hashes.length) await merge();
  } finally { pending--; controls(); }
}
function command(kind) { $('nativeView').contentWindow.postMessage({ knitShell: true, kind }, location.origin); }
function pause() {
  reading = starting = false; clearTimeout(readTimer); command('pause');
  resetEngine(); document.body.classList.remove('native-active');
  if (lamp) { lamp.release().catch(() => {}); lamp = null; }
  $('badge').textContent = '已暂停'; $('empty').hidden = false; $('empty').textContent = '已暂停'; controls();
}
function resetEngine() {
  nativeEpoch++; engineReady = engineRequested = false; $('nativeView').srcdoc = '';
}
function fail(error) { pause(); if (!engineReady) resetEngine(); status('需要处理后继续', error.message || String(error), true); }
async function start() {
  if (reading || starting || merging || pending) return;
  resetEngine();
  $('partialProgress').value = 0; $('partial').textContent = '0%'; $('scanState').textContent = '等待识别图案'; $('extraProgress').replaceChildren();
  starting = true; controls(); $('badge').textContent = '开启相机';
  status('正在打开原版接收页', '相机就绪后，对准完整图案。');
  engineRequested = true;
  window.KnitNativeSources = { runtime: decode('nativeRuntime'), worker: decode('readerSource'), session: nativeEpoch };
  document.body.classList.add('native-active');
  $('nativeView').srcdoc = decode('nativeEngine');
  readTimer = setTimeout(() => { if (starting) fail(new Error('摄像头尚未就绪，请检查权限后重试。')); }, 30000);
}
async function merge() {
  if (merging || !manifest || have.size !== manifest.hashes.length) return;
  pause(); merging = true; controls(); revokeOutput();
  try {
    const blob = await B.assemble(manifest, i => KnitStore.part(manifest.id, i), (done, total) => status('正在合并原文件', '校验 ' + done + ' / ' + total + ' 段，请勿关闭页面。'));
    outputURL = URL.createObjectURL(blob); $('save').href = outputURL; $('save').download = B.safeName(manifest.name);
    $('saveArea').hidden = false; $('badge').textContent = '全部完成';
    $('partialProgress').value = 1; $('partial').textContent = '100%'; $('scanState').textContent = '全部分段已收齐'; $('extraProgress').replaceChildren();
    status('已收齐，保存原文件', '全部分段的内容、顺序和大小已校验通过。');
  } finally { merging = false; controls(); }
}
async function accept(blob) {
  const value = await B.unpack(blob);
  if (manifest && manifest.id !== value.manifest.id) {
    status('不是当前任务', '当前任务没有改变。请播放当前文件的待收段，或暂停后切换任务。', true); return false;
  }
  if (!manifest) { manifest = value.manifest; revokeOutput(); have = new Set(await KnitStore.indices(manifest.id)); }
  if (!have.has(value.index)) { await KnitStore.put(manifest, value.index, value.data); have.add(value.index); }
  $('tasks').hidden = true; render();
  status('第' + (value.index + 1) + '段已保存', reading ? '等待源端自动切到下一段。本轮结束后可复制待收短码补收。' : '点击读取继续，或复制待收短码到源端。');
  if (have.size === manifest.hashes.length) await merge(); return true;
}
window.addEventListener('message', event => {
  if (event.source !== $('nativeView').contentWindow || event.origin !== location.origin || !event.data || !event.data.knitNative || event.data.session !== nativeEpoch) return;
  const data = event.data;
  if (data.kind === 'camera') {
    clearTimeout(readTimer); if (!starting && !reading) { command('pause'); return; }
    starting = false; reading = engineReady = true; $('empty').hidden = true; $('badge').textContent = '读取中';
    status('正在识别图案', '每段收齐后自动保存；播完一轮，再复制待收短码。'); controls();
    if (navigator.wakeLock) navigator.wakeLock.request('screen').then(lock => { if (reading) lamp = lock; else lock.release().catch(() => {}); }).catch(() => {});
  }
  if (data.kind === 'progress' && Array.isArray(data.report) && (!manifest || have.size < manifest.hashes.length)) {
    const list = data.report.map(Number).filter(Number.isFinite).map(v => Math.max(0, Math.min(1, v)));
    $('partialProgress').value = list[0] || 0; $('partial').textContent = Math.floor((list[0] || 0) * 100) + '%';
    $('scanState').textContent = list.length > 1 ? '识别进度（' + list.length + '组）' : list.length ? '本段识别进度' : '等待下一段';
    $('extraProgress').replaceChildren();
    for (const value of list.slice(1)) { const progress = document.createElement('progress'); progress.max = 1; progress.value = value; progress.setAttribute('aria-label', '其他原版识别进度'); $('extraProgress').appendChild(progress); }
  }
  if (data.kind === 'file') {
    pending++; controls(); serial = serial.then(() => accept(data.blob)).catch(fail).finally(() => { pending--; controls(); });
  }
  if (data.kind === 'error') fail(new Error(data.message));
});
$('read').addEventListener('click', start);
$('pause').addEventListener('click', () => { pause(); status('已暂停', '已保存的完整段保留。未完成段会在补收轮重新读取。'); });
$('copy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(B.mending(manifest, have)); status('待收短码已复制', '粘贴到源端并载入；先点击读取，再让源端开始补收轮。'); }
  catch { $('mending').focus(); $('mending').select(); status('请复制选中的短码', '也可长按选中复制。'); }
});
$('other').addEventListener('click', async () => {
  if (reading || starting || merging || pending) return;
  resetEngine(); revokeOutput(); manifest = null; have.clear(); render(); await tasks(); status('选择任务，或读取新文件', '已保存任务没有删除。');
});
$('clear').addEventListener('click', async () => {
  if (reading || starting || merging || pending || !manifest || !confirm('删除当前任务及已保存段？此操作不可撤销。')) return;
  try { await KnitStore.remove(manifest.id); revokeOutput(); manifest = null; have.clear(); render(); await tasks(); status('任务已删除', '可以读取新的文件。'); } catch (error) { fail(error); }
});
window.addEventListener('pagehide', pause);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && (reading || starting)) { pause(); status('读取已暂停', '返回页面后点击读取。已完成段仍保留。'); } });
const decode = id => new TextDecoder().decode(Uint8Array.from(atob($(id).textContent.trim()), c => c.charCodeAt(0)));
window.KnitReceiver = { start, pause, accept, restore };
tasks().catch(fail); render();
