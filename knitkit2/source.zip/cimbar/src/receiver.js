'use strict';
const B = KnitBatches;
const $ = id => document.getElementById(id);
let manifest = null, have = new Set(), reading = false, starting = false, merging = false;
let stream = null, worker = null, workerURL = null, workerReady = false, busy = false, clock = 0, cameraTime = -1;
let frames = 0, outputURL = null, serial = Promise.resolve(), pending = 0;
let cameraEpoch = 0, lamp = null;
const capture = document.createElement('canvas');
const context = capture.getContext('2d', { willReadFrequently: true });
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint; $('status').dataset.error = error;
}
function controls() {
  $('read').disabled = reading || starting || merging || (manifest && have.size === manifest.hashes.length);
  $('pause').disabled = !reading && !starting;
  $('copy').disabled = !manifest || have.size === manifest.hashes.length;
  $('clear').disabled = !manifest || reading || starting || merging || pending > 0;
  $('other').disabled = !manifest || reading || starting || merging || pending > 0;
  for (const button of $('taskList').children) button.disabled = reading || starting || merging || pending > 0;
}
function render() {
  $('gathered').textContent = manifest ? have.size + ' / ' + manifest.hashes.length : '0';
  $('missing').textContent = manifest ? String(manifest.hashes.length - have.size) : '尚未确定';
  $('batches').hidden = !manifest; $('filename').hidden = !manifest;
  if (manifest) {
    $('filename').textContent = manifest.name; $('filename').title = manifest.name;
    const list = $('batchList'); list.replaceChildren();
    for (let i = 0; i < manifest.hashes.length; i++) {
      const button = document.createElement('button'); button.type = 'button';
      button.dataset.done = String(have.has(i));
      button.setAttribute('aria-label', '第' + (i + 1) + '段，' + (have.has(i) ? '已完成' : '待收'));
      button.append(String(i + 1).padStart(2, '0'));
      const label = document.createElement('small'); label.textContent = have.has(i) ? '已完成' : '待收'; button.append(label);
      button.title = '在源端点击第' + (i + 1) + '段播放';
      button.addEventListener('click', () => status('第' + (i + 1) + '段' + (have.has(i) ? '已完成' : '待收'),
        have.has(i) ? '这一段已经保存在本浏览器，无需重扫。' : '请在源端选择同一序号，然后保持摄像头对准。'));
      list.append(button);
    }
  }
  controls();
}
function revokeOutput() {
  if (outputURL) URL.revokeObjectURL(outputURL);
  outputURL = null; $('saveArea').hidden = true; $('save').removeAttribute('href');
}
async function tasks() {
  const list = await KnitStore.tasks();
  $('tasks').hidden = list.length === 0;
  $('taskList').replaceChildren();
  for (const task of list) {
    const button = document.createElement('button'); button.type = 'button';
    const name = document.createElement('span'); name.textContent = task.manifest.name;
    const date = document.createElement('small'); date.textContent = new Date(task.updated).toLocaleString();
    button.append(name, date); button.title = task.manifest.name;
    button.addEventListener('click', () => restore(task.manifest).catch(fail));
    $('taskList').append(button);
  }
  controls();
}
async function restore(value) {
  if (reading || starting || merging || pending) return;
  await B.validate(value);
  disposeWorker(); revokeOutput(); manifest = value;
  have = new Set(await KnitStore.indices(value.id));
  $('tasks').hidden = true; render();
  status('已恢复任务', '已完成段仍在。点击读取，再让源端播放待收序号。');
  if (have.size === manifest.hashes.length) await merge();
}
function fail(error) {
  pause();
  status('需要处理后再继续', error.message || String(error), true);
  controls();
}
async function merge() {
  if (merging || !manifest || have.size !== manifest.hashes.length) return;
  pause(); merging = true; controls(); revokeOutput();
  try {
    const blob = await B.assemble(manifest, i => KnitStore.part(manifest.id, i), (done, total) => {
      status('正在自动合并', '逐段复核 ' + done + ' / ' + total + '，请不要关闭页面。');
    });
    outputURL = URL.createObjectURL(blob);
    $('save').href = outputURL; $('save').download = B.safeName(manifest.name); $('saveArea').hidden = false;
    $('badge').textContent = '全部完成'; $('partial').textContent = '100%';
    status('已合并，可以保存原文件', '全部分段的SHA-256与原清单一致，顺序和总大小校验通过。');
  } finally { merging = false; controls(); }
}
async function accept(blob) {
  const value = await B.unpack(blob);
  if (manifest && manifest.id !== value.manifest.id) {
    status('读到了其他任务', '当前任务未改变。请让源端播放当前文件，或暂停后选择其他历史任务。', true);
    return false;
  }
  if (!manifest) {
    manifest = value.manifest; revokeOutput();
    have = new Set(await KnitStore.indices(manifest.id));
  }
  if (!have.has(value.index)) {
    await KnitStore.put(manifest, value.index, value.data);
    have.add(value.index);
  }
  $('tasks').hidden = true; render();
  status('第' + (value.index + 1) + '段已保存',
    '请在源端切换到待收段。已完成的分段无需再扫。');
  if (have.size === manifest.hashes.length) await merge();
  return true;
}
function disposeWorker() {
  if (worker) worker.terminate();
  if (workerURL) URL.revokeObjectURL(workerURL);
  workerURL = null;
  worker = null; workerReady = false; busy = false;
}
function makeWorker() {
  disposeWorker();
  const source = new TextDecoder().decode(Uint8Array.from(atob($('readerSource').textContent.trim()), c => c.charCodeAt(0)));
  const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
  const next = new Worker(url); workerURL = url; worker = next;
  const timeout = setTimeout(() => { if (worker === next && !workerReady) fail(new Error('读取引擎启动超时，请重新读取。')); }, 20000);
  next.onerror = () => { if (worker === next) { clearTimeout(timeout); disposeWorker(); fail(new Error('读取引擎异常，请重新读取这一段。')); } };
  next.onmessage = event => {
    if (worker !== next) return;
    const data = event.data;
    if (data.kind === 'ready') { clearTimeout(timeout); workerReady = true; URL.revokeObjectURL(url); workerURL = null; return; }
    busy = false;
    if (data.kind === 'switch') {
      $('partial').textContent = '0%'; makeWorker();
      status('正在切换分段', '已完成段不会丢失。正在读取源端当前选择的一段。'); return;
    }
    if (data.kind === 'error') { disposeWorker(); fail(new Error(data.message)); return; }
    if (data.decoded || data.kind === 'complete') $('frames').textContent = String(++frames);
    if (Array.isArray(data.progress) && data.progress.length) {
      const value = Math.max(0, Math.min(1, Number(data.progress[0]) || 0));
      $('partial').textContent = Math.floor(value * 100) + '%';
    }
    if (data.kind === 'complete') {
      $('partial').textContent = '100%'; pending++; controls();
      serial = serial.then(() => accept(new Blob([data.buffer]))).catch(error => { disposeWorker(); fail(error); }).finally(() => { pending--; controls(); });
    }
  };
}
function captureFrame() {
  if (!reading || !workerReady || busy || !$('video').videoWidth || $('video').currentTime === cameraTime) return;
  const video = $('video');
  cameraTime = video.currentTime;
  const scale = Math.min(1, 1920 / Math.max(video.videoWidth, video.videoHeight));
  capture.width = Math.max(1, Math.round(video.videoWidth * scale));
  capture.height = Math.max(1, Math.round(video.videoHeight * scale));
  try {
    context.drawImage(video, 0, 0, capture.width, capture.height);
    const pixels = context.getImageData(0, 0, capture.width, capture.height).data;
    busy = true;
    worker.postMessage({ pixels, width: capture.width, height: capture.height }, [pixels.buffer]);
  } catch (error) { busy = false; fail(error); }
}
function pause() {
  cameraEpoch++;
  reading = false; starting = false;
  clearInterval(clock); clock = 0;
  if (stream) stream.getTracks().forEach(track => track.stop());
  stream = null; $('video').srcObject = null;
  if (lamp) { lamp.release().catch(() => {}); lamp = null; }
  $('empty').hidden = false; $('empty').textContent = '已暂停';
  $('badge').textContent = '已暂停'; controls();
}
async function start() {
  if (reading || starting || merging) return;
  const epoch = ++cameraEpoch;
  starting = true; controls(); status('正在开启摄像头', '请允许访问摄像头，并对准完整彩色画面。');
  try {
    await KnitStore.tasks();
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('摄像头不可用，请通过可信HTTPS网址打开接收页。');
    const local = await navigator.mediaDevices.getUserMedia({ audio: false, video: {
      facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 30 }
    } });
    if (!starting || epoch !== cameraEpoch) { local.getTracks().forEach(track => track.stop()); return; }
    stream = local; $('video').srcObject = stream;
    for (const track of stream.getVideoTracks()) track.addEventListener('ended', () => {
      if (epoch === cameraEpoch && (reading || starting)) fail(new Error('摄像头已断开，请重新点击读取。'));
    });
    await $('video').play();
    if (!starting || epoch !== cameraEpoch) return;
    if (!worker) makeWorker();
    reading = true; starting = false; cameraTime = -1;
    if (navigator.wakeLock) navigator.wakeLock.request('screen').then(lock => {
      if (reading && epoch === cameraEpoch) lamp = lock;
      else lock.release().catch(() => {});
    }).catch(() => {});
    $('empty').hidden = true; $('badge').textContent = '正在读取';
    clock = setInterval(captureFrame, 50);
    status('正在读取当前段', '收齐后会自动保存；随后在源端点击下一待收序号。'); controls();
  } catch (error) { if (epoch === cameraEpoch) fail(error); }
}
$('read').addEventListener('click', start);
$('pause').addEventListener('click', () => { pause(); status('已暂停，进度保留', '可稍后继续。刷新或关闭页面会保留已完成段，未完成的当前段需重扫。'); });
$('copy').addEventListener('click', async () => {
  const missing = manifest.hashes.map((_, i) => i).filter(i => !have.has(i)).map(i => i + 1);
  try { await navigator.clipboard.writeText(missing.join(', ')); status('待收序号已复制', '在源端依次点击这些序号即可。'); }
  catch { status('无法访问剪贴板', '请按下方标为待收的序号，在源端依次选择。', true); }
});
$('other').addEventListener('click', async () => {
  if (reading || starting || merging || pending) return;
  disposeWorker(); revokeOutput(); manifest = null; have = new Set();
  $('partial').textContent = '0%'; frames = 0; $('frames').textContent = '0'; render();
  try { await tasks(); status('选择任务，或读取新文件', '旧任务仍在本浏览器中，没有删除。'); }
  catch (error) { fail(error); }
});
$('clear').addEventListener('click', async () => {
  if (reading || starting || merging || pending || !manifest || !confirm('删除此任务及其已完成分段？此操作不可撤销。')) return;
  try {
    await KnitStore.remove(manifest.id); disposeWorker(); revokeOutput(); manifest = null; have.clear();
    $('partial').textContent = '0%'; frames = 0; $('frames').textContent = '0'; render(); await tasks();
    status('任务已删除', '可以读取新的文件任务。');
  } catch (error) { fail(error); }
});
window.addEventListener('pagehide', () => { pause(); disposeWorker(); });
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && (reading || starting)) {
    pause(); status('页面已隐藏，读取暂停', '已完成段保留。返回后点击读取继续。');
  }
});
// The decoder and browser tests share this same validated entry point; no file-import UI is added.
window.KnitReceiver = { accept, start, pause, restore };
tasks().catch(fail); render();
