(function (root) {
  'use strict';
  const magic = new TextEncoder().encode('KK2PACK\n');
  const maxPart = 20 * 1024 * 1024;
  const maxHeader = 2 * 1024 * 1024;
  const hex = /^[0-9a-f]{64}$/;
  const text = new TextEncoder();
  const decode = new TextDecoder('utf-8', { fatal: true });

  async function hash(bytes) {
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
  }
  function canonical(m) {
    return JSON.stringify([1, m.name, m.size, m.type, m.partSize, m.hashes]);
  }
  function partLength(m, index) {
    return Math.max(0, Math.min(m.partSize, m.size - index * m.partSize));
  }
  async function validate(m) {
    if (!m || typeof m.name !== 'string' || !m.name.length || m.name.length > 4096 ||
        typeof m.type !== 'string' || m.type.length > 256 ||
        !Number.isSafeInteger(m.size) || m.size < 0 ||
        !Number.isSafeInteger(m.partSize) || m.partSize < 1 || m.partSize > maxPart ||
        !Array.isArray(m.hashes) || m.hashes.length !== Math.max(1, Math.ceil(m.size / m.partSize)) ||
        !m.hashes.every(h => typeof h === 'string' && hex.test(h)) || !hex.test(m.id)) {
      throw new Error('任务清单格式不正确。');
    }
    if (text.encode(canonical(m)).length > maxHeader - 16384) throw new Error('任务清单过大，请增大每段容量。');
    if (await hash(text.encode(canonical(m))) !== m.id) throw new Error('任务清单校验失败。');
    return m;
  }
  async function prepare(file, partSize, progress = () => {}) {
    if (!Number.isSafeInteger(partSize) || partSize < 1 || partSize > maxPart) throw new Error('每段容量须在20MiB以内。');
    const m = { name: file.name || 'pattern.bin', size: file.size, type: file.type || '', partSize, hashes: [] };
    const count = Math.max(1, Math.ceil(file.size / partSize));
    for (let i = 0; i < count; i++) {
      m.hashes.push(await hash(await file.slice(i * partSize, (i + 1) * partSize).arrayBuffer()));
      progress(i + 1, count);
    }
    m.id = await hash(text.encode(canonical(m)));
    return validate(m);
  }
  async function packet(file, m, index) {
    if (!Number.isSafeInteger(index) || index < 0 || index >= m.hashes.length) throw new Error('分段序号不正确。');
    const data = await file.slice(index * m.partSize, (index + 1) * m.partSize).arrayBuffer();
    if (await hash(data) !== m.hashes[index]) throw new Error('文件内容已变化，请重新选择文件。');
    const header = text.encode(JSON.stringify({ v: 1, manifest: m, index }));
    if (header.length > maxHeader) throw new Error('任务清单过大。');
    const prefix = new Uint8Array(12);
    prefix.set(magic);
    new DataView(prefix.buffer).setUint32(8, header.length);
    return new Blob([prefix, header, data], { type: 'application/octet-stream' });
  }
  async function unpack(blob) {
    if (blob.size < 12 || blob.size > maxPart + maxHeader + 12) throw new Error('不是有效的KnitKit2分段。');
    const prefix = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
    if (!magic.every((b, i) => b === prefix[i])) throw new Error('请使用配套的KnitKit2源端生成分段。');
    const length = new DataView(prefix.buffer).getUint32(8);
    if (length < 1 || length > maxHeader || length + 12 > blob.size) throw new Error('分段头部已损坏。');
    const h = JSON.parse(decode.decode(await blob.slice(12, 12 + length).arrayBuffer()));
    if (h.v !== 1) throw new Error('分段格式版本不支持。');
    const m = await validate(h.manifest);
    if (!Number.isSafeInteger(h.index) || h.index < 0 || h.index >= m.hashes.length) throw new Error('分段序号超出清单范围。');
    const data = blob.slice(12 + length);
    if (data.size !== partLength(m, h.index) || await hash(await data.arrayBuffer()) !== m.hashes[h.index]) {
      throw new Error('分段内容校验失败，请重扫这一段。');
    }
    return { manifest: m, index: h.index, data };
  }
  function safeName(name) {
    return name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim() || 'pattern.bin';
  }
  async function assemble(m, getPart, progress = () => {}) {
    await validate(m);
    const blobs = [];
    for (let i = 0; i < m.hashes.length; i++) {
      const blob = await getPart(i);
      if (!blob || blob.size !== partLength(m, i) || await hash(await blob.arrayBuffer()) !== m.hashes[i]) {
        throw new Error('第' + (i + 1) + '段缺失或损坏，请重新读取。');
      }
      blobs.push(blob);
      progress(i + 1, m.hashes.length);
    }
    const result = new Blob(blobs, { type: m.type || 'application/octet-stream' });
    if (result.size !== m.size) throw new Error('合并后大小不一致。');
    return result;
  }
  function ranges(indices) {
    const values = [...new Set(indices)].sort((a, b) => a - b);
    const groups = [];
    for (let i = 0; i < values.length; i++) {
      const start = values[i];
      while (i + 1 < values.length && values[i + 1] === values[i] + 1) i++;
      groups.push(start === values[i] ? String(start + 1) : (start + 1) + '-' + (values[i] + 1));
    }
    return groups.join(',');
  }
  function mending(m, have) {
    return 'KK2M:' + m.id + ':' + ranges(m.hashes.map((_, i) => i).filter(i => !have.has(i)));
  }
  function replay(m, code) {
    let body = code.trim();
    if (body.startsWith('KK2M:')) {
      const match = /^KK2M:([0-9a-f]{64}):(.+)$/.exec(body);
      if (!match || match[1] !== m.id) throw new Error('短码不属于当前文件任务，请复制当前任务的待收短码。');
      body = match[2];
    }
    if (!body || body.length > maxHeader) throw new Error('请输入有效的待收序号或短码。');
    body = body.replace(/\s*-\s*/g, '-').replace(/\s*[,，、;；]\s*/g, ',').replace(/\s+/g, ',');
    const result = new Set();
    for (const group of body.split(',')) {
      const range = /^(\d+)(?:-(\d+))?$/.exec(group);
      if (!range) throw new Error('待收内容格式不正确，请输入序号、范围或完整短码。');
      const from = Number(range[1]), to = Number(range[2] || range[1]);
      if (!Number.isSafeInteger(from) || !Number.isSafeInteger(to) || from < 1 || to < from || to > m.hashes.length) throw new Error('待收序号超出当前任务范围。');
      for (let i = from; i <= to; i++) result.add(i - 1);
    }
    return [...result].sort((a, b) => a - b);
  }
  root.KnitBatches = { hash, prepare, packet, unpack, assemble, validate, safeName, maxPart, ranges, mending, replay };
})(globalThis);
