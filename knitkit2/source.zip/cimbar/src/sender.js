'use strict';
var Module;
const B = KnitBatches;
const $ = id => document.getElementById(id);
// Keep GLFW's global keyboard capture out of the shell's native form controls.
for (const type of ['keydown', 'keypress', 'keyup']) window.addEventListener(type, event => {
  if (event.target.closest?.('input, textarea, select, button, [contenteditable="true"]')) event.stopImmediatePropagation();
}, true);
let file, manifest, selected = 0, preparing = false, playing = false, ready = false, initialized = false;
let generation = 0, count = 0, lastFrame = 0, lamp, locked = false;
let order = [], position = 0, elapsed = 0, lastTick = 0, roundDone = false, round = 1, mending = false;
let extension = 0;
const sourceErrors = {
  '任务清单格式不正确。': 'Invalid segment manifest.',
  '任务清单过大，请增大每段容量。': 'Manifest too large. Increase segment size.',
  '任务清单校验失败。': 'Manifest verification failed.',
  '每段容量须在20MiB以内。': 'Segment size must not exceed 20M.',
  '分段序号不正确。': 'Invalid segment number.',
  '文件内容已变化，请重新选择文件。': 'File changed. Open it again.',
  '任务清单过大。': 'Manifest too large.',
  '短码不属于当前文件任务，请复制当前任务的待收短码。': 'This repair code belongs to another file.',
  '请输入有效的待收序号或短码。': 'Enter segment numbers or a repair code.',
  '待收内容格式不正确，请输入序号、范围或完整短码。': 'Use segment numbers, ranges or a complete repair code.',
  '待收序号超出当前任务范围。': 'Segment number is outside this file.'
};
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = sourceErrors[hint] || hint;
  $('status').dataset.error = error;
}
function formatSize(size) { return (size / 1048576).toFixed(1) + 'M'; }
function controls() {
  $('play').disabled = !ready || preparing || !initialized;
  $('next').disabled = $('extend').disabled = !ready || preparing || !initialized || roundDone;
  $('extend').textContent = '+' + Number($('partSize').value) * 20 + 's';
  $('mending').disabled = !ready || preparing || playing || !locked;
  $('partSize').disabled = locked || preparing;
  $('mode').disabled = locked || preparing;
  $('pattern').disabled = preparing;
  $('choose').disabled = preparing;
  $('reset').disabled = $('clear').disabled = !file || preparing;
  $('play').textContent = playing ? 'Pause' : locked && $('mending').value.trim() ? 'Resume' : roundDone ? 'Replay' : locked ? 'Resume' : 'Start';
}
function progress() {
  const seconds = Number($('dwell').value) + extension;
  $('lap').textContent = (mending ? 'Repair ' + round : 'Round 1') + ' · ' + (position + 1) + ' / ' + order.length;
  $('remaining').textContent = roundDone ? 'Round complete' : Math.max(0, Math.ceil(seconds - elapsed)) + 's left';
  $('lapProgress').value = roundDone ? 1 : (position + Math.min(1, elapsed / seconds)) / Math.max(1, order.length);
}
async function wake() {
  if (lamp || document.visibilityState !== 'visible') return;
  try { lamp = await navigator.wakeLock.request('screen'); lamp.addEventListener('release', () => { lamp = null; }); } catch {}
}
async function encode(blob, index) {
  const name = new TextEncoder().encode('knitkit2-' + manifest.id.slice(0, 12) + '-' + (index + 1) + '.bin');
  const namePtr = Module._malloc(name.length);
  try {
    Module.HEAPU8.set(name, namePtr);
    const result = Module._cimbare_init_encode(namePtr, name.length, -1);
    if (result < 0) throw new Error('Frame initialization failed: ' + result);
  } finally { Module._free(namePtr); }
  const size = Module._cimbare_encode_bufsize() * 16;
  const pointer = Module._malloc(size);
  let result = 1;
  try {
    for (let offset = 0; offset < blob.size; offset += size) {
      const data = new Uint8Array(await blob.slice(offset, offset + size).arrayBuffer());
      Module.HEAPU8.set(data, pointer);
      result = Module._cimbare_encode(pointer, data.length);
      if (result < 0) throw new Error('Segment preparation failed: ' + result);
    }
    if (result !== 0) result = Module._cimbare_encode(pointer, 0);
    if (result !== 0) throw new Error('Segment preparation incomplete.');
  } finally { Module._free(pointer); }
  Module._cimbare_next_frame(false); Module._cimbare_render();
}
async function selectBatch(index, automatic = false) {
  if (preparing || !manifest || !initialized) return;
  const resume = automatic && playing;
  playing = false; ready = false; preparing = true; selected = index; count = 0;
  if (!automatic) {
    position = order.indexOf(index);
    if (position < 0) { order = [index]; position = 0; mending = true; }
  }
  elapsed = 0; extension = 0; lastTick = 0; roundDone = false;
  $('frames').textContent = '0'; $('current').textContent = (index + 1) + ' / ' + manifest.hashes.length;
  status('Preparing segment ' + (index + 1), '');
  $('emptyTitle').textContent = 'Preparing';
  $('canvas').hidden = true; $('empty').hidden = false;
  controls();
  try {
    await encode(await B.packet(file, manifest, index), index);
    ready = true; playing = resume;
    $('canvas').hidden = false; $('empty').hidden = true;
    status(playing ? 'Playing segment ' + (index + 1) : 'Segment ' + (index + 1) + ' ready', '');
  } catch (error) { status('Segment preparation failed', error.message, true); }
  finally { preparing = false; controls(); progress(); }
}
async function prepare() {
  if (!file || preparing || !initialized) return;
  const token = ++generation;
  playing = false; ready = false; preparing = true; manifest = null;
  order = []; position = 0; round = 1; roundDone = false; mending = false;
  $('mending').value = '';
  $('emptyTitle').textContent = 'Preparing';
  $('canvas').hidden = true; $('empty').hidden = false;
  $('dashboard').hidden = false; $('filename').textContent = file.name; $('filename').title = file.name;
  $('fileSize').textContent = formatSize(file.size); $('total').textContent = '...'; $('current').textContent = 'Pending';
  controls();
  try {
    manifest = await B.prepare(file, Number($('partSize').value) * 1048576, (done, total) => {
      status('Preparing segments ' + done + ' / ' + total, '');
    });
    if (token !== generation) return;
    order = manifest.hashes.map((_, i) => i);
    $('total').textContent = String(manifest.hashes.length);
    preparing = false;
    await selectBatch(0);
  } catch (error) { manifest = null; status('File preparation failed', error.message, true); }
  finally { preparing = false; controls(); }
}
function nextBatch() {
  if (!ready || preparing || roundDone) return;
  if (position + 1 < order.length) { position++; return selectBatch(order[position], true); }
  playing = false; roundDone = true; lastTick = 0; progress(); controls();
  status('Round complete', '');
}
function render(now) {
  requestAnimationFrame(render);
  if (!playing || !ready || preparing) { lastTick = 0; return; }
  if (lastTick) elapsed += (now - lastTick) / 1000;
  lastTick = now; progress();
  if (elapsed >= Number($('dwell').value) + extension) {
    nextBatch();
    return;
  }
  if (now - lastFrame < Math.floor(1000 / Number($('fps').value))) return;
  lastFrame = now;
  try {
    Module._cimbare_next_frame(false); Module._cimbare_render();
    $('frames').textContent = String(++count);
  } catch (error) { playing = false; controls(); status('Playback stopped', error.message, true); }
}
function loadFile(next) {
  if (!next || preparing) return;
  file = next; locked = false; wake(); prepare();
}
$('pattern').addEventListener('change', () => {
  const next = $('pattern').files[0]; $('pattern').value = ''; loadFile(next);
});
$('choose').addEventListener('click', () => $('pattern').click());
const fileDrag = event => Array.from(event.dataTransfer?.types || []).includes('Files');
let dragDepth = 0;
window.addEventListener('dragover', event => { if (fileDrag(event)) event.preventDefault(); });
window.addEventListener('drop', event => {
  if (!fileDrag(event)) return;
  event.preventDefault(); dragDepth = 0; $('dropZone').classList.remove('drag-over');
});
$('dropZone').addEventListener('dragenter', event => {
  if (!fileDrag(event)) return;
  event.preventDefault(); dragDepth++; if (!preparing) $('dropZone').classList.add('drag-over');
});
$('dropZone').addEventListener('dragleave', () => {
  if (--dragDepth <= 0) { dragDepth = 0; $('dropZone').classList.remove('drag-over'); }
});
$('dropZone').addEventListener('dragover', event => {
  if (!fileDrag(event)) return;
  event.preventDefault(); event.dataTransfer.dropEffect = preparing ? 'none' : 'copy';
});
$('dropZone').addEventListener('drop', event => {
  if (!fileDrag(event)) return;
  event.preventDefault(); loadFile(event.dataTransfer.files[0]);
});
$('reset').addEventListener('click', () => {
  if (!file || preparing) return;
  locked = false; prepare();
});
$('clear').addEventListener('click', () => {
  if (preparing) return;
  generation++;
  playing = ready = locked = roundDone = mending = false;
  file = manifest = null; order = []; selected = position = count = elapsed = extension = lastTick = lastFrame = 0; round = 1;
  $('pattern').value = $('mending').value = '';
  $('dashboard').hidden = $('canvas').hidden = true; $('empty').hidden = false;
  $('emptyTitle').textContent = 'Drop a file'; $('filename').textContent = $('filename').title = '';
  $('fileSize').textContent = $('total').textContent = $('current').textContent = ''; $('frames').textContent = '0';
  $('lap').textContent = 'Round 1 · Ready'; $('remaining').textContent = $('dwell').value + 's / segment'; $('lapProgress').value = 0;
  status('Waiting for a file', ''); controls();
  if (lamp) lamp.release().catch(() => {});
});
$('partSize').addEventListener('change', prepare);
$('mode').addEventListener('change', () => {
  if (initialized) Module._cimbare_configure(Number($('mode').value), -1);
  prepare();
});
$('play').addEventListener('click', async () => {
  if (!ready || preparing || !initialized) return;
  if (playing) {
    playing = false; lastTick = 0; controls();
    status('Segment ' + (selected + 1) + ' paused', ''); return;
  }
  if ($('mending').value.trim()) { await replayInput(); return; }
  if (roundDone) { position = 0; await selectBatch(order[0]); if (!ready) return; }
  playing = locked = true; lastTick = 0; wake(); controls();
  status('Playing segment ' + (selected + 1), '');
});
$('next').addEventListener('click', nextBatch);
$('extend').addEventListener('click', () => {
  if (!ready || preparing || roundDone) return;
  extension += Number($('partSize').value) * 20; progress();
});
async function replayInput() {
  const code = $('mending').value.trim();
  if (!code || !manifest || playing || preparing || document.visibilityState === 'hidden') return;
  try {
    const next = B.replay(manifest, code);
    playing = false;
    order = next; position = 0; mending = true; round++; await selectBatch(order[0]);
    if (ready) {
      if ($('mending').value.trim() === code) $('mending').value = '';
      playing = locked = true; wake(); controls();
      status('Repairing segment ' + (selected + 1), '');
    }
  } catch (error) { status('Invalid repair code', error.message, true); }
}
$('mending').addEventListener('input', controls);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && playing) {
    playing = false; controls(); status('Paused in background', '');
  } else wake();
});
window.addEventListener('beforeunload', event => { if (playing) { event.preventDefault(); event.returnValue = ''; } });
window.knitRuntimeReady = () => {
  try {
    Module.canvas = $('canvas');
    if (Module._cimbare_init_window(0, 0) < 0) throw new Error('Enable hardware acceleration for WebGL.');
    Module._cimbare_configure(Number($('mode').value), -1); initialized = true; controls();
    if (file) prepare();
  } catch (error) { status('Encoder unavailable', error.message, true); }
};
window.knitRuntimeFailed = error => {
  initialized = false; playing = false; ready = false; controls();
  status('Encoder unavailable', 'Use Chrome with WebAssembly and WebGL. ' + String(error), true);
};
requestAnimationFrame(render);
