'use strict';
var Module;
const B = KnitBatches;
const $ = id => document.getElementById(id);
let file, manifest, selected = 0, preparing = false, playing = false, ready = false, initialized = false;
let generation = 0, count = 0, lastFrame = 0, lamp, locked = false;
let order = [], position = 0, elapsed = 0, lastTick = 0, roundDone = false, round = 1, mending = false;
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint;
  $('status').dataset.error = error;
}
function formatSize(size) { return (size / 1048576).toFixed(1) + ' MiB'; }
function controls() {
  $('play').disabled = !ready || preparing || !initialized;
  $('partSize').disabled = locked || preparing;
  $('mode').disabled = locked || preparing;
  $('pattern').disabled = preparing;
  $('apply').disabled = !manifest || preparing || playing || !$('mending').value.trim();
  $('play').textContent = playing ? '暂停' : roundDone ? '重播本轮' : mending && elapsed === 0 ? '开始补收轮' : locked ? '继续本轮' : '开始首轮';
}
function progress() {
  const seconds = Number($('dwell').value);
  $('lap').textContent = (mending ? '补收轮 ' + round : '首轮') + ' · ' + (position + 1) + ' / ' + order.length;
  $('remaining').textContent = roundDone ? '本轮已播完' : Math.max(0, Math.ceil(seconds - elapsed)) + ' 秒后切段';
  $('lapProgress').value = roundDone ? 1 : (position + Math.min(1, elapsed / seconds)) / Math.max(1, order.length);
}
async function wake() {
  if (lamp || document.visibilityState !== 'visible') return;
  try { lamp = await navigator.wakeLock.request('screen'); lamp.addEventListener('release', () => { lamp = null; }); } catch {}
}
async function encode(blob, index) {
  const name = new TextEncoder().encode('knitkit2-' + manifest.id.slice(0, 12) + '-' + (index + 1) + '.bin');
  const namePtr = Module._malloc(name.length);
  try {
    Module.HEAPU8.set(name, namePtr);
    const result = Module._cimbare_init_encode(namePtr, name.length, -1);
    if (result < 0) throw new Error('画面初始化失败：' + result);
  } finally { Module._free(namePtr); }
  const size = Module._cimbare_encode_bufsize() * 16;
  const pointer = Module._malloc(size);
  let result = 1;
  try {
    for (let offset = 0; offset < blob.size; offset += size) {
      const data = new Uint8Array(await blob.slice(offset, offset + size).arrayBuffer());
      Module.HEAPU8.set(data, pointer);
      result = Module._cimbare_encode(pointer, data.length);
      if (result < 0) throw new Error('分段准备失败：' + result);
    }
    if (result !== 0) result = Module._cimbare_encode(pointer, 0);
    if (result !== 0) throw new Error('分段未准备完成。');
  } finally { Module._free(pointer); }
  Module._cimbare_next_frame(false); Module._cimbare_render();
}
async function selectBatch(index, automatic = false) {
  if (preparing || !manifest || !initialized) return;
  const resume = automatic && playing;
  playing = false; ready = false; preparing = true; selected = index; count = 0;
  if (!automatic) {
    position = order.indexOf(index);
    if (position < 0) { order = [index]; position = 0; mending = true; }
  }
  elapsed = 0; lastTick = 0; roundDone = false;
  $('frames').textContent = '0'; $('current').textContent = (index + 1) + ' / ' + manifest.hashes.length;
  status('正在准备第' + (index + 1) + '段', '只处理这一段，不会一次载入整个文件。');
  $('canvas').hidden = true; $('empty').hidden = false;
  controls();
  try {
    await encode(await B.packet(file, manifest, index), index);
    ready = true; playing = resume;
    $('canvas').hidden = false; $('empty').hidden = true;
    status(playing ? '正在播放第' + (index + 1) + '段' : '第' + (index + 1) + '段已就绪',
      '按设定时长自动切到下一段。完成以接收端进度为准，漏段可在本轮后补收。');
  } catch (error) { status('这一段没有准备成功', error.message, true); }
  finally { preparing = false; controls(); progress(); }
}
async function prepare() {
  if (!file || preparing || !initialized) return;
  const token = ++generation;
  playing = false; ready = false; preparing = true; manifest = null;
  order = []; position = 0; round = 1; roundDone = false; mending = false;
  $('mending').value = '';
  $('canvas').hidden = true; $('empty').hidden = false;
  $('dashboard').hidden = false; $('filename').textContent = file.name; $('filename').title = file.name;
  $('fileSize').textContent = formatSize(file.size); $('total').textContent = '计算中'; $('current').textContent = '待就绪';
  controls();
  try {
    manifest = await B.prepare(file, Number($('partSize').value) * 1048576, (done, total) => {
      status('正在自动分段', '校验 ' + done + ' / ' + total + '，请稍候。');
    });
    if (token !== generation) return;
    order = manifest.hashes.map((_, i) => i);
    $('total').textContent = String(manifest.hashes.length);
    preparing = false;
    await selectBatch(0);
  } catch (error) { manifest = null; status('文件未能准备', error.message, true); }
  finally { preparing = false; controls(); }
}
function render(now) {
  requestAnimationFrame(render);
  if (!playing || !ready || preparing) { lastTick = 0; return; }
  if (lastTick) elapsed += (now - lastTick) / 1000;
  lastTick = now; progress();
  if (elapsed >= Number($('dwell').value)) {
    if (position + 1 < order.length) { position++; selectBatch(order[position], true); }
    else {
      playing = false; roundDone = true; progress(); controls();
      status('本轮已播完', '在接收端暂停并复制待收短码，粘贴到下方载入下一轮。源端播放进度不代表接收完成。');
    }
    return;
  }
  if (now - lastFrame < Math.floor(1000 / Number($('fps').value))) return;
  lastFrame = now;
  try {
    Module._cimbare_next_frame(false); Module._cimbare_render();
    $('frames').textContent = String(++count);
  } catch (error) { playing = false; controls(); status('播放停止', error.message, true); }
}
$('pattern').addEventListener('change', () => { file = $('pattern').files[0]; if (file) { locked = false; wake(); prepare(); } });
$('partSize').addEventListener('change', prepare);
$('mode').addEventListener('change', () => {
  if (initialized) Module._cimbare_configure(Number($('mode').value), -1);
  prepare();
});
$('play').addEventListener('click', async () => {
  if (roundDone) { position = 0; await selectBatch(order[0], true); if (!ready) return; }
  playing = !playing; locked = true; wake(); controls();
  status(playing ? '正在播放第' + (selected + 1) + '段' : '已暂停第' + (selected + 1) + '段',
    playing ? '自动按设定时长切段，播完本轮后暂停。接收端收齐后会自动合并。' : '当前播放位置保留。可调整节奏和每段停留时长，或粘贴待收短码。');
});
$('mending').addEventListener('input', controls);
$('apply').addEventListener('click', async () => {
  if (playing || preparing || !manifest) return;
  try {
    const next = B.replay(manifest, $('mending').value);
    order = next; position = 0; mending = true; round++; await selectBatch(order[0]);
    if (ready) status('补收轮已就绪 · ' + order.length + '段', '先在接收端点击读取，再开始本轮。已完成段不会重播。');
  } catch (error) { status('待收内容未能载入', error.message, true); }
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && playing) {
    playing = false; controls(); status('页面已隐藏，播放暂停', '返回页面后点击继续，避免后台计时跳过分段。');
  } else wake();
});
window.addEventListener('beforeunload', event => { if (playing) { event.preventDefault(); event.returnValue = ''; } });
window.knitRuntimeReady = () => {
  try {
    Module.canvas = $('canvas');
    if (Module._cimbare_init_window(0, 0) < 0) throw new Error('浏览器未能开启WebGL，请启用硬件加速。');
    Module._cimbare_configure(Number($('mode').value), -1); initialized = true; controls();
    if (file) prepare();
  } catch (error) { status('画面引擎未能启动', error.message, true); }
};
window.knitRuntimeFailed = error => {
  initialized = false; playing = false; ready = false; controls();
  status('画面引擎未能启动', '请使用支持WebAssembly和WebGL的Chrome。' + String(error), true);
};
requestAnimationFrame(render);
