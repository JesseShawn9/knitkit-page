'use strict';
var Module;
const B = KnitBatches;
const $ = id => document.getElementById(id);
let file, manifest, selected = 0, preparing = false, playing = false, ready = false, initialized = false;
let generation = 0, count = 0, lastFrame = 0, lamp, locked = false;
function status(title, hint, error = false) {
  $('stateTitle').textContent = title; $('stateHint').textContent = hint;
  $('status').dataset.error = error;
}
function formatSize(size) { return (size / 1048576).toFixed(1) + ' MiB'; }
function controls() {
  $('play').disabled = !ready || preparing || !initialized;
  $('next').disabled = !manifest || selected + 1 >= manifest.hashes.length || preparing;
  $('partSize').disabled = locked || preparing;
  $('pattern').disabled = preparing;
  $('play').textContent = playing ? '暂停' : '播放这一段';
}
function paintList() {
  const list = $('batchList'); list.replaceChildren();
  for (let i = 0; i < manifest.hashes.length; i++) {
    const button = document.createElement('button');
    button.type = 'button'; button.textContent = String(i + 1).padStart(2, '0');
    button.setAttribute('aria-current', String(i === selected)); button.disabled = preparing;
    button.addEventListener('click', () => selectBatch(i)); list.append(button);
  }
}
async function wake() {
  if (lamp || document.visibilityState !== 'visible') return;
  try { lamp = await navigator.wakeLock.request('screen'); lamp.addEventListener('release', () => { lamp = null; }); } catch {}
}
async function encode(blob, index) {
  const name = new TextEncoder().encode('knitkit2-' + manifest.id.slice(0, 12) + '-' + (index + 1) + '.bin');
  const namePtr = Module._malloc(name.length);
  try {
    Module.HEAPU8.set(name, namePtr);
    const result = Module._cimbare_init_encode(namePtr, name.length, -1);
    if (result < 0) throw new Error('画面初始化失败：' + result);
  } finally { Module._free(namePtr); }
  const size = Module._cimbare_encode_bufsize() * 16;
  const pointer = Module._malloc(size);
  let result = 1;
  try {
    for (let offset = 0; offset < blob.size; offset += size) {
      const data = new Uint8Array(await blob.slice(offset, offset + size).arrayBuffer());
      Module.HEAPU8.set(data, pointer);
      result = Module._cimbare_encode(pointer, data.length);
      if (result < 0) throw new Error('分段准备失败：' + result);
    }
    if (result !== 0) result = Module._cimbare_encode(pointer, 0);
    if (result !== 0) throw new Error('分段未准备完成。');
  } finally { Module._free(pointer); }
  Module._cimbare_next_frame(false); Module._cimbare_render();
}
async function selectBatch(index) {
  if (preparing || !manifest || !initialized) return;
  const resume = playing;
  playing = false; ready = false; preparing = true; selected = index; count = 0;
  $('frames').textContent = '0'; $('current').textContent = (index + 1) + ' / ' + manifest.hashes.length;
  status('正在准备第' + (index + 1) + '段', '只处理这一段，不会一次载入整个文件。');
  $('canvas').hidden = true; $('empty').hidden = false;
  controls(); paintList();
  try {
    await encode(await B.packet(file, manifest, index), index);
    ready = true; playing = resume;
    $('canvas').hidden = false; $('empty').hidden = true;
    status(playing ? '正在播放第' + (index + 1) + '段' : '第' + (index + 1) + '段已就绪',
      '扫描端显示这段已完成后，再点击下一段；也可直接选择待收序号。');
  } catch (error) { status('这一段没有准备成功', error.message, true); }
  finally { preparing = false; controls(); paintList(); }
}
async function prepare() {
  if (!file || preparing || !initialized) return;
  const token = ++generation;
  playing = false; ready = false; preparing = true; manifest = null;
  $('canvas').hidden = true; $('empty').hidden = false; $('batches').hidden = true;
  $('dashboard').hidden = false; $('filename').textContent = file.name; $('filename').title = file.name;
  $('fileSize').textContent = formatSize(file.size); $('total').textContent = '计算中'; $('current').textContent = '待就绪';
  controls();
  try {
    manifest = await B.prepare(file, Number($('partSize').value) * 1048576, (done, total) => {
      status('正在自动分段', '校验 ' + done + ' / ' + total + '，请稍候。');
    });
    if (token !== generation) return;
    $('total').textContent = String(manifest.hashes.length); $('batches').hidden = false;
    preparing = false;
    await selectBatch(0);
  } catch (error) { manifest = null; status('文件未能准备', error.message, true); }
  finally { preparing = false; controls(); }
}
function render(now) {
  requestAnimationFrame(render);
  if (!playing || !ready || preparing || now - lastFrame < 1000 / Number($('fps').value)) return;
  lastFrame = now;
  try {
    Module._cimbare_next_frame(false); Module._cimbare_render();
    $('frames').textContent = String(++count);
  } catch (error) { playing = false; controls(); status('播放停止', error.message, true); }
}
$('pattern').addEventListener('change', () => { file = $('pattern').files[0]; if (file) { locked = false; wake(); prepare(); } });
$('partSize').addEventListener('change', prepare);
$('play').addEventListener('click', () => {
  playing = !playing; locked = true; wake(); controls();
  status(playing ? '正在播放第' + (selected + 1) + '段' : '已暂停第' + (selected + 1) + '段',
    '等待扫描端显示本段完成，再选择下一段。接收端的待收列表才是完成依据。');
});
$('next').addEventListener('click', () => selectBatch(selected + 1));
document.addEventListener('visibilitychange', () => { if (playing) wake(); });
window.addEventListener('beforeunload', event => { if (playing) { event.preventDefault(); event.returnValue = ''; } });
window.knitRuntimeReady = () => {
  try {
    Module.canvas = $('canvas');
    if (Module._cimbare_init_window(0, 0) < 0) throw new Error('浏览器未能开启WebGL，请启用硬件加速。');
    Module._cimbare_configure(68, -1); initialized = true; controls();
    if (file) prepare();
  } catch (error) { status('画面引擎未能启动', error.message, true); }
};
window.knitRuntimeFailed = error => {
  initialized = false; playing = false; ready = false; controls();
  status('画面引擎未能启动', '请使用支持WebAssembly和WebGL的Chrome。' + String(error), true);
};
requestAnimationFrame(render);
