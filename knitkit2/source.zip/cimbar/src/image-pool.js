'use strict';
globalThis.KnitImagePool = {
  create(makeWorker) {
    const slots = [];
    function deliver(owner, type, data) {
      if (!owner?.active) return;
      owner.target.dispatchEvent(type === 'message' ? new MessageEvent(type, { data }) : new Event(type));
    }
    function pump(slot) {
      if (!slot.ready || slot.busy || !slot.queue.length) return;
      const job = slot.queue.shift();
      slot.busy = job.owner;
      try { slot.worker.postMessage(job.data, job.transfer); }
      catch { slot.busy = null; deliver(job.owner, 'error'); }
    }
    function borrow(url, options) {
      let slot = slots.find(value => !value.owner);
      if (!slot) {
        if (slots.length === 4) throw new Error('Image worker limit exceeded');
        slot = { worker: makeWorker(url, options), owner: null, ready: null, busy: null, queue: [] };
        slots.push(slot);
        slot.worker.addEventListener('message', event => {
          if (event.data?.ready) { slot.ready = event.data; deliver(slot.owner, 'message', event.data); }
          else {
            const owner = slot.busy; slot.busy = null;
            deliver(owner, 'message', event.data);
          }
          pump(slot);
        });
        for (const type of ['error', 'messageerror']) slot.worker.addEventListener(type, () => deliver(slot.owner, type));
      }
      const target = new EventTarget(), owner = { target, active: true };
      slot.owner = owner;
      for (const type of ['message', 'error', 'messageerror']) {
        let handler = null;
        Object.defineProperty(target, 'on' + type, {
          get: () => handler,
          set(value) { if (handler) target.removeEventListener(type, handler); handler = typeof value === 'function' ? value : null; if (handler) target.addEventListener(type, handler); }
        });
      }
      target.postMessage = (data, transfer) => {
        if (!owner.active) return;
        if (slot.queue.length >= 24) { deliver(owner, 'error'); return; }
        slot.queue.push({ owner, data, transfer }); pump(slot);
      };
      target.terminate = () => {
        if (!owner.active) return;
        owner.active = false; slot.queue = slot.queue.filter(job => job.owner !== owner);
        if (slot.owner === owner) slot.owner = null;
      };
      if (slot.ready) queueMicrotask(() => deliver(owner, 'message', slot.ready));
      return target;
    }
    function retire() { for (const slot of slots) slot.owner?.target.terminate(); }
    function clear() {
      retire();
      for (const slot of slots.splice(0)) { slot.queue.length = 0; slot.busy = null; slot.worker.terminate(); }
    }
    return { borrow, retire, clear };
  }
};
