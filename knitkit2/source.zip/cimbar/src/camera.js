'use strict';
globalThis.KnitCameraLease = {
  create(request, active, preview = null) {
    let stream = null, pending = null, generation = 0;
    const stop = value => value.getTracks().forEach(track => track.stop());
    const canceled = () => new DOMException('Camera request canceled', 'AbortError');
    function release() {
      generation++; pending = null;
      if (stream) stop(stream);
      stream = null;
      if (preview) { preview.pause(); preview.srcObject = null; }
    }
    function acquire(constraints) {
      if (!active()) return Promise.reject(canceled());
      if (stream && stream.getVideoTracks().some(track => track.readyState === 'live')) return Promise.resolve(stream);
      if (pending) return pending;
      if (stream) release();
      const token = generation;
      pending = Promise.resolve().then(() => {
        if (token !== generation || !active()) throw canceled();
        return request(constraints);
      }).then(value => {
        if (token !== generation || !active()) { stop(value); throw canceled(); }
        stream = value;
        if (preview && preview.srcObject !== value) { preview.srcObject = value; preview.play().catch(() => {}); }
        return value;
      }).finally(() => { if (token === generation) pending = null; });
      return pending;
    }
    return { acquire, release };
  }
};
