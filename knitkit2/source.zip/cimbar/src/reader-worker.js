'use strict';
let buffers = {};
let currentId = null;
let completed = false;
function batchMemory(name, size) {
  let b = buffers[name];
  if (!b || b.size < size) {
    if (b) Module._free(b.pointer);
    b = { pointer: Module._malloc(size), size };
  }
  buffers[name] = b;
  return new Uint8Array(Module.HEAPU8.buffer, b.pointer, b.size);
}
function report() {
  const b = batchMemory('report', 8192);
  const length = Module._cimbard_get_report(b.byteOffset, b.length);
  try { return JSON.parse(new TextDecoder().decode(batchMemory('report', 8192).slice(0, length))); }
  catch { return []; }
}
function recover(id) {
  const size = Module._cimbard_get_decompress_bufsize();
  const chunks = [];
  let total = 0;
  while (true) {
    const b = batchMemory('decompress', size);
    const length = Module._cimbard_decompress_read(id, b.byteOffset, size);
    if (length < 0) throw new Error('分段解压失败。');
    if (length === 0) break;
    total += length;
    if (total > 22 * 1024 * 1024 + 12) throw new Error('分段超过安全容量，请使用配套源端。');
    chunks.push(batchMemory('decompress', size).slice(0, length));
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return bytes;
}
self.onmessage = event => {
  try {
    const { pixels, width, height } = event.data;
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 ||
        width > 2560 || height > 2560 || pixels.length !== width * height * 4) throw new Error('画面尺寸不正确。');
    const inputPointer = batchMemory('image', pixels.length).byteOffset;
    Module.HEAPU8.set(pixels, inputPointer);
    const outputSize = Module._cimbard_get_bufsize();
    const outputPointer = batchMemory('fountain', outputSize).byteOffset;
    Module._cimbard_configure_decode(68);
    const length = Module._cimbard_scan_extract_decode(inputPointer, width, height, 4, outputPointer, outputSize);
    if (length <= 0) { postMessage({ kind: 'frame', decoded: false }); return; }
    const bytes = batchMemory('fountain', outputSize);
    const id = new DataView(bytes.buffer, bytes.byteOffset, 4).getUint32(0, true);
    // A fresh WASM instance bounds memory and avoids the upstream eight-stream slot collisions.
    if (currentId !== null && currentId !== id) { postMessage({ kind: 'switch' }); return; }
    currentId = id;
    if (completed) { postMessage({ kind: 'frame', decoded: true, progress: [1] }); return; }
    const result = Module._cimbard_fountain_decode(bytes.byteOffset, length);
    if (result > 0) {
      const value = recover(Number(result & 0xffffffffn));
      completed = true;
      postMessage({ kind: 'complete', buffer: value.buffer }, [value.buffer]);
    } else {
      postMessage({ kind: 'frame', decoded: true, progress: report() });
    }
  } catch (error) {
    postMessage({ kind: 'error', message: error.message || String(error) });
  }
};
