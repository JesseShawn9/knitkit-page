'use strict';
let buffers = {};
let currentId = null;
let completed = false;
let mode = 68;
function batchMemory(name, size) {
  let b = buffers[name];
  if (!b || b.size < size) {
    if (b) Module._free(b.pointer);
    b = { pointer: Module._malloc(size), size };
  }
  buffers[name] = b;
  return new Uint8Array(Module.HEAPU8.buffer, b.pointer, b.size);
}
function report() {
  const b = batchMemory('report', 8192);
  const length = Module._cimbard_get_report(b.byteOffset, b.length);
  try { return JSON.parse(new TextDecoder().decode(batchMemory('report', 8192).slice(0, length))); }
  catch { return []; }
}
function recover(id) {
  const size = Module._cimbard_get_decompress_bufsize();
  const chunks = [];
  let total = 0;
  while (true) {
    const b = batchMemory('decompress', size);
    const length = Module._cimbard_decompress_read(id, b.byteOffset, size);
    if (length < 0) throw new Error('分段解压失败。');
    if (length === 0) break;
    total += length;
    if (total > 22 * 1024 * 1024 + 12) throw new Error('分段超过安全容量，请使用配套源端。');
    chunks.push(batchMemory('decompress', size).slice(0, length));
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return bytes;
}
function legacyRead(event) {
  try {
    const { pixels, width, height } = event.data;
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 ||
        width > 8192 || height > 8192 || width * height > 16777216 || pixels.length !== width * height * 4) throw new Error('画面尺寸不正确。');
    const inputPointer = batchMemory('image', pixels.length).byteOffset;
    Module.HEAPU8.set(pixels, inputPointer);
    let length = 0, outputSize = 0;
    // Try all upstream modes before a stream is found; retain its mode while gathering.
    for (const candidate of currentId === null ? [mode, ...[68, 67, 66].filter(m => m !== mode)] : [mode]) {
      Module._cimbard_configure_decode(candidate);
      outputSize = Module._cimbard_get_bufsize();
      const outputPointer = batchMemory('fountain', outputSize).byteOffset;
      length = Module._cimbard_scan_extract_decode(inputPointer, width, height, 4, outputPointer, outputSize);
      if (length > 0) { mode = candidate; break; }
    }
    if (length <= 0) {
      postMessage({ kind: 'frame', decoded: false, scanCode: length }); return;
    }
    const bytes = batchMemory('fountain', outputSize);
    const id = new DataView(bytes.buffer, bytes.byteOffset, 4).getUint32(0, true);
    // A fresh WASM instance bounds memory and avoids the upstream eight-stream slot collisions.
    if (currentId !== null && currentId !== id) { postMessage({ kind: 'switch' }); return; }
    currentId = id;
    if (completed) { postMessage({ kind: 'frame', decoded: true, progress: [1] }); return; }
    const result = Module._cimbard_fountain_decode(bytes.byteOffset, length);
    if (result > 0) {
      const value = recover(Number(result & 0xffffffffn));
      completed = true;
      postMessage({ kind: 'complete', buffer: value.buffer }, [value.buffer]);
    } else {
      postMessage({ kind: 'frame', decoded: true, progress: report() });
    }
  } catch (error) {
    postMessage({ kind: 'error', message: error.message || String(error) });
  }
}

const chunkSizes = { 68: 625, 67: 429, 66: 540 };
const role = typeof knitRole === 'undefined' ? 'pipeline' : knitRole;
let collectorSerial = Promise.resolve(), active = null, catalog = null, nativeKey = null;
let nativeLabel = 1, recoveredLabel = 0;
const aliases = new Map();
const trials = new Map();
function equalBytes(a, b) { return a.length === b.length && a.every((v, i) => v === b[i]); }
function extract(data) {
  const { pixels, width, height, sequence } = data;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width > 8192 || height > 8192 || width * height > 16777216 || !pixels || pixels.length !== width * height * 4) throw new Error('画面尺寸不正确。');
  const input = batchMemory('image', pixels.length).byteOffset;
  Module.HEAPU8.set(pixels, input);
  for (const candidate of [mode, ...[68, 67, 66].filter(m => m !== mode)]) {
    Module._cimbard_configure_decode(candidate);
    const size = Module._cimbard_get_bufsize();
    const pointer = batchMemory('fountain', size).byteOffset;
    const length = Module._cimbard_scan_extract_decode(input, width, height, 4, pointer, size);
    if (length <= 0) continue;
    mode = candidate;
    const bytes = batchMemory('fountain', size).slice(0, length);
    if (length % chunkSizes[mode]) throw new Error('画面片段长度不正确。');
    postMessage({ kind: 'symbols', mode, sequence, bytes }, [bytes.buffer]); return;
  }
  postMessage({ kind: 'frame', sequence, decoded: false });
}
async function loadSkein(key, initial) {
  if (active && active.meta.key === key) return active;
  const meta = catalog.get(key) || initial;
  const blocks = new Map((await KnitStore.stitches(key)).map(s => [s.block, new Uint8Array(s.bytes)]));
  active = { meta, blocks, prefixCount: 0, prefix: null, header: new Uint8Array(), headerDone: false };
  return active;
}
async function identify(skein) {
  if (skein.headerDone || skein.meta.task) return;
  if (!skein.prefix) skein.prefix = new fzstd.Decompress(bytes => {
    if (skein.headerDone) return;
    if (skein.header.length + bytes.length > 3 * 1024 * 1024) throw new Error('分段清单超过容量。');
    const joined = new Uint8Array(skein.header.length + bytes.length);
    joined.set(skein.header); joined.set(bytes, skein.header.length); skein.header = joined;
  });
  const payload = chunkSizes[skein.meta.mode] - 6;
  const count = Math.ceil(skein.meta.size / payload);
  while (skein.prefixCount < count && skein.blocks.has(skein.prefixCount) && !skein.headerDone) {
    const index = skein.prefixCount++;
    const bytes = skein.blocks.get(index).subarray(6, 6 + Math.min(payload, skein.meta.size - index * payload));
    skein.prefix.push(bytes);
    const h = skein.header;
    if (h.length < 12) continue;
    if (new TextDecoder().decode(h.subarray(0, 8)) !== 'KK2PACK\n') throw new Error('请使用配套的KnitKit2源端。');
    const length = new DataView(h.buffer).getUint32(8);
    if (length < 1 || length > 2 * 1024 * 1024) throw new Error('分段清单长度不正确。');
    if (h.length < 12 + length) continue;
    const value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(h.subarray(12, 12 + length)));
    await KnitBatches.validate(value.manifest);
    if (value.v !== 1 || !Number.isInteger(value.index) || value.index < 0 || value.index >= value.manifest.hashes.length) throw new Error('分段清单序号不正确。');
    skein.meta.task = value.manifest.id; skein.meta.index = value.index; skein.meta.manifest = value.manifest;
    await KnitStore.remember(value.manifest);
    skein.headerDone = true; skein.prefix = null; skein.header = new Uint8Array();
  }
}
function nativeFeed(bytes) {
  const pointer = batchMemory('fountain', bytes.length).byteOffset;
  Module.HEAPU8.set(bytes, pointer);
  Module.HEAPU8[pointer] = (bytes[0] & 128) | nativeLabel;
  return Module._cimbard_fountain_decode(pointer, bytes.length);
}
function activateNative(candidateMode, key) {
  Module._cimbard_configure_decode(candidateMode === 68 ? 66 : 68);
  Module._cimbard_configure_decode(candidateMode);
  nativeLabel = (recoveredLabel + 1) % 128;
  nativeKey = key;
}
async function tryUnanchored(skein) {
  if (skein.meta.key.startsWith('pending:')) return null;
  const needed = Math.ceil(skein.meta.size / (chunkSizes[skein.meta.mode] - 6));
  for (const prior of catalog.values()) {
    if (!prior.key.startsWith('pending:') || prior.done || prior.consumed || prior.mode !== skein.meta.mode || prior.size !== skein.meta.size || prior.count + skein.blocks.size < needed) continue;
    const pair = skein.meta.key + '/' + prior.key, total = prior.count + skein.blocks.size;
    const previous = trials.get(pair);
    if (previous === -1 || (previous !== undefined && total < previous + 12)) continue;
    trials.set(pair, total);
    const candidate = await KnitStore.stitches(prior.key), union = new Map(skein.blocks);
    if (candidate.some(s => union.has(s.block) && !equalBytes(union.get(s.block), s.bytes))) { trials.set(pair, -1); continue; }
    for (const s of candidate) union.set(s.block, new Uint8Array(s.bytes));
    if (union.size < needed) continue;
    activateNative(skein.meta.mode, null);
    let result = 0n;
    for (const bytes of union.values()) { result = nativeFeed(bytes); if (result > 0n) break; }
    if (result <= 0n) continue;
    recoveredLabel = nativeLabel;
    try {
      const bytes = recover(Number(result & 0xffffffffn));
      const packet = await KnitBatches.unpack(new Blob([bytes]));
      if (skein.meta.task && (packet.manifest.id !== skein.meta.task || packet.index !== skein.meta.index)) continue;
      // A trial never overwrites either journal. Only a fully verified result is accepted.
      return { bytes, packet, assisted: prior.key };
    } catch { /* A candidate is not an identity: retain both journals if validation fails. */ }
  }
  return null;
}
async function collect(data) {
  if (!catalog) catalog = new Map((await KnitStore.skeins()).map(s => [s.key, s]));
  if (data.kind === 'inventory') {
    postMessage({ kind: 'inventory', skeins: [...catalog.values()] }); return;
  }
  if (data.kind === 'saved') {
    const meta = catalog.get(data.key);
    if (meta) {
      meta.done = true; meta.progress = 1; meta.task = data.task; meta.index = data.index; delete meta.manifest;
      await KnitStore.dropSkein(meta.key); await KnitStore.journal(meta, []);
      if (meta.assisted) {
        const prior = catalog.get(meta.assisted);
        if (prior) { prior.consumed = true; await KnitStore.journal(prior, []); }
      }
      if (active && active.meta.key === meta.key) { active = null; nativeKey = null; }
    }
    postMessage({ kind: 'saved', key: data.key }); return;
  }
  const size = chunkSizes[data.mode], bytes = data.bytes;
  if (!size || !bytes || !bytes.length || bytes.length % size) throw new Error('片段格式不正确。');
  const groups = new Map();
  for (let offset = 0; offset < bytes.length; offset += size) {
    const chunk = bytes.slice(offset, offset + size);
    const compressed = (chunk[0] >>> 7) * 16777216 + chunk[1] * 65536 + chunk[2] * 256 + chunk[3];
    if (!compressed || compressed > 24 * 1024 * 1024) throw new Error('分段容量不正确。');
    const wire = data.mode + ':' + chunk[0] + ':' + compressed;
    chunk[0] &= 128;
    if (!groups.has(wire)) groups.set(wire, { compressed, chunks: [] });
    groups.get(wire).chunks.push({ block: chunk[4] * 256 + chunk[5], bytes: chunk });
  }
  for (const [wire, group] of groups) {
    const zero = group.chunks.find(c => c.block === 0);
    const anchor = zero ? data.mode + ':' + group.compressed + ':' + await KnitBatches.hash(zero.bytes) : null;
    let key = anchor || aliases.get(wire) || 'pending:' + crypto.randomUUID();
    const previous = aliases.get(wire);
    let carried = [];
    if (anchor && previous && previous !== anchor && previous.startsWith('pending:')) carried = [...(await loadSkein(previous)).blocks].map(([block, bytes]) => ({ block, bytes }));
    let skein = await loadSkein(key, { key, mode: data.mode, size: group.compressed, count: 0, progress: 0 });
    // An identical systematic prefix is only a replay candidate. Never overwrite conflicts;
    // complete envelope and per-part SHA-256 validation remain mandatory before acceptance.
    const incoming = carried.concat(group.chunks);
    const seen = new Map();
    for (const s of incoming) {
      if (seen.has(s.block) && !equalBytes(seen.get(s.block), s.bytes)) throw new Error('同一编号内容不一致，原进度已保留，请重新读取这一段。');
      seen.set(s.block, s.bytes);
    }
    if (incoming.some(s => skein.blocks.has(s.block) && !equalBytes(skein.blocks.get(s.block), s.bytes))) {
      key = 'pending:' + crypto.randomUUID();
      skein = await loadSkein(key, { key, mode: data.mode, size: group.compressed, count: 0, progress: 0 });
      postMessage({ kind: 'notice', message: '发现不一致的片段，已分开保留，不会覆盖原进度。请保持同一文件及分段参数。' });
    }
    aliases.set(wire, key);
    if (skein.meta.done || skein.delivered) { postMessage({ kind: 'progress', key, meta: skein.meta }); continue; }
    const added = [];
    for (const s of incoming) if (!skein.blocks.has(s.block)) { skein.blocks.set(s.block, s.bytes); added.push(s); }
    skein.meta.count = skein.blocks.size;
    await identify(skein);
    await KnitStore.journal(skein.meta, added);
    catalog.set(key, skein.meta);
    if (carried.length && previous !== key) { await KnitStore.dropSkein(previous); catalog.delete(previous); }
    let result = 0n;
    if (nativeKey !== key) {
      // Upstream's decompressor caches the last ID independently of its fountain sink.
      activateNative(data.mode, key);
      for (const chunk of skein.blocks.values()) { result = nativeFeed(chunk); if (result > 0n) break; }
    } else for (const s of added) { result = nativeFeed(s.bytes); if (result > 0n) break; }
    const progress = Math.max(skein.meta.progress || 0, Number(report()[0]) || 0);
    let combined = null;
    if (result <= 0n) combined = await tryUnanchored(skein);
    if (result > 0n || combined) {
      if (result > 0n) recoveredLabel = nativeLabel;
      const value = combined ? combined.bytes : recover(Number(result & 0xffffffffn));
      const verified = combined ? combined.packet : await KnitBatches.unpack(new Blob([value]));
      skein.meta.task = verified.manifest.id; skein.meta.index = verified.index; skein.meta.manifest = verified.manifest;
      if (combined) skein.meta.assisted = combined.assisted;
      skein.meta.progress = 1;
      skein.delivered = true;
      postMessage({ kind: 'complete', key, meta: skein.meta, buffer: value.buffer }, [value.buffer]);
    } else {
      skein.meta.progress = progress;
      await KnitStore.journal(skein.meta, []);
      postMessage({ kind: 'progress', key, meta: skein.meta });
    }
  }
  postMessage({ kind: 'settled', sequence: data.sequence });
}
self.onmessage = event => {
  if (role === 'pipeline') { legacyRead(event); return; }
  if (role === 'extract') {
    try { extract(event.data); } catch (error) { postMessage({ kind: 'error', message: error.message }); }
    return;
  }
  collectorSerial = collectorSerial.then(() => collect(event.data)).catch(error => {
    nativeKey = null;
    postMessage({ kind: 'error', message: error.message || String(error) });
  });
};
