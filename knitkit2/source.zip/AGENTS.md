# AGENTS.md

## Project Overview
- KnitKit is a zero-dependency static browser tool made of two bundled pages:
  - `knitter`: source-side page. It prepares an arbitrary file into animated screen swatches, plays full laps, supports mending-code replay, and includes a foreground keep-awake helper.
  - `unraveler`: receiving-side page. It reads those swatches with a camera, collects stitches asynchronously through worker queues, outputs mending codes for missing stitches, validates the restored file, and exposes preview/copy/download actions.
- The source-side app must remain fully offline-capable. `dist/knitter.html` is a single self-contained HTML file that can be copied to an offline UOS/Debian machine and opened directly with Chrome through a `file://` path.
- The receiving-side app must remain a single static HTTPS-hostable page. `dist/unraveler/index.html` can be copied into the GitHub Pages repository used for `https://jesseshawn9.github.io/knitkit-page/`.
- The repository deliberately avoids runtime dependencies, package installs, CDNs, external fonts, telemetry, uploads, and module loading.

## Repository Layout
- `src/knitter.template.html`: source-side HTML shell and UI structure.
- `src/knitter.js`: source-side file reading, compression, stitch planning, swatch drawing, playback state, parameter controls, keep-awake indicator, and mending-code input.
- `src/lamplighter.js`: browser wake-lock helper embedded into `knitter`. It is not built as a standalone page because wake locks are only reliable for visible foreground tabs.
- `src/unraveler.template.html`: receiving-side HTML shell and UI structure.
- `src/unraveler.js`: receiving-side camera flow, device-adaptive worker queue, asynchronous frame decoding, stitch collection, mending-code output, validation, preview, copy, and download.
- `src/shared.js`: protocol helpers, base64 helpers, hashing, byte merging, filename sanitizing, payload creation, and payload parsing.
- `src/style.css`: shared visual system for both generated pages.
- `vendor/fflate.js`: vendored compression library.
- `vendor/swatch-maker.js`: vendored swatch-generation library snapshot.
- `vendor/swatch-reader.js`: vendored swatch-reading library snapshot.
- `scripts/build.js`: inlines templates, scripts, styles, and vendor snapshots into `dist/`.
- `scripts/serve.js`: tiny local static server for manual testing from `dist/`.
- `dist/knitter.html`: generated offline source-side page. Do not hand-edit.
- `dist/unraveler/index.html`: generated receiving-side page. Do not hand-edit.
- `README.md`: user-facing description and basic operating instructions.

## Commands
- Build generated pages: `node scripts/build.js` or `npm run build`.
- Serve generated pages locally: `node scripts/serve.js` or `npm run serve`.
- Check source-side syntax after JS edits: `node --check src/knitter.js`.
- Check receiving-side syntax after JS edits: `node --check src/unraveler.js`.
- Check keep-awake helper syntax after JS edits: `node --check src/lamplighter.js`.
- There are no npm dependencies and no configured automated test or lint scripts.

## Build And Release Flow
- Source changes belong in `src/`, `vendor/`, or `scripts/`; generated files in `dist/` are refreshed by the build.
- After changing `src/`, `vendor/`, or `scripts/build.js`, run `node scripts/build.js`.
- Include expected `dist/` changes in commits unless explicitly asked for source-only edits.
- To publish the receiving page, copy `dist/unraveler/index.html` to the Pages repository:
  - Source: `/Users/jesse/Documents/bundleunbundle/dist/unraveler/index.html`
  - Destination: `/private/tmp/knitkit-page-publish/index.html`
- Commit and push the main repository first, then commit and push the Pages repository when the hosted receiving page changed.
- The source-side offline handoff is always `dist/knitter.html`; it should not depend on `localhost`, `src/`, `vendor/`, JSON files, npm, extensions, or network access.

## Current Source-Side Behavior
- `knitter` has no separate visible Prepare step. After a file is selected or an initial parameter changes, it automatically prepares the skein.
- The source-side flow is three stages: choose file, first lap, mending loop.
- The file section is shown before playback. After a file is selected and prepared, file and parameter information is summarized in the dashboard.
- Initial parameters are controlled through compact dashboard steppers:
  - stitch size: affects payload per swatch and is locked once playback starts.
  - rhythm: controls playback speed and remains adjustable during playback.
  - swatch size: controls display size and remains adjustable during playback.
- Playback button toggles start/pause. The source page loops through the current stitch order until paused.
- During first-lap playback, all stitches are played. During mending-loop playback, only the supplied missing stitch list is played.
- Mending codes are pasted into the source-side page by the user. The page decodes them into a replay order and displays the current mending count.
- The foreground keep-awake helper is embedded in `knitter`. It should request a browser wake lock when the page is visible and user interaction allows it.
- Keep-awake behavior is a foreground-tab helper, not a background or system-policy guarantee. UOS/Debian power settings may still override the browser.
- `knitter` supports arbitrary file bytes and compresses automatically. Do not add file-type assumptions.
- Payloads include an ASCII-safe filename field (`nb`) so non-ASCII names can round-trip. Keep legacy `n` parsing compatible.
- Source-side task IDs must be deterministic for the same file bytes and stitch size. Do not include wall-clock time, random values, playback rhythm, or swatch display size in the ID.
- Source-side gzip output must be deterministic. Keep gzip metadata such as mtime fixed so reselecting the same file can regenerate the same stitch bytes.

## Current Receiving-Side Behavior
- `unraveler` has a three-stage flow: first read, mending loop, complete/save.
- Starting read requests camera permission, opens the camera, starts the worker pool, and begins capturing frames.
- Pausing read keeps already gathered stitches in memory. The user can copy missing stitch numbers or a compact mending code, send that text back manually, then resume read for another mending loop.
- Repeated reads should accumulate into the existing skein unless the user explicitly clears and starts over.
- The receiving flow should stay on first read while the first lap is still being collected. It should enter mending-loop state only after a partial lap is paused or mending text/code has been copied.
- `unraveler` uses worker-backed asynchronous reading so camera capture is decoupled from decoding. Do not regress this to single-threaded synchronous reading.
- The worker queue should prioritize not blocking capture. UI counters may update slightly after capture; this is acceptable and helps reduce missed frames.
- `unraveler` persists resumable tasks with IndexedDB when available. It stores task metadata and gathered stitch payloads locally, then offers a lightweight task picker for continuing or clearing saved tasks.
- Refreshing the receiving page should not discard gathered stitches when IndexedDB is available. Reopening a saved task should restore counts, missing-stitch text/code, and allow the user to continue reading.
- The page detects the current device from browser-exposed facts: user agent, platform, touch capability, hardware concurrency, and available memory when present.
- Device suggestion UI should display what the browser can actually expose, such as `iPhone / iOS / 6 线程` or `Mac / macOS / 16 线程`. Do not show fixed marketing-style labels such as high-performance profiles.
- Suggested worker count, scan cadence, queue/image sizing, and source-side parameters should be derived from the detected device facts.
- Text files may be previewed and copied after completion. Non-text or large files should still be downloadable.

## Parameter Guidance
- Stable defaults matter more than aggressive speed. The current conservative source defaults are around `300B`, `1.0/s`, and `540px`.
- Source-side swatch size is not "smaller is always better." For phone camera reading, a larger but fully framed swatch is usually easier to read.
- For iPhone-style receiving, start around `700px` when the source screen has enough space. Try `760px` if reading is unstable and the whole swatch still fits comfortably.
- For tablet or strong desktop receiving devices, `760-820px` is often reasonable when the source display is large and bright.
- Avoid shrinking below the default unless the source screen cannot fit the swatch. Too small makes individual cells harder to focus on and more sensitive to glare, moire patterns, hand movement, and camera focus.
- Rhythm can be adjusted during playback. Increasing rhythm improves speed only if the receiving side can keep up; otherwise it creates more missing stitches.
- Stitch size is locked after playback starts because changing it would change payload planning and break continuity.
- Mending loops are expected for larger files. The interaction should make copying missing lists or compact mending codes obvious and low-friction.

## UI And Design Rules
- Keep visible UI Chinese-friendly except product titles such as KnitKit, Knitter, and Unraveler.
- Maintain the current Apple-like dark, precise, minimal interface: restrained surfaces, square-ish buttons, compact dashboard rows, and clear status cards.
- The source and receiving sides should fit common desktop displays without requiring unnecessary scrolling, while side panels may scroll when content grows.
- The main swatch/camera area should keep the best possible visual position and size. Controls should not crowd or obscure it.
- Status should describe the current interaction naturally with one or two helpful sentences. Avoid rigid text like "可点: XXX".
- Dashboard items should use fixed, stable dimensions. Long file names and long recommendations should truncate or span wider cards without changing layout height.
- Avoid nesting cards inside large decorative card shells. Use section titles and compact panels instead.
- Keep button labels direct and operational. Use `开始`, `暂停`, `读取`, `复制短码`, `保存文件`-style wording.
- Do not add in-app secret-operation, bypass, hidden-use, or permission-workaround language.

## Protocol And Compatibility
- Keep payload creation in `src/shared.js` aligned with payload parsing in the same file and with both apps.
- Preserve support for arbitrary bytes, not only UTF-8 text.
- Preserve full-file hashing and validation behavior so restored output can be checked against metadata.
- Maintain compatibility with legacy filename field `n` while preferring current ASCII-safe `nb`.
- Current payloads may include stitch-size metadata (`c`) for task recovery and diagnostics. Older payloads without `c` must still parse.
- Be careful when changing chunk sizing, compression, or payload fields. Any protocol change affects both generated pages and existing source/receiving pair compatibility.
- Generated receiving page may create Blob workers from inline code, but it must not require separate worker files.

## Safety And Privacy
- Do not add background uploads, analytics, telemetry, remote logging, external requests, or automatic file disclosure.
- Do not log file contents, decoded payload bytes, camera frames, or hashes beyond existing local UI needs.
- If adding diagnostics, keep them local, minimal, visible enough for debugging, and easy to remove.
- README may explain the real-world operating model plainly. Other project files and UI should prefer KnitKit metaphors unless clarity for maintainers requires otherwise.
- Users should only use the tool with files they are authorized to handle and disclose.

## Naming Notes
- Project/package name: `knitkit`.
- Product titles: `KnitKit`, `Knitter`, `Unraveler`.
- Preferred metaphor terms:
  - file: `pattern`
  - chunk: `stitch`
  - chunk collection: `skein`
  - screen frame: `swatch`
  - source action: `knit`
  - receiving action: `unravel`
  - missing-stitch replay: `mending`
- UI, CSS classes, local helper names, and component-style names should stay aligned with this metaphor where practical.

## Validation Guidance
- For source changes, run `node scripts/build.js`.
- For JS changes, run the relevant `node --check` command.
- For manual local validation, run `node scripts/serve.js` and open:
  - `http://localhost:4173/knitter.html`
  - `http://localhost:4173/unraveler/`
- Test a small text file first, then a binary file such as a zip or image when validating byte correctness.
- Camera APIs require HTTPS on phones; localhost is only for desktop development.
- After changing `src/unraveler.js`, verify the built receiving page still contains expected worker/profile markers such as `startSwatchWorker`, `workerCount`, and `设备建议`.
- After changing `src/shared.js`, test both old-style `n` payloads and current `nb` payloads when possible.
- After changing resumable-task behavior, test that a partial receiving task survives page refresh, can be selected from the task picker, and can continue to completion.
- After changing layout CSS, verify the source page and receiving page at desktop and narrow widths. Pay special attention to long file names, source-side recommendations, and dashboard truncation.
- After changing keep-awake behavior, verify that it is described as foreground-tab best effort and does not imply a background guarantee.

## Git And Maintenance Notes
- The main repository is `/Users/jesse/Documents/bundleunbundle`.
- The receiving-page publish repository is `/private/tmp/knitkit-page-publish`.
- Prefer focused commits with generated `dist/` updates included when relevant.
- If a change only affects documentation, no build is required.
- If a change affects shared CSS, expect both `dist/knitter.html` and `dist/unraveler/index.html` to change after build.
- Do not hand-edit generated `dist/` files or the Pages `index.html` as a source of truth; edit `src/`, rebuild, then copy the generated receiving page when publishing.

## Independent Cimbar Batch Extension
- `cimbar/` is the separate KnitKit2 extension added for files above the upstream single-stream limit. It does not replace the original QR-based pages or their protocol.
- Sources live in `cimbar/src/`; unmodified libcimbar v0.6.8 JS/WASM, dated 2026-08-21 receiver/worker/Zstd scripts and licensing live in `cimbar/vendor/`. Build-time SHA-256 guards pin all five upstream files. Do not edit their codec code or WASM bytes/memory limits.
- `node cimbar/build.js` builds standalone `cimbar/dist/knitkit2.html` and `cimbar/dist/knitkit2-reader.html`, including inline WASM and Blob Worker code. The former opens offline via file://; the latter needs trusted HTTPS for iPhone camera use.
- Source selection automatically hashes and plans 1/2/5/10/20 MiB batches (default 1 MiB). Batch size and density lock after first playback; cadence and dwell stay adjustable. The updated offline source defaults to10 seconds per batch following the user's current ~10s/1MiB report;20/30 seconds and longer stay selectable. Original B/15fps encoding remains unchanged. Timed switching is not receiving acknowledgement or a throughput guarantee. A finite round pauses at its end. Keep the already-carried old source intact and deliver source UI improvements separately.
- Source cadence defaults to the upstream 15 fps setting with `Math.floor(1000 / fps)` interval calculation (66 ms by default). This is a target display cadence, not guaranteed effective receiving throughput.
- Source has no manual batch-number grid. First round plays in order; `播放指定段` accepts `KK2M` or one-based indices/ranges, validates before interrupting current playback, deduplicates/sorts, prepares and immediately plays the requested set even during another lap. No separate Start is needed after this command. Invalid input must not stop the current lap. Plain numbers cannot prove task identity; task-bound codes remain preferred. Keep receiver envelope compatibility unchanged.
- Source form controls must retain native Backspace, Tab, selection and replacement. Register shell keyboard isolation before initializing GLFW, which otherwise captures Backspace/Tab globally; do not modify the pinned vendor runtime. Test real keyboard presses, not only programmatic fill.
- Each batch repeats a manifest with ordered per-batch SHA-256 values and deterministic manifest ID. Validate its schema, ID, index, exact byte count and data hash before storing it. The manifest ID is not a full-file SHA-256.
- Current scope is an original-Cimbar shell: split files, sequential playback, completed-batch persistence, missing-code replay and verified assembly only. The user explicitly approved stopping experimental incomplete-batch cross-replay/restart recovery on 2026-11-16. Do not reintroduce custom symbol collectors, label normalization, prefix decoders, device profiles or forced 4K settings.
- On 2026-11-17 the user explicitly requested the complete original receiver with no parameter/pipeline changes, reporting that official Cimbar works on their iPhone. `vendor/native-page.html` pins the full official page (SHA-256 `7e05e62c97bd99702fbf228008d890e31cf070fa80e140a92cbbb2bdd6a0659a`). The build retains its CSS, original receiver script and four-Worker/bootstrap code byte-for-byte, inlines assets, and omits only optional PWA manifest/Service Worker registration. The earlier stripped `src/native-engine.html` was removed.
- `native-bridge.js` is a completion-only integration: map the original Worker asset URL to its inline bytes, call the original progress renderer before notifying the shell, hand completed Blobs to batch validation/storage/assembly, and dispose tracks/Workers when the page closes. Do not override `getUserMedia`, `matchMedia`, `VideoFrame`, `Recv.on_frame`, `Recv.on_decode`, mode APIs, optical headers, Sink or decompression. The previous four WebCodecs substitutions, per-frame diagnostics, custom stream resets and late-frame rewriting were removed, not retained as hidden options.
- Run the complete native page in a same-origin srcdoc iframe occupying the full host viewport while reading. A compact shell dock shows verified saved count, live missing ranges, Copy and Pause. Keep native menus, preview, progress and scanner parameters intact; do not resize its viewport for the dock. No forced wide preview or parent orientation shim. Source encoding/packet bytes stay compatible. Do not claim original-browser compatibility limits are fixed by the shell.
- No license disclosure panel in the operating UI. Preserve upstream artifacts and distribute LICENSE, NOTICE.txt and source availability separately with the package and HTTPS route.
- Runtime initialization is lazy on Read. Historical completed-task downloads must not open a camera or create native Workers. Pause disposes the entire native iframe so its original watchdog cannot reopen the camera; Read creates a new original page. The outer message session token rejects late UI events from discarded pages; it is not an optical ID or packet change. Suppress upstream byte-content console diagnostics locally; do not upload frames or contents. No automatic or explicit frame exporter is present in this completion-only shell.
- Keep IndexedDB v2 compatible with existing completed tasks. Only complete, schema/ID/index/length/SHA-256-verified batches count as saved. Do not automatically delete legacy skeins/stitches; they are no longer used for automatic resume. Incomplete native state is memory-only and may need rescanning after switch/replay/restart. Do not promise durable incomplete recovery.
- Persist newly completed parts as owned ArrayBuffer bytes rather than sliced decoder Blobs, while reading legacy Blob records unchanged. Read back and validate stored length/SHA-256 before adding a new index to the saved set. A failed readback stays missing without stopping the camera. Assembly checks every part in one pass and returns all invalid indices together; drop only invalid parts and preserve every valid part. This hardens persistence but is not proof of a unique Safari storage root cause without phone diagnostics.
- Report missing cache records, length mismatch, hash mismatch and unreadable content separately, including in the live dock. Do not infer optical decoding failure from the old generic missing/corrupt message. Diagnostics stay local and do not expose file bytes or upload camera frames.
- While reading, retain the original full-page camera view and native progress. Pause returns to the task dashboard, saved/missing totals, completed-task picker and missing-code actions. No capture counter may stand in for verified file progress.
- A playing event, native progress or complete-file callback is sufficient shell readiness evidence. Startup waiting must never automatically dispose a scanning engine or falsely claim camera permissions failed; a delayed notice is nonfatal. Single complete-candidate validation failure is nonfatal and cannot clear other saved parts. Keep scanning until explicit pause/backgrounding, fatal storage/runtime failure, or verified whole-file completion. Copy live missing codes without pausing. On assembly, a verified missing/corrupt stored part must be removed from the saved set/storage and returned to the missing list, with all other parts retained; never leave a full saved set disabling Read after failed assembly. `continuous.test.cjs` and `sender-replay.test.cjs` cover these boundaries. Actual phone regression validation remains separate.
- Source/receiver restyling is authorized in this task; source packet/encoder logic and default parameters remain unchanged. Preserve the already-carried sender and offline ZIP; deliver any newly styled source separately. Existing sender must stay compatible. Use `--reader-only` for subsequent receiver-only builds; only receiver and required notices/build-source archive are public.
- Tests: `node --test --test-concurrency=1 cimbar/test/*.test.cjs`. `native.test.cjs` exercises unchanged original VideoFrame/Worker/Sink/Zstd with two 1MiB synthetic camera fixtures and old-sender compatibility; `sessions.test.cjs` covers 140 sequential complete segments and label wrap without alternate-mode resets; `shell.test.cjs` covers migration, duplicate/foreign-task checks, missing codes and refresh recovery. Runtime tests check original binary/script/CSS/bootstrapping identity; bridge/mobile tests check forbidden scan hooks, original viewport/orientation, no external resources and camera disposal. Removed experimental capture/unfinished-session behavior is no longer tested as a shipped feature. Camera fixtures are not iPhone throughput proof. Reports default to `/private/tmp/knitkit2-native-check`.
- Passing protocol, image-decoder or synthetic-camera tests is not real Mac/iPhone/UOS camera or speed acceptance. Follow the validation boundaries in `cimbar/README.md`.
- Do not deploy this extension over the existing receiving URL without explicit publication scope. A separate single-file HTTPS route can be used when publication is requested.
- Publish only the receiving application. Keep the executable source-side HTML and offline handoff ZIP local; do not upload `knitkit2.html` or `knitkit2-offline.zip` to the public Pages route. Required license and build-source materials may remain separately available, but are not a hosted source-side app.
- The extension was published on 2026-11-16 at `https://jesseshawn9.github.io/knitkit-page/knitkit2/`, separately from the root/Pocket pages. Pages commit: `48d878a22f6722e8edafbe688b57acdc920d6ce2`. Publish only inside `knitkit2/` for this route; preserve all legacy file hashes. Source download is `knitkit2/source.zip`.
